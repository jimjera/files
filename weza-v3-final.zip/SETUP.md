# Weza v3 — Setup Guide

## Quick Start (Local Development)

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env — add your GROK_API_KEY
python -c "from app.database import init_db; init_db()"
python seed_demo.py
python run.py
# Open http://localhost:8000
```

## Deploy to VPS

```bash
scp weza-v3.zip root@your-server:/tmp/
ssh root@your-server
cd /tmp && unzip weza-v3.zip -d weza-v3
cp -r weza-v3/* /opt/weza/
cd /opt/weza
rm -f weza.db
source venv/bin/activate
pip install Pillow
python seed_demo.py
sudo systemctl restart weza
```

## Go Live with Evolution API (WhatsApp)

```bash
# On your VPS:
cd /opt/weza
bash deploy/setup_evolution.sh YOUR_SECRET_KEY wesza.online

# Then open in browser:
# http://YOUR_IP:8080/manager
# Login with YOUR_SECRET_KEY
# Click weza instance → Connect → Scan QR with phone

# Test:
curl -X POST http://localhost:8080/message/sendText/weza \
  -H "apikey: YOUR_SECRET_KEY" \
  -H "Content-Type: application/json" \
  -d '{"number":"YOUR_PHONE","text":"Hello from Weza!"}'
```

## Switch to Meta Cloud API (Later)

When your Meta Business account is ready:
1. Go to admin dashboard → click "Meta API" button
2. Or: `curl -X POST https://wesza.online/api/admin/set-provider -H "Content-Type: application/json" -d '{"provider":"meta"}'`
3. Update .env with WA_ACCESS_TOKEN and WA_PHONE_NUMBER_ID
4. Restart: `sudo systemctl restart weza`

## What's New in v3

### WhatsApp Providers (switch anytime)
- **Evolution API** — free, scan QR, go live today
- **Meta Cloud API** — official, needs business verification
- **Twilio** — sandbox testing
- Switch from admin dashboard with one click

### Session Trap Fix
- Users can now switch between shops/SACCOs without getting stuck
- Typing a keyword (VISION, GRACE, etc.) while in a shop session switches correctly
- Unrecognized messages in a shop search across ALL shops, not just current one

### Shop Pages
- Each shop gets a web page: wesza.online/shop/KEYWORD
- Beautiful dark mobile-first design
- WhatsApp deep links for Status card sharing

### SACCO Uganda Features
- Cash deposits at meetings with instant member confirmation
- Merry-go-round rotation tracking
- Shares vs Savings split
- Meeting management + attendance
- Member self-registration
- Automatic late fines
- Year-end dividends

### Marketplace
- Buyer→Seller connection flow (not automated checkout)
- SOLD command for sellers to record sales
- Shop verification (✅ blue tick)
- Status card image generation for WhatsApp Status
- Daily seller reports via WhatsApp

### Cost Tracking
- AI usage dashboard with daily costs
- Provider status monitoring
- Message logging for analytics
