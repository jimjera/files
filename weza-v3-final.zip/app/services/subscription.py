"""
app/services/subscription.py — SACCO/Group subscription & trial management
Zero AI cost — date checks + MoMo regex
"""
from datetime import datetime, timedelta
from app.database import get_db
from app.services.weza_ai import read_momo_text

PRICING = {
    "small": {"max_members": 20, "price": 15000, "label": "UGX 15,000"},
    "medium": {"max_members": 50, "price": 25000, "label": "UGX 25,000"},
    "large": {"max_members": 999999, "price": 40000, "label": "UGX 40,000"},
}
TRIAL_DAYS = 90
WEZA_MOMO = "0771234567"
WEZA_MOMO_NAME = "Weza Platform"

def check_subscription(tenant_id: int) -> dict:
    conn = get_db()
    t = conn.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
    if not t:
        conn.close()
        return {"active": False, "reason": "not_found"}
    t = dict(t)
    # RETAIL is free (revenue from verification)
    if t["module_type"] == "RETAIL":
        conn.close()
        return {"active": True, "reason": "retail_free"}
    # Check trial
    if t["subscription_status"] == "trial":
        if t.get("trial_ends_at"):
            trial_end = datetime.fromisoformat(t["trial_ends_at"])
            if datetime.now() < trial_end:
                days_left = (trial_end - datetime.now()).days
                conn.close()
                return {"active": True, "reason": "trial", "days_left": days_left}
        else:
            # Set trial end if not set
            end = datetime.now() + timedelta(days=TRIAL_DAYS)
            conn.execute("UPDATE tenants SET trial_ends_at=? WHERE id=?",
                         (end.isoformat(), tenant_id))
            conn.commit()
            conn.close()
            return {"active": True, "reason": "trial", "days_left": TRIAL_DAYS}
    # Check paid subscription
    if t["subscription_status"] == "paid" and t.get("subscription_paid_until"):
        paid_until = datetime.fromisoformat(t["subscription_paid_until"])
        if datetime.now() < paid_until:
            conn.close()
            return {"active": True, "reason": "paid"}
    conn.close()
    # Get member count for pricing
    conn = get_db()
    mc = conn.execute("SELECT COUNT(*) n FROM sacco_members WHERE tenant_id=? AND status='active'",
                      (tenant_id,)).fetchone()["n"]
    conn.close()
    tier = "small" if mc <= 20 else ("medium" if mc <= 50 else "large")
    p = PRICING[tier]
    return {"active": False, "reason": "expired", "price": p["price"],
            "label": p["label"], "members": mc, "tier": tier}

def get_payment_prompt(tenant_name, sub_info):
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ⏰ Free trial ended\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"*{tenant_name}* ({sub_info['members']} members)\n"
            f"has been using Weza free for 3 months.\n\n"
            f"To continue: pay {sub_info['label']}/month\n"
            f"MTN MoMo: {WEZA_MOMO} ({WEZA_MOMO_NAME})\n\n"
            f"Send the MoMo confirmation here.\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def process_payment(text, tenant_id):
    momo = read_momo_text(text)
    if not momo or not momo.get("transactionId"):
        return None
    conn = get_db()
    # Record verification
    conn.execute("INSERT INTO verifications (tenant_id,type,status,payment_ref,amount_paid) VALUES (?,'subscription','approved',?,?)",
                 (tenant_id, momo["transactionId"], momo["amount"]))
    # Extend subscription
    paid_until = datetime.now() + timedelta(days=30)
    conn.execute("UPDATE tenants SET subscription_status='paid', subscription_paid_until=? WHERE id=?",
                 (paid_until.isoformat(), tenant_id))
    conn.commit()
    conn.close()
    return {"ref": momo["transactionId"], "amount": momo["amount"],
            "paid_until": paid_until.strftime("%d %b %Y")}
