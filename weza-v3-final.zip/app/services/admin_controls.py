"""
app/services/admin_controls.py

Admin control menus and broadcast system for all three Weza modules.

Every module admin gets:
  MENU          — numbered control panel
  BROADCAST     — message all members/customers
  MENU [number] — execute a menu action

SACCO admin extras:
  REMIND        — nudge members with unpaid contributions

GROUPS admin extras:
  REMIND        — nudge all unpaid pledgers with auto-generated message

RETAIL admin extras:
  PROMO [msg]   — send offer to recent buyers
"""

import json
from datetime import datetime
from app.database import get_db
from app.services import whatsapp


# ═══════════════════════════════════════════════════════════════════════════════
# MENUS
# ═══════════════════════════════════════════════════════════════════════════════

SACCO_MENU = """*Admin Control Panel*
━━━━━━━━━━━━━━━━━━
*1* · Members & balances
*2* · Pending approvals
*3* · Monthly report
*4* · Add a member
*5* · Send reminder to all
*6* · Broadcast a message
*7* · View / update rules
*8* · Suspend a member
*9* · Member statement
━━━━━━━━━━━━━━━━━━
Reply with a number or type the command directly."""

GROUPS_MENU = """*Organiser Control Panel*
━━━━━━━━━━━━━━━━━━
*1* · Event progress (total)
*2* · All pledges
*3* · Unpaid pledges
*4* · Remind unpaid members
*5* · Transparency report
*6* · Broadcast to all
*7* · Record a pledge manually
*8* · Close the event
━━━━━━━━━━━━━━━━━━
Reply with a number or type the command directly."""

RETAIL_MENU = """*Shop Control Panel*
━━━━━━━━━━━━━━━━━━
*1* · Current stock list
*2* · Today's sales
*3* · Pending orders
*4* · Add a product
*5* · Update a price
*6* · Remove a product
*7* · Broadcast offer to buyers
*8* · Mark order as delivered
━━━━━━━━━━━━━━━━━━
Reply with a number or type the command directly."""


def get_menu(module_type: str) -> str:
    return {
        "SACCO":  SACCO_MENU,
        "GROUPS": GROUPS_MENU,
        "RETAIL": RETAIL_MENU,
    }.get(module_type, "Type HELP for available commands.")


def handle_menu_number(number: int, module_type: str, phone: str,
                       tenant: dict, session: dict) -> str:
    """Execute a menu action from the numbered panel."""
    from app.modules import sacco, groups, retail

    SACCO_ACTIONS = {
        1: "MEMBERS",
        2: "QUEUE",
        3: "REPORT",
        4: "add member",
        5: "_remind_contributions",
        6: "_broadcast_prompt",
        7: "RULES",
        8: "suspend",
        9: "statement",
    }
    GROUPS_ACTIONS = {
        1: "TOTAL",
        2: "PLEDGES",
        3: "UNPAID",
        4: "_remind_pledges",
        5: "REPORT",
        6: "_broadcast_prompt",
        7: "PLEDGE",
        8: "CLOSE EVENT",
    }
    RETAIL_ACTIONS = {
        1: "STOCK",
        2: "SALES",
        3: "_pending_orders",
        4: "add",
        5: "update",
        6: "remove",
        7: "_broadcast_prompt",
        8: "_mark_delivered",
    }

    action_map = {
        "SACCO":  SACCO_ACTIONS,
        "GROUPS": GROUPS_ACTIONS,
        "RETAIL": RETAIL_ACTIONS,
    }.get(module_type, {})

    action = action_map.get(number)
    if not action:
        return f"Option {number} not found. Reply MENU to see options."

    # Internal actions
    if action == "_remind_contributions":
        return remind_sacco_contributions(tenant, phone)
    if action == "_remind_pledges":
        return remind_unpaid_pledges(tenant, phone)
    if action == "_broadcast_prompt":
        from app.services.session_store import update_context
        update_context(phone, {"admin_action": "awaiting_broadcast"})
        return "What message would you like to send to everyone?\n\nType it now:"
    if action == "_pending_orders":
        return pending_orders(tenant)
    if action == "_mark_delivered":
        from app.services.session_store import update_context
        update_context(phone, {"admin_action": "awaiting_order_id"})
        return "Which order number was delivered? Type the order ID:"

    # Route to module handler
    if module_type == "SACCO":
        return sacco.handle(action, phone, session)
    if module_type == "GROUPS":
        return groups.handle(action, phone, session)
    if module_type == "RETAIL":
        return retail.handle(action, phone, session)

    return "Command not found."


# ═══════════════════════════════════════════════════════════════════════════════
# BROADCAST — send a message to all members / customers
# ═══════════════════════════════════════════════════════════════════════════════

def broadcast_to_members(tenant: dict, message: str,
                          sender_phone: str) -> str:
    """Send a message to all active SACCO members."""
    conn    = get_db()
    members = conn.execute(
        "SELECT phone, full_name FROM sacco_members "
        "WHERE tenant_id=? AND status='active' AND phone!=?",
        (tenant["id"], sender_phone)
    ).fetchall()
    conn.close()

    if not members:
        return "No members to broadcast to yet."

    sent = 0
    failed = 0
    full_message = (
        f"📢 *{tenant['name']}*\n\n"
        f"{message}\n\n"
        f"_{datetime.now().strftime('%d %b %Y, %I:%M %p')}_"
    )

    for m in members:
        ok = whatsapp.send(m["phone"], full_message)
        if ok:
            sent += 1
        else:
            failed += 1

    result = f"Broadcast sent to {sent} member(s)."
    if failed:
        result += f" ({failed} failed — check their numbers.)"
    return result


def broadcast_to_pledgers(tenant: dict, message: str,
                           sender_phone: str) -> str:
    """Send a message to all event pledgers."""
    conn = get_db()
    event = conn.execute(
        "SELECT * FROM group_events WHERE tenant_id=? AND status='active' LIMIT 1",
        (tenant["id"],)
    ).fetchone()

    if not event:
        return "No active event to broadcast to."

    pledgers = conn.execute(
        "SELECT DISTINCT member_phone FROM pledges "
        "WHERE event_id=? AND is_draft=0 AND member_phone!=?",
        (event["id"], sender_phone)
    ).fetchall()
    conn.close()

    if not pledgers:
        return "No pledgers to message yet."

    sent = 0
    full_message = (
        f"📢 *{tenant['name']} — {event['event_name']}*\n\n"
        f"{message}\n\n"
        f"_{datetime.now().strftime('%d %b %Y')}_"
    )

    for p in pledgers:
        if whatsapp.send(p["member_phone"], full_message):
            sent += 1

    return f"Message sent to {sent} contributor(s)."


def broadcast_to_buyers(tenant: dict, message: str,
                         sender_phone: str) -> str:
    """Send a promo message to all recent buyers."""
    conn = get_db()
    buyers = conn.execute(
        "SELECT DISTINCT buyer_phone FROM orders "
        "WHERE tenant_id=? AND buyer_phone!=? "
        "ORDER BY created_at DESC LIMIT 500",
        (tenant["id"], sender_phone)
    ).fetchall()
    conn.close()

    if not buyers:
        return "No customers yet. Get your first sale and they'll appear here."

    sent = 0
    full_message = (
        f"🏪 *{tenant['name']}*\n\n"
        f"{message}\n\n"
        f"_Reply to order_"
    )

    for b in buyers:
        if whatsapp.send(b["buyer_phone"], full_message):
            sent += 1

    return f"Promo sent to {sent} customer(s)."


def broadcast(tenant: dict, message: str, sender_phone: str) -> str:
    """Route broadcast to correct function based on module type."""
    mod = tenant.get("module_type","")
    if mod == "SACCO":
        return broadcast_to_members(tenant, message, sender_phone)
    if mod == "GROUPS":
        return broadcast_to_pledgers(tenant, message, sender_phone)
    if mod == "RETAIL":
        return broadcast_to_buyers(tenant, message, sender_phone)
    return "Broadcast not supported for this group type."


# ═══════════════════════════════════════════════════════════════════════════════
# REMINDERS — auto-generated, contextual nudges
# ═══════════════════════════════════════════════════════════════════════════════

def remind_sacco_contributions(tenant: dict, sender_phone: str) -> str:
    """
    Send a personalised contribution reminder to every member
    who hasn't contributed this month.
    """
    from calendar import monthrange
    conn = get_db()
    now  = datetime.now()

    # Find members with no deposit this month
    members_overdue = conn.execute(
        """SELECT m.phone, m.full_name, m.savings_balance
           FROM sacco_members m
           WHERE m.tenant_id=? AND m.status='active' AND m.phone!=?
             AND NOT EXISTS (
               SELECT 1 FROM sacco_transactions t
               WHERE t.member_id=m.id AND t.type='deposit'
                 AND strftime('%Y-%m', t.created_at) = strftime('%Y-%m', 'now')
             )""",
        (tenant["id"], sender_phone)
    ).fetchall()
    conn.close()

    if not members_overdue:
        return "Everyone has contributed this month! 🎉"

    rules = _get_rules(tenant["id"])
    amount = rules["monthly_contrib_ugx"] if rules else 0
    amount_str = f"UGX {amount:,}" if amount else "your monthly contribution"

    sent = 0
    for m in members_overdue:
        msg = (
            f"Hello *{m['full_name']}* 👋\n\n"
            f"This is a friendly reminder from *{tenant['name']}*.\n\n"
            f"Your {amount_str} for {now.strftime('%B %Y')} is still pending.\n\n"
            f"Please send your contribution at your earliest convenience.\n"
            f"Your current savings: UGX {m['savings_balance']:,}"
        )
        if whatsapp.send(m["phone"], msg):
            sent += 1

    return (f"Reminder sent to {sent} member(s) who haven't contributed this month.\n"
            f"{len(members_overdue) - sent} could not be reached.")


def remind_unpaid_pledges(tenant: dict, sender_phone: str) -> str:
    """
    Send a personalised payment reminder to everyone with
    an outstanding pledge for the active event.
    """
    conn = get_db()
    event = conn.execute(
        "SELECT * FROM group_events WHERE tenant_id=? AND status='active' LIMIT 1",
        (tenant["id"],)
    ).fetchone()

    if not event:
        conn.close()
        return "No active event to send reminders for."

    unpaid = conn.execute(
        """SELECT member_phone, member_name, pledged_ugx, paid_ugx
           FROM pledges
           WHERE event_id=? AND status IN ('pledged','partial')
             AND is_draft=0 AND member_phone!=?""",
        (event["id"], sender_phone)
    ).fetchall()
    conn.close()

    if not unpaid:
        return "Everyone has cleared their pledges! 🎉"

    sent = 0
    for p in unpaid:
        balance = p["pledged_ugx"] - p["paid_ugx"]
        status  = "partially paid" if p["paid_ugx"] > 0 else "not yet paid"
        msg = (
            f"Hello *{p['member_name'] or 'there'}* 👋\n\n"
            f"Just a reminder about *{event['event_name']}*.\n\n"
            f"Your pledge: UGX {p['pledged_ugx']:,}\n"
            f"Paid so far: UGX {p['paid_ugx']:,}\n"
            f"Outstanding: *UGX {balance:,}*\n\n"
            f"Status: {status}\n\n"
            f"When you pay, reply:\n"
            f"_PAID {balance:,} [MoMo reference]_\n\n"
            f"Thank you for your contribution! 🙏"
        )
        if whatsapp.send(p["member_phone"], msg):
            sent += 1

    return (f"Payment reminder sent to {sent} contributor(s).\n"
            f"Total outstanding: {len(unpaid)} pledge(s)")


# ═══════════════════════════════════════════════════════════════════════════════
# RETAIL — pending orders
# ═══════════════════════════════════════════════════════════════════════════════

def pending_orders(tenant: dict) -> str:
    conn = get_db()
    orders = conn.execute(
        """SELECT id, buyer_phone, total_ugx, items, created_at
           FROM orders WHERE tenant_id=? AND status='pending'
           ORDER BY created_at ASC LIMIT 20""",
        (tenant["id"],)
    ).fetchall()
    conn.close()

    if not orders:
        return "No pending orders. 🎉"

    lines = []
    for o in orders:
        items = json.loads(o["items"] or "[]")
        item_summary = ", ".join(i.get("name","?") for i in items[:3])
        lines.append(
            f"Order #{o['id']} — UGX {o['total_ugx']:,}\n"
            f"  +{o['buyer_phone']} | {item_summary}\n"
            f"  {o['created_at'][:10]}"
        )

    return (f"*Pending Orders — {tenant['name']}*\n\n" +
            "\n\n".join(lines) +
            f"\n\nTo confirm payment: _APPROVE [order id]_")


# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _get_rules(tenant_id: int) -> dict:
    conn = get_db()
    row  = conn.execute("SELECT * FROM sacco_rules WHERE tenant_id=?",
                        (tenant_id,)).fetchone()
    conn.close()
    return dict(row) if row else {}


def handle_broadcast_context(text: str, phone: str,
                              tenant: dict, session: dict) -> str | None:
    """
    Called when a user is in 'awaiting_broadcast' context.
    Returns the broadcast result, or None if not in that context.
    """
    ctx = session.get("context", {})
    if ctx.get("admin_action") == "awaiting_broadcast":
        from app.services.session_store import update_context
        update_context(phone, {"admin_action": None})
        return broadcast(tenant, text, phone)
    return None
