"""
app/services/session_store.py

Manages the 2-hour session lock.
When a user triggers a keyword, they are locked into that tenant's
module for 2 hours. All their messages go to that module automatically.

Two-layer: in-memory dict (fast) + SQLite (survives restarts).
"""

import json
import sqlite3
from datetime import datetime, timedelta
from app.database import get_db

# Hot cache: phone -> session dict
_cache: dict = {}


def get(phone: str) -> dict | None:
    """Return active session for a phone number, or None if expired/missing."""
    session = _cache.get(phone)
    if session:
        if datetime.fromisoformat(session["expires_at"]) > datetime.now():
            return session
        else:
            _cache.pop(phone, None)
            return None

    # Try database fallback
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM sessions WHERE phone=? AND expires_at > datetime('now')",
        (phone,)
    ).fetchone()
    conn.close()

    if row:
        session = {
            "tenant_id":   row["tenant_id"],
            "module_type": row["module_type"],
            "context":     json.loads(row["context"] or "{}"),
            "expires_at":  row["expires_at"],
        }
        _cache[phone] = session
        return session

    return None


def create(phone: str, tenant: dict) -> dict:
    """Create or replace a session for a phone number."""
    expires_at = (datetime.now() + timedelta(hours=2)).isoformat()
    session = {
        "tenant_id":   tenant["id"],
        "module_type": tenant["module_type"],
        "context":     {},
        "expires_at":  expires_at,
        "tenant":      dict(tenant),
    }
    _cache[phone] = session

    conn = get_db()
    conn.execute("""
        INSERT INTO sessions (phone, tenant_id, module_type, context, expires_at)
        VALUES (?, ?, ?, '{}', ?)
        ON CONFLICT(phone) DO UPDATE SET
            tenant_id=excluded.tenant_id,
            module_type=excluded.module_type,
            context='{}',
            expires_at=excluded.expires_at,
            last_active=CURRENT_TIMESTAMP
    """, (phone, tenant["id"], tenant["module_type"], expires_at))
    conn.commit()
    conn.close()
    return session


def update_context(phone: str, patch: dict):
    """Merge patch into the session context and refresh expiry."""
    session = _cache.get(phone)
    if not session:
        return
    session["context"] = {**session.get("context", {}), **patch}
    session["expires_at"] = (datetime.now() + timedelta(hours=2)).isoformat()
    _cache[phone] = session

    conn = get_db()
    conn.execute(
        "UPDATE sessions SET context=?, expires_at=?, last_active=CURRENT_TIMESTAMP WHERE phone=?",
        (json.dumps(session["context"]), session["expires_at"], phone)
    )
    conn.commit()
    conn.close()


def clear(phone: str):
    """End the session for a phone number."""
    _cache.pop(phone, None)
    conn = get_db()
    conn.execute("DELETE FROM sessions WHERE phone=?", (phone,))
    conn.commit()
    conn.close()


def load_from_db():
    """Called at startup to restore active sessions into the hot cache."""
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM sessions WHERE expires_at > datetime('now')"
    ).fetchall()
    conn.close()
    for row in rows:
        _cache[row["phone"]] = {
            "tenant_id":   row["tenant_id"],
            "module_type": row["module_type"],
            "context":     json.loads(row["context"] or "{}"),
            "expires_at":  row["expires_at"],
        }
    print(f"✓ Session store: loaded {len(rows)} active sessions")
