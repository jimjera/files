"""
app/services/whatsapp.py — Multi-provider WhatsApp service

Providers:
  1. evolution  — Evolution API (free, scan QR, go live today)
  2. meta       — Meta Cloud API (official, needs business verification)
  3. twilio     — Twilio sandbox (dev/testing only)

Switch providers by changing WHATSAPP_PROVIDER in .env
or via the admin API: POST /api/admin/set-provider

All providers expose the same interface:
  send(to, body)           → send text message
  send_image(to, bytes, caption) → send image
  send_location(to, lat, lng, name) → send location
  format_phone(raw)        → normalize phone number
"""

import os, json, base64, httpx
from app.database import get_db

# ── Provider config ──────────────────────────────────────────────────────────

def _get_provider():
    """Read provider from DB setting first, then env fallback."""
    try:
        conn = get_db()
        # Check if settings table exists and has provider setting
        row = conn.execute(
            "SELECT value FROM platform_settings WHERE key='whatsapp_provider'"
        ).fetchone()
        conn.close()
        if row:
            return row["value"]
    except:
        pass
    return os.getenv("WHATSAPP_PROVIDER", "evolution")

def set_provider(provider: str) -> bool:
    """Switch WhatsApp provider. Called from admin dashboard."""
    if provider not in ("evolution", "meta", "twilio"):
        return False
    try:
        conn = get_db()
        conn.execute(
            "INSERT OR REPLACE INTO platform_settings (key, value) VALUES ('whatsapp_provider', ?)",
            (provider,))
        conn.commit()
        conn.close()
        print(f"✅ WhatsApp provider switched to: {provider}")
        return True
    except:
        return False

def get_provider_status() -> dict:
    """Get current provider info for admin dashboard."""
    provider = _get_provider()
    status = {"provider": provider, "configured": False, "details": ""}
    if provider == "evolution":
        url = os.getenv("EVOLUTION_API_URL", "http://localhost:8080")
        key = os.getenv("EVOLUTION_API_KEY", "")
        instance = os.getenv("EVOLUTION_INSTANCE", "weza")
        status["configured"] = bool(key)
        status["details"] = f"URL: {url} | Instance: {instance}"
        # Check connection
        try:
            r = httpx.get(f"{url}/instance/connectionState/{instance}",
                         headers={"apikey": key}, timeout=5)
            data = r.json()
            state = data.get("instance", {}).get("state", "unknown")
            status["connected"] = state == "open"
            status["state"] = state
        except:
            status["connected"] = False
            status["state"] = "unreachable"
    elif provider == "meta":
        status["configured"] = bool(os.getenv("WA_ACCESS_TOKEN"))
        status["details"] = f"Phone ID: {os.getenv('WA_PHONE_NUMBER_ID', 'not set')}"
        status["connected"] = status["configured"]
    elif provider == "twilio":
        status["configured"] = bool(os.getenv("TWILIO_ACCOUNT_SID"))
        status["details"] = f"From: {os.getenv('TWILIO_WHATSAPP_NUMBER', 'not set')}"
        status["connected"] = status["configured"]
    return status


# ── Evolution API config ─────────────────────────────────────────────────────

EVO_URL      = os.getenv("EVOLUTION_API_URL", "http://localhost:8080")
EVO_KEY      = os.getenv("EVOLUTION_API_KEY", "")
EVO_INSTANCE = os.getenv("EVOLUTION_INSTANCE", "weza")

# ── Meta Cloud API config ────────────────────────────────────────────────────

META_TOKEN    = os.getenv("WA_ACCESS_TOKEN", "")
META_PHONE_ID = os.getenv("WA_PHONE_NUMBER_ID", "")
META_API      = "https://graph.facebook.com/v21.0"

# ── Twilio config ────────────────────────────────────────────────────────────

TWILIO_SID    = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_TOKEN  = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM   = os.getenv("TWILIO_WHATSAPP_NUMBER", "whatsapp:+14155238886")
_twilio_client = None


# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC API — same interface regardless of provider
# ═══════════════════════════════════════════════════════════════════════════════

def send(to: str, body: str) -> bool:
    """Send a text message via the active provider."""
    if not to or not body:
        return False
    phone = format_phone(to)
    print(f"\n📱 [{_get_provider()}] → +{phone}: {body[:100]}{'...' if len(body)>100 else ''}")

    provider = _get_provider()
    if provider == "evolution":
        return _evo_send_text(phone, body)
    elif provider == "meta":
        return _meta_send_text(phone, body)
    elif provider == "twilio":
        return _twilio_send(phone, body)
    print(f"   ⚠️ Unknown provider: {provider}")
    return False


def send_image(to: str, image_bytes: bytes, caption: str = "") -> bool:
    """Send an image message via the active provider."""
    if not to:
        return False
    phone = format_phone(to)
    print(f"\n🖼️ [{_get_provider()}] → +{phone}: [image] {caption[:60]}")

    provider = _get_provider()
    if provider == "evolution":
        return _evo_send_image(phone, image_bytes, caption)
    elif provider == "meta":
        return _meta_send_image(phone, image_bytes, caption)
    # Twilio fallback — send caption as text
    if caption:
        return send(to, caption)
    return True


def send_location(to: str, lat: float, lng: float, name: str = "") -> bool:
    """Send a location pin."""
    phone = format_phone(to)
    provider = _get_provider()
    if provider == "evolution":
        return _evo_send_location(phone, lat, lng, name)
    elif provider == "meta":
        return _meta_send_location(phone, lat, lng, name)
    return send(to, f"📍 Location: {name} ({lat}, {lng})")


def send_interactive(to: str, body_text: str, buttons: list) -> bool:
    """Send interactive button message (Meta only, others fall back to text)."""
    provider = _get_provider()
    if provider == "meta" and META_TOKEN and META_PHONE_ID:
        return _meta_send_interactive(format_phone(to), body_text, buttons)
    # Evolution and Twilio: fall back to text with numbered options
    btn_text = "\n".join(f"{i+1}. {b['title']}" for i, b in enumerate(buttons))
    return send(to, f"{body_text}\n\n{btn_text}")


def format_phone(raw: str) -> str:
    """Normalize phone number to digits only."""
    digits = "".join(c for c in str(raw) if c.isdigit())
    # Remove whatsapp: prefix artifacts
    if digits.startswith("1415") and len(digits) > 12:
        return digits
    return digits


# ═══════════════════════════════════════════════════════════════════════════════
# EVOLUTION API PROVIDER
# ═══════════════════════════════════════════════════════════════════════════════

def _evo_headers():
    return {"apikey": EVO_KEY, "Content-Type": "application/json"}

def _evo_send_text(phone, body):
    try:
        r = httpx.post(
            f"{EVO_URL}/message/sendText/{EVO_INSTANCE}",
            headers=_evo_headers(),
            json={"number": phone, "text": body},
            timeout=15
        )
        data = r.json()
        if data.get("key") or data.get("status") == "PENDING":
            print(f"   ✓ Evolution sent")
            return True
        print(f"   ✗ Evolution: {data}")
        return False
    except Exception as e:
        print(f"   ✗ Evolution error: {e}")
        return False

def _evo_send_image(phone, image_bytes, caption):
    try:
        b64 = base64.b64encode(image_bytes).decode()
        r = httpx.post(
            f"{EVO_URL}/message/sendMedia/{EVO_INSTANCE}",
            headers=_evo_headers(),
            json={
                "number": phone,
                "mediatype": "image",
                "mimetype": "image/png",
                "media": f"data:image/png;base64,{b64}",
                "caption": caption or "",
            },
            timeout=30
        )
        return bool(r.json().get("key"))
    except Exception as e:
        print(f"   ✗ Evolution image error: {e}")
        # Fallback to text
        if caption:
            return _evo_send_text(phone, caption)
        return False

def _evo_send_location(phone, lat, lng, name):
    try:
        r = httpx.post(
            f"{EVO_URL}/message/sendLocation/{EVO_INSTANCE}",
            headers=_evo_headers(),
            json={
                "number": phone,
                "name": name or "Location",
                "address": name or "",
                "latitude": lat,
                "longitude": lng,
            },
            timeout=10
        )
        return bool(r.json().get("key"))
    except:
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# META CLOUD API PROVIDER
# ═══════════════════════════════════════════════════════════════════════════════

def _meta_headers():
    return {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}

def _meta_send_text(phone, body):
    if not META_TOKEN or not META_PHONE_ID:
        print("   [Meta not configured — printed only]")
        return True
    try:
        r = httpx.post(
            f"{META_API}/{META_PHONE_ID}/messages",
            headers=_meta_headers(),
            json={"messaging_product": "whatsapp", "to": phone,
                  "type": "text", "text": {"body": body}},
            timeout=10
        )
        return "messages" in r.json()
    except Exception as e:
        print(f"   ✗ Meta: {e}")
        return False

def _meta_send_image(phone, image_bytes, caption):
    if not META_TOKEN or not META_PHONE_ID:
        return _meta_send_text(phone, caption) if caption else True
    try:
        # Upload media first
        r = httpx.post(
            f"{META_API}/{META_PHONE_ID}/media",
            headers={"Authorization": f"Bearer {META_TOKEN}"},
            files={"file": ("card.png", image_bytes, "image/png")},
            data={"messaging_product": "whatsapp"},
            timeout=30
        )
        media_id = r.json().get("id")
        if not media_id:
            return _meta_send_text(phone, caption) if caption else False
        body = {"messaging_product": "whatsapp", "to": phone,
                "type": "image", "image": {"id": media_id}}
        if caption:
            body["image"]["caption"] = caption
        r2 = httpx.post(f"{META_API}/{META_PHONE_ID}/messages",
                        headers=_meta_headers(), json=body, timeout=10)
        return "messages" in r2.json()
    except:
        return _meta_send_text(phone, caption) if caption else False

def _meta_send_location(phone, lat, lng, name):
    try:
        r = httpx.post(
            f"{META_API}/{META_PHONE_ID}/messages",
            headers=_meta_headers(),
            json={"messaging_product": "whatsapp", "to": phone,
                  "type": "location",
                  "location": {"latitude": lat, "longitude": lng, "name": name}},
            timeout=10
        )
        return "messages" in r.json()
    except:
        return False

def _meta_send_interactive(phone, body_text, buttons):
    btn_list = [{"type": "reply", "reply": {"id": b["id"], "title": b["title"][:20]}}
                for b in buttons[:3]]
    try:
        r = httpx.post(
            f"{META_API}/{META_PHONE_ID}/messages",
            headers=_meta_headers(),
            json={"messaging_product": "whatsapp", "to": phone,
                  "type": "interactive",
                  "interactive": {"type": "button", "body": {"text": body_text},
                                  "action": {"buttons": btn_list}}},
            timeout=10
        )
        return "messages" in r.json()
    except:
        return _meta_send_text(phone, body_text)


# ═══════════════════════════════════════════════════════════════════════════════
# TWILIO PROVIDER
# ═══════════════════════════════════════════════════════════════════════════════

def _get_twilio():
    global _twilio_client
    if not _twilio_client and TWILIO_SID and TWILIO_TOKEN:
        from twilio.rest import Client
        _twilio_client = Client(TWILIO_SID, TWILIO_TOKEN)
    return _twilio_client

def _twilio_send(phone, body):
    to_wa = f"whatsapp:+{phone.lstrip('+')}"
    client = _get_twilio()
    if not client:
        print("   [Twilio not configured — printed only]")
        return True
    try:
        msg = client.messages.create(body=body, from_=TWILIO_FROM, to=to_wa)
        print(f"   ✓ Twilio: {msg.sid}")
        return True
    except Exception as e:
        print(f"   ✗ Twilio: {e}")
        return False
