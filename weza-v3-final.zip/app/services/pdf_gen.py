"""
app/services/pdf_gen.py

Generates PDF documents using ReportLab.
Returns a bytes object that can be sent as a WhatsApp attachment
or downloaded from the admin panel.
"""

import io
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT

TEAL   = colors.HexColor("#0F6E56")
PURPLE = colors.HexColor("#534AB7")
GRAY   = colors.HexColor("#F5F5F5")
DGRAY  = colors.HexColor("#333333")


def _base_doc(buffer, title="Weza Document"):
    return SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=2*cm, bottomMargin=2*cm,
        leftMargin=2*cm, rightMargin=2*cm,
        title=title
    )


def _styles():
    s = getSampleStyleSheet()
    s.add(ParagraphStyle("brand",   fontSize=22, textColor=TEAL,   fontName="Helvetica-Bold", alignment=TA_CENTER))
    s.add(ParagraphStyle("h1",      fontSize=14, textColor=DGRAY,  fontName="Helvetica-Bold", spaceAfter=6))
    s.add(ParagraphStyle("body",    fontSize=10, textColor=DGRAY,  fontName="Helvetica",      spaceAfter=4))
    s.add(ParagraphStyle("small",   fontSize=8,  textColor=colors.grey, fontName="Helvetica"))
    s.add(ParagraphStyle("right",   fontSize=10, textColor=DGRAY,  fontName="Helvetica",      alignment=TA_RIGHT))
    s.add(ParagraphStyle("center",  fontSize=10, textColor=DGRAY,  fontName="Helvetica",      alignment=TA_CENTER))
    return s


def _header(story, s, tenant_name: str, doc_title: str):
    story.append(Paragraph("Weza", s["brand"]))
    story.append(Paragraph(tenant_name, s["center"]))
    story.append(Spacer(1, 0.3*cm))
    story.append(HRFlowable(width="100%", thickness=2, color=TEAL))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(doc_title, s["h1"]))
    story.append(Paragraph(
        f"Generated: {datetime.now().strftime('%d %B %Y, %I:%M %p')}",
        s["small"]
    ))
    story.append(Spacer(1, 0.5*cm))


def _table_style(header_color=TEAL):
    return TableStyle([
        ("BACKGROUND",  (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR",   (0, 0), (-1, 0), colors.white),
        ("FONTNAME",    (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",    (0, 0), (-1, 0), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRAY]),
        ("FONTSIZE",    (0, 1), (-1, -1), 9),
        ("GRID",        (0, 0), (-1, -1), 0.3, colors.HexColor("#DDDDDD")),
        ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING",  (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ])


# ── 1. Loan Agreement ─────────────────────────────────────────────────────────

def loan_agreement(tenant: dict, member: dict, loan: dict, guarantors: list) -> bytes:
    buf = io.BytesIO()
    doc = _base_doc(buf, "Loan Agreement")
    s   = _styles()
    story = []

    _header(story, s, tenant["name"], "LOAN AGREEMENT")

    # Parties
    story.append(Paragraph("BORROWER DETAILS", s["h1"]))
    data = [
        ["Full Name",      member["full_name"]],
        ["Phone Number",   f"+{member['phone']}"],
        ["Member Number",  member.get("member_number", "—")],
        ["Savings Balance", f"UGX {member['savings_balance']:,}"],
    ]
    for row in data:
        story.append(Table([row], colWidths=[6*cm, 10*cm], style=TableStyle([
            ("FONTNAME", (0,0),(0,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0),(-1,-1), 10),
            ("BOTTOMPADDING",(0,0),(-1,-1),4),
        ])))
    story.append(Spacer(1, 0.4*cm))

    # Loan terms
    story.append(Paragraph("LOAN TERMS", s["h1"]))
    monthly = loan.get("monthly_payment", 0)
    total   = loan["principal_ugx"] + int(loan["principal_ugx"] * loan["interest_rate"] / 100 * loan["term_months"])
    terms = [
        ["Loan Amount",        f"UGX {loan['principal_ugx']:,}"],
        ["Interest Rate",      f"{loan['interest_rate']}% per month (flat)"],
        ["Loan Term",          f"{loan['term_months']} months"],
        ["Monthly Repayment",  f"UGX {monthly:,}"],
        ["Total Repayment",    f"UGX {total:,}"],
        ["Application Date",   datetime.now().strftime("%d %B %Y")],
    ]
    story.append(Table(
        [["Item", "Detail"]] + terms,
        colWidths=[7*cm, 9*cm],
        style=_table_style()
    ))
    story.append(Spacer(1, 0.4*cm))

    # Guarantors
    if guarantors:
        story.append(Paragraph("GUARANTORS", s["h1"]))
        g_data = [["Name", "Phone", "Status"]]
        for g in guarantors:
            g_data.append([g.get("name","—"), f"+{g.get('phone','—')}", "Confirmed"])
        story.append(Table(g_data, colWidths=[6*cm, 5*cm, 5*cm], style=_table_style()))
        story.append(Spacer(1, 0.4*cm))

    # Terms
    story.append(Paragraph("TERMS & CONDITIONS", s["h1"]))
    for term in [
        "The borrower agrees to repay the loan in equal monthly instalments as stated above.",
        "Failure to repay on time will trigger the late payment penalty as per the SACCO constitution.",
        "In the event of default, guarantors may be required to cover the outstanding balance.",
        "This agreement is governed by the rules of " + tenant["name"] + ".",
    ]:
        story.append(Paragraph(f"• {term}", s["body"]))
    story.append(Spacer(1, 0.8*cm))

    # Signatures
    story.append(Paragraph("SIGNATURES", s["h1"]))
    sig = Table(
        [["Borrower Signature", "Treasurer Signature"],
         ["________________________", "________________________"],
         ["Date: _______________", "Date: _______________"]],
        colWidths=[8*cm, 8*cm],
        style=TableStyle([
            ("FONTSIZE", (0,0),(-1,-1), 9),
            ("TOPPADDING",(0,0),(-1,-1), 8),
        ])
    )
    story.append(sig)

    # Ref
    story.append(Spacer(1, 1*cm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.grey))
    story.append(Paragraph(f"Document Ref: LOAN-{loan.get('id','XXX')}-{tenant['id']} | Weza Platform", s["small"]))

    doc.build(story)
    return buf.getvalue()


# ── 2. Member Statement ───────────────────────────────────────────────────────

def member_statement(tenant: dict, member: dict, transactions: list) -> bytes:
    buf   = io.BytesIO()
    doc   = _base_doc(buf, "Member Statement")
    s     = _styles()
    story = []

    _header(story, s, tenant["name"], "MEMBER ACCOUNT STATEMENT")

    story.append(Paragraph(f"Member: {member['full_name']}  |  Phone: +{member['phone']}", s["body"]))
    story.append(Paragraph(
        f"Savings Balance: UGX {member['savings_balance']:,}  |  Loan Balance: UGX {member['loan_balance']:,}",
        s["body"]
    ))
    story.append(Spacer(1, 0.4*cm))

    rows = [["Date", "Type", "Amount (UGX)", "Balance After"]]
    for t in transactions:
        rows.append([
            t["created_at"][:10],
            t["type"].replace("_", " ").title(),
            f"{t['amount_ugx']:,}",
            f"{t['balance_after']:,}",
        ])

    story.append(Table(rows, colWidths=[3*cm, 5*cm, 5*cm, 4*cm], style=_table_style()))
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.grey))
    story.append(Paragraph("Weza Platform — Confidential Member Record", s["small"]))

    doc.build(story)
    return buf.getvalue()


# ── 3. Group Constitution ─────────────────────────────────────────────────────

def group_constitution(tenant: dict, rules: dict) -> bytes:
    buf   = io.BytesIO()
    doc   = _base_doc(buf, "SACCO Constitution")
    s     = _styles()
    story = []

    _header(story, s, tenant["name"], "SACCO CONSTITUTION & RULES")
    story.append(Paragraph(
        f"This document records the rules of {tenant['name']} as confirmed by the administrator "
        f"on {datetime.now().strftime('%d %B %Y')}.",
        s["body"]
    ))
    story.append(Spacer(1, 0.4*cm))

    rule_rows = [["Rule", "Value"]]
    rule_map = {
        "monthly_contrib_ugx": ("Monthly Contribution", lambda v: f"UGX {v:,}"),
        "contrib_day":         ("Contribution Day",     str),
        "grace_days":          ("Grace Period",         lambda v: f"{v} days"),
        "late_penalty_ugx":    ("Late Penalty",         lambda v: f"UGX {v:,}"),
        "loan_multiplier":     ("Loan Limit",           lambda v: f"{v}× savings balance"),
        "interest_rate":       ("Interest Rate",        lambda v: f"{v}% per month (flat)"),
        "loan_term_months":    ("Default Loan Term",    lambda v: f"{v} months"),
        "approvers_required":  ("Loan Approvers",       str),
        "exit_policy":         ("Member Exit Policy",   str),
    }
    for key, (label, fmt) in rule_map.items():
        val = rules.get(key)
        if val:
            rule_rows.append([label, fmt(val)])

    story.append(Table(rule_rows, colWidths=[8*cm, 8*cm], style=_table_style()))
    story.append(Spacer(1, 0.8*cm))
    story.append(Paragraph("ADMINISTRATOR CONFIRMATION", s["h1"]))
    story.append(Paragraph("By adding the Weza assistant to the group, the administrator confirms that these rules accurately reflect how the group operates.", s["body"]))
    story.append(Spacer(1, 1*cm))
    story.append(Table(
        [["Administrator Name", "Signature", "Date"],
         ["________________________", "________________________", datetime.now().strftime("%d/%m/%Y")]],
        colWidths=[6*cm, 6*cm, 5*cm],
        style=TableStyle([("FONTSIZE",(0,0),(-1,-1),9),("TOPPADDING",(0,0),(-1,-1),8)])
    ))

    doc.build(story)
    return buf.getvalue()


# ── 4. Transparency Report ────────────────────────────────────────────────────

def transparency_report(tenant: dict, event: dict, pledges: list) -> bytes:
    buf   = io.BytesIO()
    doc   = _base_doc(buf, "Transparency Report")
    s     = _styles()
    story = []

    _header(story, s, tenant["name"], f"TRANSPARENCY REPORT — {event['event_name'].upper()}")

    pct = int((event["collected_total"] / event["target_budget"] * 100)) if event["target_budget"] else 0
    story.append(Table(
        [["Budget Target", "Collected", "Remaining", "Progress"],
         [f"UGX {event['target_budget']:,}", f"UGX {event['collected_total']:,}",
          f"UGX {max(0, event['target_budget']-event['collected_total']):,}", f"{pct}%"]],
        colWidths=[4*cm, 4*cm, 4*cm, 4*cm],
        style=_table_style(PURPLE)
    ))
    story.append(Spacer(1, 0.5*cm))

    rows = [["Member", "Phone", "Pledged", "Paid", "Balance", "Status"]]
    for p in pledges:
        bal = p["pledged_ugx"] - p["paid_ugx"]
        rows.append([
            p["member_name"] or "—",
            f"+{p['member_phone']}",
            f"{p['pledged_ugx']:,}",
            f"{p['paid_ugx']:,}",
            f"{bal:,}",
            p["status"].upper(),
        ])

    story.append(Table(rows, colWidths=[4*cm, 3.5*cm, 2.5*cm, 2.5*cm, 2.5*cm, 2*cm], style=_table_style()))
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.grey))
    story.append(Paragraph(f"Weza — {tenant['name']} | Report ID: RPT-{event['id']}-{datetime.now().strftime('%Y%m%d')}", s["small"]))

    doc.build(story)
    return buf.getvalue()
