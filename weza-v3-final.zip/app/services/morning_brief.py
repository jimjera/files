"""
app/services/morning_brief.py — Daily reports for treasurers AND sellers
Also handles member contribution reminders.
All zero AI cost — database queries + templates.
"""
from datetime import datetime, timedelta
from app.database import get_db
from app.services import whatsapp

def send_sacco_brief(tenant_id):
    conn = get_db()
    t = conn.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
    if not t: conn.close(); return
    t = dict(t)
    stats = conn.execute(
        "SELECT COUNT(*) members, COALESCE(SUM(savings_balance),0) savings, COALESCE(SUM(loan_balance),0) loans "
        "FROM sacco_members WHERE tenant_id=? AND status='active'", (tenant_id,)).fetchone()
    yesterday = conn.execute(
        "SELECT COALESCE(SUM(amount_ugx),0) amt, COUNT(*) cnt FROM sacco_transactions "
        "WHERE tenant_id=? AND type IN ('deposit','cash_deposit') AND created_at >= date('now','-1 day')",
        (tenant_id,)).fetchone()
    pending = conn.execute("SELECT COUNT(*) n FROM deposit_queue WHERE tenant_id=? AND status='pending'",
                           (tenant_id,)).fetchone()["n"]
    pending_loans = conn.execute("SELECT COUNT(*) n FROM sacco_loans WHERE tenant_id=? AND status='pending'",
                                 (tenant_id,)).fetchone()["n"]
    conn.close()

    admins = _get_admins(tenant_id)
    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  ☀️ {t['name']}\n"
           f"  Daily Brief — {datetime.now().strftime('%a %d %b')}\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
           f"👥 Members: {stats['members']}\n"
           f"💰 Total savings: UGX {int(stats['savings']):,}\n"
           f"💳 Loans outstanding: UGX {int(stats['loans']):,}\n\n"
           f"📊 Yesterday:\n"
           f"   {yesterday['cnt']} deposits · UGX {int(yesterday['amt']):,}\n\n"
           f"⏳ Pending: {pending} deposits, {pending_loans} loan applications\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━")
    for a in admins:
        whatsapp.send(a, msg)

def send_retail_brief(tenant_id):
    conn = get_db()
    t = conn.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
    if not t: conn.close(); return
    t = dict(t)
    yesterday_sales = conn.execute(
        "SELECT COUNT(*) cnt, COALESCE(SUM(total_ugx),0) rev FROM orders "
        "WHERE tenant_id=? AND status='completed' AND created_at >= date('now','-1 day')",
        (tenant_id,)).fetchone()
    leads = conn.execute(
        "SELECT COUNT(*) n FROM leads WHERE tenant_id=? AND created_at >= date('now','-1 day')",
        (tenant_id,)).fetchone()["n"]
    products = conn.execute(
        "SELECT name, price_ugx, stock_qty, image_id FROM products "
        "WHERE tenant_id=? AND is_available=1 ORDER BY added_at DESC",
        (tenant_id,)).fetchall()
    week_sales = conn.execute(
        "SELECT COUNT(*) cnt, COALESCE(SUM(total_ugx),0) rev FROM orders "
        "WHERE tenant_id=? AND status='completed' AND created_at >= date('now','-7 day')",
        (tenant_id,)).fetchone()
    conn.close()

    prod_lines = []
    for p in products[:8]:
        p = dict(p)
        status = "✅" if p.get("image_id") else "⚠️"
        stock_warn = f" _(low: {p['stock_qty']} left)_" if p.get("stock_qty",0) > 0 and p["stock_qty"] <= 5 else ""
        prod_lines.append(f"   {status} {p['name']:20} {p['price_ugx']:>10,}{stock_warn}")

    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  ☀️ {t['name']}\n"
           f"  Daily Report — {datetime.now().strftime('%a %d %b')}\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
           f"📊 YESTERDAY\n"
           f"   Leads received:  {leads}\n"
           f"   Sales recorded:  {yesterday_sales['cnt']}\n"
           f"   Revenue:         UGX {int(yesterday_sales['rev']):,}\n\n"
           f"📦 YOUR PRODUCTS ({len(products)} listed)\n"
           + "\n".join(prod_lines) + "\n\n"
           f"📈 THIS WEEK\n"
           f"   Sales: {week_sales['cnt']} · UGX {int(week_sales['rev']):,}\n\n")

    no_photo = sum(1 for p in products if not dict(p).get("image_id"))
    if no_photo:
        msg += f"💡 TIP: {no_photo} products have no photo.\n   Products with photos get 3× more views!\n\n"
    msg += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n   STOCK · SALES · ADD · HELP\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    whatsapp.send(t["owner_phone"], msg)

def send_member_reminders(tenant_id):
    """Send contribution reminders to members who haven't paid this cycle."""
    conn = get_db()
    t = conn.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
    if not t: conn.close(); return
    t = dict(t)
    rules = conn.execute("SELECT * FROM sacco_rules WHERE tenant_id=?", (tenant_id,)).fetchone()
    if not rules: conn.close(); return
    rules = dict(rules)
    if rules["monthly_contrib_ugx"] <= 0: conn.close(); return

    # Get members who haven't deposited this month
    members = conn.execute(
        """SELECT m.phone, m.full_name, m.savings_balance FROM sacco_members m
           WHERE m.tenant_id=? AND m.status='active'
           AND m.id NOT IN (
               SELECT member_id FROM sacco_transactions
               WHERE tenant_id=? AND type IN ('deposit','cash_deposit')
               AND created_at >= date('now','start of month')
           )""", (tenant_id, tenant_id)).fetchall()
    conn.close()

    for m in members:
        m = dict(m)
        msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
               f"  📅 Contribution Reminder\n"
               f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
               f"Hi {m['full_name'].split()[0]}!\n"
               f"Your monthly contribution of\n"
               f"UGX {rules['monthly_contrib_ugx']:,} to *{t['name']}*\n"
               f"is due ({rules['contrib_day']}).\n\n"
               f"Your savings: UGX {m['savings_balance']:,}\n\n"
               f"Pay to: {t['momo_network']} {t['momo_number']}\n"
               f"Then send the confirmation here.\n"
               f"━━━━━━━━━━━━━━━━━━━━━━━━━")
        whatsapp.send(m["phone"], msg)

def send_all():
    """Send all daily briefs. Called by cron."""
    conn = get_db()
    tenants = conn.execute("SELECT id, module_type FROM tenants WHERE is_active=1").fetchall()
    conn.close()
    for t in tenants:
        t = dict(t)
        try:
            if t["module_type"] == "SACCO":
                send_sacco_brief(t["id"])
                send_member_reminders(t["id"])
            elif t["module_type"] == "RETAIL":
                send_retail_brief(t["id"])
        except Exception as e:
            print(f"Brief error for tenant {t['id']}: {e}")

def _get_admins(tenant_id):
    conn = get_db()
    rows = conn.execute("SELECT phone FROM tenant_admins WHERE tenant_id=?", (tenant_id,)).fetchall()
    conn.close()
    return [r["phone"] for r in rows]
