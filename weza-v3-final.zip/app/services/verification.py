"""
app/services/verification.py — Shop verification (Blue Tick ✅)
Zero AI cost — MoMo regex + location storage
"""
from app.database import get_db
from app.services.weza_ai import read_momo_text
from datetime import datetime

VERIFY_FEE = 10000  # UGX
WEZA_MOMO = "0771234567"

def get_verify_prompt():
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ Get Verified\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"The *Verified Badge* ✅ means:\n"
            f"• Appear first in search results\n"
            f"• Trusted badge on your shop\n"
            f"• Professional Status cards daily\n"
            f"• Beautiful web shop page\n\n"
            f"Cost: UGX {VERIFY_FEE:,} (one-time)\n"
            f"Pay to: MTN MoMo {WEZA_MOMO} (Weza)\n\n"
            f"Send the MoMo confirmation to start.\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def process_verification_payment(text, tenant_id):
    momo = read_momo_text(text)
    if not momo or momo.get("amount",0) < VERIFY_FEE:
        return None
    conn = get_db()
    conn.execute("INSERT INTO verifications (tenant_id,type,status,payment_ref,amount_paid) VALUES (?,'shop_verify','payment_received',?,?)",
                 (tenant_id, momo["transactionId"], momo["amount"]))
    conn.commit()
    conn.close()
    return {"ref": momo["transactionId"], "amount": momo["amount"]}

def save_location(tenant_id, lat, lng, name=""):
    conn = get_db()
    conn.execute("UPDATE tenants SET latitude=?, longitude=?, location=? WHERE id=?",
                 (lat, lng, name or "Verified location", tenant_id))
    conn.commit()
    conn.close()

def complete_verification(tenant_id):
    conn = get_db()
    conn.execute("UPDATE tenants SET is_verified=1, verified_at=? WHERE id=?",
                 (datetime.now().isoformat(), tenant_id))
    conn.execute("UPDATE verifications SET status='approved' WHERE tenant_id=? AND type='shop_verify'",
                 (tenant_id,))
    conn.commit()
    conn.close()
    return True

def get_verification_status(tenant_id):
    conn = get_db()
    v = conn.execute("SELECT * FROM verifications WHERE tenant_id=? AND type='shop_verify' ORDER BY created_at DESC LIMIT 1",
                     (tenant_id,)).fetchone()
    t = conn.execute("SELECT is_verified, latitude, longitude FROM tenants WHERE id=?",
                     (tenant_id,)).fetchone()
    conn.close()
    if not v:
        return {"step": "not_started"}
    v = dict(v)
    has_payment = v["status"] in ("payment_received","approved")
    has_location = t["latitude"] is not None if t else False
    if has_payment and has_location:
        return {"step": "ready_to_complete"}
    elif has_payment:
        return {"step": "needs_location"}
    return {"step": "needs_payment"}
