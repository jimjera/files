"""
app/services/status_cards.py — Generate WhatsApp Status product cards
Uses Pillow for image generation. ZERO AI cost.
"""
import os, io
from PIL import Image, ImageDraw, ImageFont
from app.database import get_db

CARD_W, CARD_H = 1080, 1920
WEZA_NUMBER = os.getenv("WEZA_WA_NUMBER", "256XXXXXXXXX")

# Colors by category
THEMES = {
    "Fashion":    {"bg": "#1a0a2e", "accent": "#e91e8c", "text": "#ffffff"},
    "Hardware":   {"bg": "#0f1729", "accent": "#f97316", "text": "#ffffff"},
    "Food":       {"bg": "#0d2818", "accent": "#22c55e", "text": "#ffffff"},
    "Electronics":{"bg": "#0c1220", "accent": "#3b82f6", "text": "#ffffff"},
    "General":    {"bg": "#0f172a", "accent": "#059669", "text": "#ffffff"},
}

def _hex(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i+2],16) for i in (0,2,4))

def _get_font(size, bold=False):
    """Try to load a nice font, fall back to default."""
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    try:
        return ImageFont.truetype("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf", size)
    except:
        return ImageFont.load_default()

def generate_hero_card(product: dict, shop: dict) -> bytes:
    """Generate a single product hero card for WhatsApp Status."""
    cat = product.get("category", "General")
    theme = THEMES.get(cat, THEMES["General"])
    bg_color = _hex(theme["bg"])
    accent = _hex(theme["accent"])
    white = _hex(theme["text"])
    gray = (180, 180, 180)

    img = Image.new("RGB", (CARD_W, CARD_H), bg_color)
    draw = ImageDraw.Draw(img)

    # If product has an image, load it as background (top 60%)
    # For now, draw a styled pattern
    # Diagonal accent stripes
    for i in range(-CARD_H, CARD_W + CARD_H, 120):
        draw.line([(i, 0), (i + CARD_H//2, CARD_H//2)], fill=(*accent, 30) if len(accent)==3 else accent, width=2)

    # Large circle decoration
    draw.ellipse([CARD_W//2-300, 200, CARD_W//2+300, 800], outline=(*accent,), width=3)

    # Category icon (centered in circle)
    icons = {"Fashion":"👗","Hardware":"🔨","Food":"🍞","Electronics":"⚡","General":"🛒"}
    icon = icons.get(cat, "🛒")
    icon_font = _get_font(120)
    try:
        draw.text((CARD_W//2, 480), icon, font=icon_font, anchor="mm")
    except:
        draw.text((CARD_W//2 - 60, 420), icon, font=icon_font)

    # Product name
    name_font = _get_font(72, bold=True)
    name = product.get("name", "Product").upper()
    try:
        draw.text((CARD_W//2, 950), name, fill=white, font=name_font, anchor="mm")
    except:
        draw.text((80, 920), name, fill=white, font=name_font)

    # Price
    price_font = _get_font(96, bold=True)
    price = f"UGX {product.get('price_ugx', 0):,}"
    try:
        draw.text((CARD_W//2, 1080), price, fill=accent, font=price_font, anchor="mm")
    except:
        draw.text((80, 1040), price, fill=accent, font=price_font)

    # Shop name + location
    shop_font = _get_font(36)
    verified = " ✅" if shop.get("is_verified") else ""
    shop_text = f"{shop.get('name','Shop')}{verified}"
    try:
        draw.text((CARD_W//2, 1220), shop_text, fill=white, font=shop_font, anchor="mm")
    except:
        draw.text((80, 1200), shop_text, fill=white, font=shop_font)

    loc = shop.get("location", "")
    if loc:
        loc_font = _get_font(30)
        try:
            draw.text((CARD_W//2, 1270), f"📍 {loc}", fill=gray, font=loc_font, anchor="mm")
        except:
            draw.text((80, 1250), f"📍 {loc}", fill=gray, font=loc_font)

    # Bottom bar — deep link
    bar_y = CARD_H - 280
    draw.rectangle([0, bar_y, CARD_W, CARD_H], fill=_hex("#111827"))

    # Green button area
    btn_pad = 60
    draw.rounded_rectangle([btn_pad, bar_y+40, CARD_W-btn_pad, bar_y+140],
                           radius=25, fill=accent)
    btn_font = _get_font(32, bold=True)
    keyword = shop.get("keyword", "SHOP")
    try:
        draw.text((CARD_W//2, bar_y+90), f"🛒 See full catalog", fill=white, font=btn_font, anchor="mm")
    except:
        draw.text((btn_pad+40, bar_y+60), f"🛒 See full catalog", fill=white, font=btn_font)

    link_font = _get_font(26)
    link = f"wa.me/{WEZA_NUMBER}?text=Shop%20{keyword}"
    try:
        draw.text((CARD_W//2, bar_y+180), link, fill=gray, font=link_font, anchor="mm")
    except:
        draw.text((80, bar_y+170), link, fill=gray, font=link_font)

    # Weza watermark
    wm_font = _get_font(22)
    try:
        draw.text((CARD_W//2, CARD_H-30), "── WEZA ──", fill=(100,100,100), font=wm_font, anchor="mm")
    except:
        pass

    buf = io.BytesIO()
    img.save(buf, "PNG", quality=90)
    return buf.getvalue()

def generate_grid_card(products: list, shop: dict) -> bytes:
    """Generate a 2x2 grid card showing multiple products."""
    theme = THEMES.get("General")
    bg = _hex(theme["bg"])
    accent = _hex(theme["accent"])
    white = (255,255,255)
    gray = (180,180,180)

    img = Image.new("RGB", (CARD_W, CARD_H), bg)
    draw = ImageDraw.Draw(img)

    # Shop header
    hdr_font = _get_font(48, bold=True)
    verified = " ✅" if shop.get("is_verified") else ""
    try:
        draw.text((CARD_W//2, 100), f"{shop['name']}{verified}", fill=white, font=hdr_font, anchor="mm")
    except:
        draw.text((60, 70), f"{shop['name']}{verified}", fill=white, font=hdr_font)

    loc_font = _get_font(28)
    if shop.get("location"):
        try:
            draw.text((CARD_W//2, 160), f"📍 {shop['location']}", fill=gray, font=loc_font, anchor="mm")
        except:
            pass

    # 2x2 grid of products
    grid_top = 220
    cell_w, cell_h = 480, 520
    gap = 40
    start_x = (CARD_W - 2*cell_w - gap) // 2

    for i, p in enumerate(products[:4]):
        col, row = i % 2, i // 2
        x = start_x + col * (cell_w + gap)
        y = grid_top + row * (cell_h + gap)

        # Card background
        draw.rounded_rectangle([x, y, x+cell_w, y+cell_h], radius=20, fill=_hex("#1e293b"))

        # Product icon
        icons = {"Fashion":"👗","Hardware":"🔨","Food":"🍞","Electronics":"⚡"}
        icon = icons.get(p.get("category",""), "📦")
        icon_f = _get_font(60)
        try:
            draw.text((x + cell_w//2, y + 120), icon, font=icon_f, anchor="mm")
        except:
            draw.text((x+cell_w//2-30, y+90), icon, font=icon_f)

        # Product name
        n_font = _get_font(32, bold=True)
        pname = p.get("name","")[:20]
        try:
            draw.text((x + cell_w//2, y + 280), pname, fill=white, font=n_font, anchor="mm")
        except:
            draw.text((x+20, y+260), pname, fill=white, font=n_font)

        # Price
        p_font = _get_font(36, bold=True)
        price = f"UGX {p.get('price_ugx',0):,}"
        try:
            draw.text((x + cell_w//2, y + 350), price, fill=accent, font=p_font, anchor="mm")
        except:
            draw.text((x+20, y+330), price, fill=accent, font=p_font)

        # Unit
        u_font = _get_font(24)
        if p.get("unit"):
            try:
                draw.text((x + cell_w//2, y + 410), f"per {p['unit']}", fill=gray, font=u_font, anchor="mm")
            except:
                pass

    # Bottom bar with link
    bar_y = CARD_H - 280
    draw.rectangle([0, bar_y, CARD_W, CARD_H], fill=_hex("#111827"))
    btn_font = _get_font(32, bold=True)
    keyword = shop.get("keyword","SHOP")
    draw.rounded_rectangle([60, bar_y+40, CARD_W-60, bar_y+140], radius=25, fill=accent)
    try:
        draw.text((CARD_W//2, bar_y+90), "🛒 See full catalog", fill=white, font=btn_font, anchor="mm")
    except:
        draw.text((100, bar_y+60), "🛒 See full catalog", fill=white, font=btn_font)

    link_font = _get_font(26)
    link = f"wa.me/{WEZA_NUMBER}?text=Shop%20{keyword}"
    try:
        draw.text((CARD_W//2, bar_y+180), link, fill=gray, font=link_font, anchor="mm")
    except:
        pass

    buf = io.BytesIO()
    img.save(buf, "PNG", quality=90)
    return buf.getvalue()

def generate_daily_cards(tenant_id: int) -> list:
    """Generate daily Status cards for a shop. Returns list of (bytes, caption)."""
    conn = get_db()
    shop = conn.execute("SELECT * FROM tenants WHERE id=? AND module_type='RETAIL' AND is_active=1",
                        (tenant_id,)).fetchone()
    if not shop:
        conn.close()
        return []
    shop = dict(shop)
    products = conn.execute(
        "SELECT * FROM products WHERE tenant_id=? AND is_available=1 ORDER BY added_at DESC LIMIT 8",
        (tenant_id,)
    ).fetchall()
    conn.close()
    products = [dict(p) for p in products]
    if not products:
        return []

    cards = []
    # Card 1: Hero card of newest/best product
    hero = generate_hero_card(products[0], shop)
    caption = f"🛒 {products[0]['name']} — UGX {products[0]['price_ugx']:,}\n{shop['name']}"
    if shop.get("location"):
        caption += f" · {shop['location']}"
    caption += f"\n\nMore: wa.me/{WEZA_NUMBER}?text=Shop%20{shop['keyword']}"
    cards.append((hero, caption))

    # Card 2: Grid card if 4+ products
    if len(products) >= 4:
        grid = generate_grid_card(products[:4], shop)
        caption2 = f"🛒 {shop['name']} — {len(products)} products available\n"
        caption2 += f"Browse: wa.me/{WEZA_NUMBER}?text=Shop%20{shop['keyword']}"
        cards.append((grid, caption2))

    # Card 3: Another hero for second product
    if len(products) >= 2:
        hero2 = generate_hero_card(products[1], shop)
        caption3 = f"🛒 {products[1]['name']} — UGX {products[1]['price_ugx']:,}\n{shop['name']}"
        caption3 += f"\n\nMore: wa.me/{WEZA_NUMBER}?text=Shop%20{shop['keyword']}"
        cards.append((hero2, caption3))

    return cards

def get_all_shops_for_cards():
    """Get all verified retail shops that should receive daily cards."""
    conn = get_db()
    shops = conn.execute(
        "SELECT id, owner_phone, name FROM tenants WHERE module_type='RETAIL' AND is_active=1 AND is_verified=1"
    ).fetchall()
    conn.close()
    return [dict(s) for s in shops]
