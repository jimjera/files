"""Compatibility shim — all functions moved to weza_ai.py"""
from app.services.weza_ai import (
    parse_inventory_text, extract_sacco_rules, read_momo_text,
    read_momo_screenshot, read_ledger_photo, classify_intent,
    generate_response, detect_intent, contextual_response,
    extract_group_name, classify_group
)
_ask = lambda msgs, mt=100: __import__('app.services.weza_ai', fromlist=['_ask'])._ask(msgs, mt)
