"""
app/services/weza_ai.py  —  Grok-powered AI Brain v6

3-Tier Hybrid Architecture:
  Tier 1 — Rules engine (zero cost)         handles greetings, exits, keywords
  Tier 2 — Response cache (zero cost)       handles repeated queries
  Tier 3 — Grok xAI (smart, cheap)          handles everything else

AI-Centric: EVERY message goes through intent classification.
No keyword matching. The AI extracts product names, understands context,
detects language, and responds naturally.
"""

import os, re, json, time, hashlib, httpx
from typing import Optional
from app.database import get_db

GROK_API_KEY  = os.getenv("GROK_API_KEY", "")
GROK_URL      = "https://api.x.ai/v1/chat/completions"
GROK_MODEL    = os.getenv("GROK_MODEL", "grok-3-mini-fast")
GROK_TEMP     = float(os.getenv("GROK_TEMPERATURE", "0.3"))
CACHE_TTL     = int(os.getenv("AI_CACHE_TTL_SECONDS", "600"))
_cache: dict  = {}

# ═══════════════════════════════════════════════════════════════════════════════
# GROK API LAYER
# ═══════════════════════════════════════════════════════════════════════════════

def _call_grok(messages: list, max_tokens: int = 200, json_mode: bool = True) -> tuple:
    if not GROK_API_KEY:
        return "", {}
    try:
        body = {"model": GROK_MODEL, "max_tokens": max_tokens,
                "messages": messages, "temperature": GROK_TEMP}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        r = httpx.post(GROK_URL,
            headers={"Authorization": f"Bearer {GROK_API_KEY}", "Content-Type": "application/json"},
            json=body, timeout=15)
        data = r.json()
        if "choices" in data:
            usage = data.get("usage", {})
            _track_cost(usage)
            return data["choices"][0]["message"]["content"].strip(), usage
        print(f"[Grok] {data.get('error',{}).get('message','error')}")
        return "", {}
    except Exception as e:
        print(f"[Grok] {e}")
        return "", {}

def _track_cost(usage: dict):
    inp = usage.get("prompt_tokens", 0)
    out = usage.get("completion_tokens", 0)
    cost = (inp * 0.10 + out * 0.30) / 1_000_000
    try:
        conn = get_db()
        conn.execute("INSERT INTO ai_usage (model,input_tokens,output_tokens,cost_usd,intent) VALUES (?,?,?,?,'tracked')",
                     (GROK_MODEL, inp, out, cost))
        conn.commit(); conn.close()
    except: pass

def _cached_call(key, messages, max_tokens=200, json_mode=True):
    h = hashlib.md5(key.encode()).hexdigest()
    if h in _cache:
        result, exp = _cache[h]
        if time.time() < exp: return result, {"cached": True}
    content, usage = _call_grok(messages, max_tokens, json_mode)
    if content: _cache[h] = (content, time.time() + CACHE_TTL)
    return content, usage

def _parse_json(raw):
    if not raw: return None
    try:
        c = raw.strip()
        if c.startswith("```"): c = re.sub(r"^```(?:json)?\s*","",c); c = re.sub(r"\s*```$","",c)
        return json.loads(c)
    except: return None

# ═══════════════════════════════════════════════════════════════════════════════
# TIER 1: RULES ENGINE (Zero cost)
# ═══════════════════════════════════════════════════════════════════════════════

GREETING_RE = re.compile(
    r"^(hi|hello|hey|yo|sup|hola|bonjour|habari|mambo|niaje|sema|"
    r"oli otya|gyendi|salaam|jambo|ola|ciao|hallo|"
    r"whats good|what'?s up|howdy|good\s*(morning|evening|afternoon|day)|"
    r"kal|kale|weza|start|ok|okay)[\s!?.]*$", re.IGNORECASE)

EXIT_WORDS = {"exit","home","back","rudi","quitter","salir","cancel","stop",
              "nevermind","never mind","acha","wacha","simama","leave","quit"}
EXIT_PHRASES = ["go home","go back","take me home","main menu","start over",
                "rudi nyumbani","lets leave","stop this","forget it"]

def tier1_rules(text):
    clean = text.strip(); upper = clean.upper(); lower = clean.lower()
    if GREETING_RE.match(clean):
        return {"intent":"greeting","confidence":0.95,"entities":{},"language":"en","tier":1}
    if lower in EXIT_WORDS or any(p in lower for p in EXIT_PHRASES):
        return {"intent":"exit","confidence":0.99,"entities":{},"language":"en","tier":1}
    if upper in ("REGISTER","MENU","HELP","SWITCH","BALANCE","CATCHUP"):
        return {"intent":upper.lower(),"confidence":0.99,"entities":{},"language":"en","tier":1}
    return None

# ═══════════════════════════════════════════════════════════════════════════════
# TIER 3: GROK AI
# ═══════════════════════════════════════════════════════════════════════════════

_ROUTER_SYSTEM = """You are Weza AI — a WhatsApp assistant for marketplace shopping, SACCOs, and community groups.
You understand ALL languages (English, Luganda, Swahili, French, Amharic, Hausa, Yoruba, Zulu, Arabic, Hindi, etc).

Analyze the user message and return ONLY valid JSON:
{
  "intent": "buy | register | balance | loan | statement | pledge | greeting | help | browse | delivery | complaint | general",
  "entities": {
    "product": "the actual product name (NOT verbs like want/buy/need) or null",
    "location": "location/area or null",
    "amount": number or null,
    "group_name": "SACCO/group name or null",
    "shop_name": "specific shop name or null"
  },
  "language": "ISO 639-1 code (en, lg, sw, fr, am, ha, yo, zu, ar, hi, etc)",
  "confidence": 0.0 to 1.0
}

CRITICAL:
- "i want cement" → product:"cement" NOT "want"
- "need to buy something from kamya" → product:null, shop_name:"kamya"
- "buy something"/"what are you selling" → intent:"browse"
- "nfuna siminti" (Luganda) → product:"cement"
- "je veux du ciment" (French) → product:"cement"
- "create group/sacco/shop" → intent:"register"
- "kal tutandike" (Luganda: let's start) → intent:"register"
- Single capitalized word that looks like a code → intent:"connect", group_name:that word
"""

_RESPONSE_SYSTEM = """You are Weza, a warm WhatsApp assistant for marketplace shopping, SACCOs, and community groups.
RULES:
- ALWAYS reply in the SAME language the user wrote in
- Brief (1-4 sentences — this is WhatsApp)
- Warm and market-savvy, like a helpful friend
- Use *bold* for emphasis
- NEVER invent prices or products. Only mention what's in the Available list.
- NEVER say "I don't understand" — always guide forward
- Understand local terms: siminti=cement, matoke=banana, sukali=sugar, chapati, etc.
"""

def classify_intent(text):
    t1 = tier1_rules(text)
    if t1: return t1
    cache_key = f"intent_v6:{text[:150].lower().strip()}"
    raw, usage = _cached_call(cache_key,
        [{"role":"system","content":_ROUTER_SYSTEM},
         {"role":"user","content":text}], max_tokens=120, json_mode=True)
    result = _parse_json(raw)
    if result and "intent" in result:
        result["tier"] = 3 if not usage.get("cached") else 2
        return result
    return _basic_fallback(text)

def _basic_fallback(text):
    """Offline fallback when Grok is unavailable."""
    tl = text.lower()
    for words, intent in [
        (["balance","savings","my money","account"],"balance"),
        (["loan","borrow"],"loan"),
        (["statement","history"],"statement"),
        (["register","create group","start sacco","open shop","tukole","kakole","tutandike"],"register"),
        (["pledge","contribute"],"pledge"),
    ]:
        if any(w in tl for w in words):
            return {"intent":intent,"confidence":0.7,"entities":{},"language":"en","tier":1}
    if any(w in tl for w in ["buy","need","want","price","sell","nfuna","nataka","acheter"]):
        skip = {"i","a","to","buy","need","want","some","please","from","the","for","me","nfuna","nataka"}
        words = [w for w in text.split() if len(w)>2 and w.lower() not in skip]
        prod = words[0].lower() if words else None
        return {"intent":"buy","confidence":0.5,"entities":{"product":prod},"language":"en","tier":1}
    return {"intent":"general","confidence":0.3,"entities":{},"language":"en","tier":1}

def generate_response(text, context="", search_results=None, user_lang="en"):
    results_ctx = ""
    if search_results:
        lines = []
        for r in search_results[:5]:
            line = f"- {r['name']} at {r['shop']}: UGX {r['price_ugx']:,}/{r['unit']}"
            if r.get("location"): line += f" [{r['location']}]"
            lines.append(line)
        results_ctx = "\nProducts found:\n" + "\n".join(lines)
    elif search_results is not None:
        cats = get_available_categories()
        if cats:
            results_ctx = f"\nNo exact match. Available: {', '.join(c['category']+' ('+c['shop']+')' for c in cats[:5])}"
        else:
            results_ctx = "\nNo shops registered yet."
    lang_note = f"\nUser language: {user_lang}. Respond in that language." if user_lang != "en" else ""
    system = _RESPONSE_SYSTEM + results_ctx + lang_note
    if context: system += f"\nContext: {context}"
    raw, _ = _call_grok([{"role":"system","content":system},{"role":"user","content":text}],
                        max_tokens=250, json_mode=False)
    return raw if raw else _local_fallback(text, search_results)

def _local_fallback(text, results=None):
    if results: return _format_product_results(results)
    return ("👋 Welcome to Weza!\n\nTell me what you need:\n"
            "• Looking for a product? Just say its name\n"
            "• Need a SACCO? Say *register*\n• Check balance? Just ask!")

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN COORDINATOR
# ═══════════════════════════════════════════════════════════════════════════════

def process_message(phone, text, user_session=None):
    intent_data = classify_intent(text)
    intent = intent_data.get("intent","general")
    entities = intent_data.get("entities",{})
    product = entities.get("product") if isinstance(entities, dict) else None
    language = intent_data.get("language","en")
    confidence = intent_data.get("confidence",0)
    base = {"intent":intent,"entities":entities,"language":language}

    if intent == "register" and confidence > 0.6:
        return {**base, "reply":"","action":"start_register","results":[]}
    if intent in ("balance","loan","statement") and confidence > 0.5:
        return {**base, "reply":"","action":intent,"results":[]}
    if intent == "pledge" and confidence > 0.5:
        return {**base, "reply":"","action":"show_pledges","results":[]}
    if intent == "connect" and entities.get("group_name"):
        return {**base, "reply":"","action":"connect_keyword","results":[]}

    # Shopping
    if intent in ("buy","browse") or (intent == "general" and _might_be_shopping(text)):
        results = []
        if product: results = search_products(product)
        if not results and isinstance(entities, dict) and entities.get("shop_name"):
            results = search_by_shop(entities["shop_name"])
        if not results and intent == "buy":
            results = search_products_broad(text)
        if results:
            reply = _format_product_results(results, product, language)
            return {**base, "reply":reply,"action":"search_product","results":results}
        reply = generate_response(text, search_results=[], user_lang=language)
        return {**base, "reply":reply,"action":"none","results":[]}

    if intent == "greeting":
        reply = generate_response(text, context="new user greeting", user_lang=language)
        return {**base, "reply":reply,"action":"none","results":[]}

    reply = generate_response(text, user_lang=language)
    return {**base, "reply":reply,"action":"none","results":[]}

def _might_be_shopping(text):
    tl = text.lower()
    return any(w in tl for w in ["buy","need","want","price","cost","how much",
        "nfuna","nataka","njagala","acheter","comprar","sell","shop","store","order","deliver"])

# ═══════════════════════════════════════════════════════════════════════════════
# PRODUCT SEARCH (DB — Zero AI cost)
# ═══════════════════════════════════════════════════════════════════════════════

def search_products(keyword, limit=5):
    if not keyword or len(keyword) < 2: return []
    kw = keyword.lower().strip()
    conn = get_db()
    rows = conn.execute(
        """SELECT p.name, p.price_ugx, p.bulk_price_ugx, p.bulk_min_qty,
                  p.unit, p.category,
                  t.name AS shop, t.location, t.keyword AS shop_code,
                  t.momo_number, t.momo_network
           FROM products p JOIN tenants t ON t.id=p.tenant_id
           WHERE p.is_available=1 AND t.is_active=1 AND t.module_type='RETAIL'
             AND (LOWER(p.name) LIKE ? OR LOWER(COALESCE(p.name_luganda,'')) LIKE ? OR LOWER(p.category) LIKE ?)
           ORDER BY p.price_ugx ASC LIMIT ?""",
        (f"%{kw}%", f"%{kw}%", f"%{kw}%", limit)).fetchall()
    conn.close()
    _track_search(keyword, len(rows))
    return [dict(r) for r in rows]

def search_by_shop(shop_name, limit=10):
    if not shop_name: return []
    conn = get_db()
    rows = conn.execute(
        """SELECT p.name, p.price_ugx, p.bulk_price_ugx, p.bulk_min_qty,
                  p.unit, p.category,
                  t.name AS shop, t.location, t.keyword AS shop_code,
                  t.momo_number, t.momo_network
           FROM products p JOIN tenants t ON t.id=p.tenant_id
           WHERE p.is_available=1 AND t.is_active=1 AND t.module_type='RETAIL'
             AND LOWER(t.name) LIKE ?
           ORDER BY p.category, p.name LIMIT ?""",
        (f"%{shop_name.lower()}%", limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def search_products_broad(text, limit=5):
    SKIP = {"i","a","the","is","am","are","to","from","for","of","in",
            "need","want","some","please","have","give","show","find","what",
            "selling","price","buy","looking","much","like","get","me","can",
            "hello","hi","kindly","now","today","lets","let","do",
            "nfuna","nataka","njagala","je","veux","acheter","quiero",
            "you","your","my","we","they","it","its","this","that","there",
            "something","anything","everything","nothing","stuff","things"}
    words = [w.lower().strip(".,!?") for w in text.split() if len(w)>2 and w.lower().strip(".,!?") not in SKIP]
    for word in words:
        results = search_products(word, limit)
        if results: return results
    return []

def get_available_categories():
    conn = get_db()
    rows = conn.execute(
        """SELECT DISTINCT p.category, t.name AS shop, COUNT(*) AS cnt
           FROM products p JOIN tenants t ON t.id=p.tenant_id
           WHERE p.is_available=1 AND t.is_active=1 AND t.module_type='RETAIL'
           GROUP BY p.category, t.name ORDER BY cnt DESC LIMIT 8""").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def _track_search(keyword, count):
    try:
        conn = get_db()
        conn.execute("INSERT INTO analytics_events (event_type,data) VALUES ('product_search',?)",
                     (json.dumps({"keyword":keyword,"results":count}),))
        conn.commit(); conn.close()
    except: pass

# ═══════════════════════════════════════════════════════════════════════════════
# PRODUCT RESULT FORMATTING
# ═══════════════════════════════════════════════════════════════════════════════

def _format_product_results(rows, product=None, lang="en"):
    if not rows: return ""
    if len(rows) == 1:
        r = rows[0]
        msg = f"🏪 *{r['shop']}*"
        if r.get("location"): msg += f"\n📍 {r['location']}"
        msg += f"\n\n*{r['name'].title()}*\n💰 UGX {r['price_ugx']:,} per {r['unit']}"
        if r.get("bulk_price_ugx"):
            msg += f"\n📦 Bulk ({r['bulk_min_qty']}+): UGX {r['bulk_price_ugx']:,} each"
        msg += f"\n\nPay via *{r['momo_network']} {r['momo_number']}*"
        msg += f"\nType *{r['shop_code']}* to order"
        return msg
    label = product.title() if product else "products"
    headers = {"lg":f"🏪 Nzuuse *{label}* mu maduka {len(rows)}:\n\n",
               "sw":f"🏪 Nimeona *{label}* katika maduka {len(rows)}:\n\n",
               "fr":f"🏪 *{label}* dans {len(rows)} boutiques:\n\n"}
    msg = headers.get(lang, f"🏪 Found *{label}* at {len(rows)} shops:\n\n")
    for r in rows:
        msg += f"*{r['shop']}*"
        if r.get("location"): msg += f" · {r['location']}"
        msg += f"\n💰 UGX {r['price_ugx']:,}/{r['unit']}"
        if r.get("bulk_price_ugx"): msg += f" _(bulk {r['bulk_min_qty']}+: UGX {r['bulk_price_ugx']:,})_"
        msg += f"\n📱 {r['momo_network']} · {r['momo_number']}"
        msg += f"\nType *{r['shop_code']}* to order\n\n"
    msg += f"✨ Best price: *{rows[0]['shop']}* at UGX {rows[0]['price_ugx']:,}/{rows[0]['unit']}"
    return msg

# ═══════════════════════════════════════════════════════════════════════════════
# REGISTRATION (Grok-powered conversational)
# ═══════════════════════════════════════════════════════════════════════════════

_REG_SYSTEM = """You help onboard new groups onto Weza. Be extremely brief. Any language.
If name is already collected, DO NOT ask again. If module_type is set, DO NOT ask again.
SACCO: needs name only. GROUPS: needs name only. RETAIL: needs name + MoMo number.
ONE question per turn. NEVER ask for a keyword (auto-generated).
SACCO/savings/cooperative/chama/vikoba → module_type: SACCO
wedding/funeral/harambee/event/committee → module_type: GROUPS
shop/kiosk/duka/hardware/pharmacy/salon → module_type: RETAIL
Unrelated message → wants_exit: true
Return ONLY JSON:
{"name":null,"organiser_name":null,"module_type":null,"momo_number":null,"momo_network":null,"reply":"short sentence","wants_exit":false,"ready":false}
"""

def registration_turn(text, collected, existing_keywords=None, history=None):
    status = []
    if collected.get("name"): status.append(f"Name: {collected['name']}")
    if collected.get("module_type"): status.append(f"Type: {collected['module_type']}")
    if collected.get("momo_number"): status.append(f"MoMo: {collected['momo_number']}")
    ctx = ("Collected: "+", ".join(status)) if status else "Nothing yet."
    messages = [{"role":"system","content":_REG_SYSTEM+"\n\n"+ctx}]
    if history: messages.extend(history[-6:])
    messages.append({"role":"user","content":text})
    raw, _ = _call_grok(messages, max_tokens=200, json_mode=True)
    result = _parse_json(raw)
    if not result:
        if raw and len(raw)<300: return {"reply":raw,"wants_exit":False}
        return {"reply":"What should we call your group?","wants_exit":False}
    return result

# ═══════════════════════════════════════════════════════════════════════════════
# SPECIALIST FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def extract_group_name(text):
    tl = text.lower().strip()
    if len(text.split())<=4 and not any(w in tl for w in ["want","need","create","make","start","tukole","kakole","njagala","lets"]):
        return text
    raw, _ = _call_grok([{"role":"system","content":"Extract ONLY the group/business name. Title-case. Nothing else."},
                         {"role":"user","content":text}], max_tokens=20, json_mode=False)
    return raw.strip() if (raw and len(raw.strip())<60) else text

def classify_group(text):
    tl = text.lower()
    if any(w in tl for w in ["wedding","marriage","funeral","burial","harambee","kwanjula","church"]):
        return {"module_type":"GROUPS","confidence":0.98,"group_name":""}
    if any(w in tl for w in ["shop","kiosk","duka","hardware","pharmacy","salon","restaurant","selling"]):
        return {"module_type":"RETAIL","confidence":0.95,"group_name":""}
    if any(w in tl for w in ["sacco","savings","loan","credit","chama","vikoba","merry"]):
        return {"module_type":"SACCO","confidence":0.95,"group_name":""}
    raw, _ = _cached_call(f"classify_v6:{text[:80].lower()}",
        [{"role":"system","content":"Classify: SACCO, GROUPS, or RETAIL. JSON: {\"module_type\":\"GROUPS\",\"confidence\":0.95}"},
         {"role":"user","content":text}], max_tokens=50, json_mode=True)
    return _parse_json(raw) or {"module_type":"GROUPS","confidence":0.5,"group_name":""}

def detect_financial_intent(text, sender_name):
    raw, _ = _call_grok([{"role":"system","content":
        f"Detect pledge/payment. JSON: {{\"isPledge\":bool,\"isPayment\":bool,\"amount\":int,\"personName\":\"{sender_name}\",\"confidence\":float}}"},
        {"role":"user","content":f"Sender: {sender_name}\nMessage: {text}"}], max_tokens=60, json_mode=True)
    return _parse_json(raw) or {"isPledge":False,"isPayment":False,"amount":0,"confidence":0}

def summarise_group_activity(event_name, budget, collected, pledges):
    pct = int(collected/budget*100) if budget else 0
    cleared = sum(1 for p in pledges if p.get("status")=="cleared")
    pending = sum(1 for p in pledges if p.get("status") in ("pledged","partial"))
    if not GROK_API_KEY:
        return f"• {event_name}: {pct}% funded\n• {collected:,} of {budget:,}\n• {cleared} cleared, {pending} pending"
    lines = "\n".join(f"- {p.get('member_name','?')}: pledged {p.get('pledged_ugx',0):,}, paid {p.get('paid_ugx',0):,} [{p.get('status','?')}]" for p in pledges[:10])
    raw, _ = _cached_call(f"summary_v6:{event_name}:{collected}:{len(pledges)}",
        [{"role":"system","content":"Warm WhatsApp catchup. Bullet points. Under 80 words."},
         {"role":"user","content":f"Event: {event_name}\nBudget: {budget:,} | Collected: {collected:,} ({pct}%)\nCleared: {cleared} | Pending: {pending}\n{lines}"}],
        max_tokens=150, json_mode=False)
    return raw or f"• {pct}% funded"

def extract_sacco_rules(text):
    raw, _ = _call_grok([{"role":"system","content":"Extract SACCO rules. JSON with monthly_contrib_ugx, loan_multiplier, interest_rate, grace_days, late_penalty_ugx, loan_term_months, approvers_required, exit_policy."},
        {"role":"user","content":text[:2000]}], max_tokens=250, json_mode=True)
    return _parse_json(raw) or {}

def read_momo_text(text):
    tc = text.replace(",",""); txid = None
    for pat in [r"TxID[:\s]+([A-Z0-9]+)",r"MP(\d{9,12})",r"Ref[:\s]+([A-Z0-9\-]+)",r"AT-(\d+)"]:
        m = re.search(pat, tc, re.IGNORECASE)
        if m: c = re.search(r"([A-Z]{0,3}\d{6,})", m.group(1), re.I); txid = c.group(1) if c else m.group(1); break
    amount = 0
    for pat in [r"UGX\s*(\d[\d,]*)",r"Ksh\s*(\d[\d,]*)",r"(\d[\d,]+)\s*(?:UGX|KES|shillings?)"]:
        m = re.search(pat, tc, re.IGNORECASE)
        if m: amount = int(m.group(1).replace(",","")); break
    network = "AIRTEL" if re.search(r"AIRTEL|AT-", text, re.I) else "MTN"
    if txid and amount: return {"transactionId":txid,"amount":amount,"network":network,"isConfirmation":True}
    return None

def read_momo_screenshot(image_bytes): return {"needsTextInput":True,"isConfirmation":False}
def read_ledger_photo(image_bytes): return []
def parse_inventory_text(text):
    items = []
    for m in re.finditer(r"([a-zA-Z][a-zA-Z\s]{1,25}?)\s+(\d+(?:\.\d+)?[kK]?)\s*([a-zA-Z]+)?", text):
        name=m.group(1).strip().lower(); ps=m.group(2).lower(); unit=(m.group(3) or "item").strip().lower()
        price=int(float(ps.replace("k",""))*(1000 if "k" in ps else 1))
        if price>0 and len(name)>1: items.append({"name":name,"price":price,"qty":0,"unit":unit})
    return items

# ── AI Stats for Admin ────────────────────────────────────────────────────────
def get_ai_stats():
    try:
        conn = get_db(); today = time.strftime("%Y-%m-%d")
        d = conn.execute("SELECT COUNT(*) as calls, COALESCE(SUM(input_tokens),0) as inp, COALESCE(SUM(output_tokens),0) as out, COALESCE(SUM(cost_usd),0) as cost FROM ai_usage WHERE DATE(created_at)=?", (today,)).fetchone()
        t = conn.execute("SELECT COUNT(*) as calls, COALESCE(SUM(cost_usd),0) as cost FROM ai_usage").fetchone()
        conn.close()
        return {"today_calls":d["calls"],"today_tokens":d["inp"]+d["out"],"today_cost":round(d["cost"],4),
                "total_calls":t["calls"],"total_cost":round(t["cost"],4),"model":GROK_MODEL,"cache_size":len(_cache)}
    except: return {"today_calls":0,"today_cost":0,"total_calls":0,"total_cost":0,"model":GROK_MODEL,"cache_size":0}

# Backward-compatible aliases
detect_intent = classify_intent
contextual_response = generate_response
extract_product_intent = classify_intent
_ask = lambda msgs, mt=100: _call_grok(msgs, mt, json_mode=False)[0]
