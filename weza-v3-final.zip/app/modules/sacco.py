"""
app/modules/sacco.py — SACCO Finance Module v3

Complete Ugandan SACCO support:
- Cash deposits at meetings with instant member confirmation
- MoMo deposit queue with admin approval
- Shares vs Savings split
- Merry-go-round rotation
- Automatic late fines
- Meeting management + attendance
- Member self-registration
- Loan flow with guarantors
- Year-end dividends
- Beautiful WhatsApp formatting
"""
import re, json, math
from datetime import datetime, timedelta
from app.database import get_db
from app.services import whatsapp
from app.services.admin_controls import (
    get_menu, handle_menu_number, broadcast, remind_sacco_contributions,
    handle_broadcast_context
)
from app.services.gemini import (
    parse_inventory_text, extract_sacco_rules, read_momo_text
)
from app.services.pdf_gen import loan_agreement, member_statement


def handle(message: str, phone: str, session: dict,
           image_bytes: bytes = None) -> str:
    tenant   = _tenant(session)
    is_admin = _is_admin(phone, tenant["id"])
    text     = message.strip()
    textup   = text.upper()

    if image_bytes:
        return _deposit_slip_image(image_bytes, phone, tenant)
    if not text:
        return ""

    # Admin broadcast context
    if is_admin:
        bc = handle_broadcast_context(text, phone, tenant, session)
        if bc is not None:
            return bc

    # ── Admin commands ─────────────────────────────────────────────────────
    if is_admin:
        if textup in ("HELP", "?", "MENU"):
            return _help(True, tenant)
        if textup == "QUEUE":
            return _queue(tenant)
        if textup == "MEMBERS":
            return _list_members(tenant)
        if textup == "REPORT":
            return _monthly_report(tenant)
        if textup == "ANNUAL REPORT":
            return _annual_report(tenant)
        if textup.startswith("APPROVE DIVIDENDS"):
            return _distribute_dividends(phone, tenant)
        if textup.startswith("APPROVE MEMBER "):
            return _approve_member_request(text, phone, tenant)
        if textup.startswith("APPROVE "):
            return _approve(text, phone, tenant)
        if textup.startswith("REJECT "):
            return _reject(text, phone, tenant)
        if textup.startswith("ADD MEMBER "):
            return _add_member(text, phone, tenant)
        if textup.startswith("SUSPEND "):
            return _suspend(text, phone, tenant, True)
        if textup.startswith("REINSTATE "):
            return _suspend(text, phone, tenant, False)
        if textup.startswith("BALANCE ") and len(text) > 8:
            return _admin_balance(text, tenant)
        if textup.startswith("SET RULE "):
            return _set_rule(text, phone, tenant)
        # Cash deposit by admin: DEPOSIT [name] [amount] cash
        if textup.startswith("DEPOSIT ") and ("CASH" in textup or "TASIIMU" in textup):
            return _cash_deposit(text, phone, tenant)
        # Meeting management
        if textup.startswith("MEETING DONE"):
            return _meeting_done(text, phone, tenant)
        if textup.startswith("MEETING "):
            return _schedule_meeting(text, phone, tenant)
        # Merry-go-round
        if textup == "ROUND DONE":
            return _round_done(phone, tenant)
        if textup.startswith("SET ROTATION "):
            return _set_rotation(text, phone, tenant)
        # Admin menu number
        result = handle_menu_number(textup, phone, tenant)
        if result is not None:
            return result

    # ── Member commands ────────────────────────────────────────────────────
    member = _get_member(phone, tenant["id"])
    if not member:
        return _not_member_msg(tenant)

    if textup in ("HELP", "?", "MENU"):
        return _help(False, tenant)

    # Natural language balance
    BAL_WORDS = ["balance","savings","my money","account","nfuna","salio",
                 "bakiamange","how much","statement","history"]
    if any(w in text.lower() for w in BAL_WORDS):
        if "statement" in text.lower() or "history" in text.lower():
            return _statement(member, tenant)
        return _balance(member, tenant)

    # Loan
    if "loan" in text.lower() or textup.startswith("LOAN"):
        return _loan_flow(text, phone, member, tenant, session)

    # Deposit/payment reference
    if textup.startswith("REF ") or textup.startswith("DEPOSIT "):
        return _deposit_slip_text(text, phone, tenant)

    # MoMo confirmation detection (forwarded SMS)
    momo = read_momo_text(text)
    if momo and momo.get("isConfirmation"):
        return _deposit_slip_text(text, phone, tenant)

    # Guarantor response
    if textup in ("YES","NO","NDAKIRIZA","NEDDA","AGREE","DECLINE"):
        return _guarantor_response(text, phone, tenant, session)

    # Rules
    if textup in ("RULES", "CONSTITUTION"):
        return _show_rules(tenant)

    # My turn (merry-go-round)
    if "my turn" in text.lower() or "position" in text.lower():
        return _my_turn(member, tenant)

    # Catchup
    if textup == "CATCHUP":
        return _monthly_report(tenant)

    return _help(False, tenant)


# ═══════════════════════════════════════════════════════════════════════════════
# BALANCE & STATEMENTS
# ═══════════════════════════════════════════════════════════════════════════════

def _balance(member, tenant):
    rules = _get_rules(tenant["id"])
    mult = rules["loan_multiplier"] if rules else 3.0
    max_loan = int((member["savings_balance"] + member.get("share_value",0)) * mult)
    contrib = rules["monthly_contrib_ugx"] if rules else 0
    contrib_day = rules["contrib_day"] if rules else ""

    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  {tenant['name']}\n"
           f"  {member['full_name']}\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
           f"💰 Savings:     UGX {member['savings_balance']:,}\n")
    if member.get("shares", 0) > 0:
        msg += f"📊 Shares:      {member['shares']} × UGX {rules.get('share_price',10000):,} = UGX {member.get('share_value',0):,}\n"
    msg += f"💳 Loan owed:   UGX {member['loan_balance']:,}\n"
    msg += f"📈 Loan limit:  UGX {max_loan:,}\n"
    if contrib > 0:
        msg += f"\n📅 Next due: {contrib_day}\n   Amount: UGX {contrib:,}\n"
    msg += f"\n━━━━━━━━━━━━━━━━━━━━━━━━━\n  STATEMENT · LOAN · RULES\n━━━━━━━━━━━━━━━━━━━━━━━━━"
    return msg

def _statement(member, tenant):
    conn = get_db()
    txns = conn.execute(
        "SELECT type, amount_ugx, balance_after, transaction_ref, created_at "
        "FROM sacco_transactions WHERE member_id=? ORDER BY created_at DESC LIMIT 10",
        (member["id"],)).fetchall()
    conn.close()
    if not txns:
        return "No transactions on record yet."
    lines = []
    for t in txns:
        date = t["created_at"][:10]
        ttype = t["type"].replace("_"," ").title()
        sign = "-" if t["type"] in ("withdrawal","loan_disbursed","late_fine") else "+"
        lines.append(f"  {date}  {ttype:18} {sign}{t['amount_ugx']:,}")
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  Statement — {member['full_name']}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
            "\n".join(lines) +
            f"\n\n💰 Savings: UGX {member['savings_balance']:,}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")


# ═══════════════════════════════════════════════════════════════════════════════
# CASH DEPOSITS (NEW — the killer feature)
# ═══════════════════════════════════════════════════════════════════════════════

def _cash_deposit(text, admin_phone, tenant):
    """Treasurer records a cash deposit at the meeting. Instant confirmation to member."""
    # Parse: DEPOSIT [name/phone] [amount] cash
    clean = re.sub(r"\b(DEPOSIT|CASH|TASIIMU)\b", "", text, flags=re.I).strip()
    # Extract amount
    amount = 0
    for m in re.finditer(r"(\d[\d,]*)", clean):
        val = int(m.group(1).replace(",",""))
        if val >= 1000:
            amount = val
            clean = clean.replace(m.group(0), "").strip()
            break
    if amount == 0:
        return "Format: *DEPOSIT [name] [amount] cash*\nExample: DEPOSIT Mary 50000 cash"

    # Find member by name or phone
    name_or_phone = clean.strip().strip('"').strip("'")
    member = _find_member(name_or_phone, tenant["id"])
    if not member:
        return f"Member '{name_or_phone}' not found. Check the name or use MEMBERS to see all."

    # Post directly (cash verified by treasurer in person)
    conn = get_db()
    new_balance = member["savings_balance"] + amount
    conn.execute("UPDATE sacco_members SET savings_balance=? WHERE id=?",
                 (new_balance, member["id"]))
    conn.execute(
        "INSERT INTO sacco_transactions (tenant_id,member_id,type,amount_ugx,balance_after,notes,approved_by) "
        "VALUES (?,?,'cash_deposit',?,?,?,?)",
        (tenant["id"], member["id"], amount, new_balance, "Cash at meeting", admin_phone))
    _audit(conn, tenant["id"], admin_phone, "CASH_DEPOSIT", member["id"])
    conn.commit()
    conn.close()

    # Instant confirmation to MEMBER
    member_msg = (f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                  f"  ✅ {tenant['name']}\n"
                  f"  Deposit Confirmed\n"
                  f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                  f"Amount:      UGX {amount:,}\n"
                  f"Method:      Cash (at meeting)\n"
                  f"Recorded by: {_admin_name(admin_phone, tenant['id'])}\n"
                  f"New balance: UGX {new_balance:,}\n"
                  f"Date:        {datetime.now().strftime('%d %b %Y')}\n"
                  f"━━━━━━━━━━━━━━━━━━━━━━━")
    whatsapp.send(member["phone"], member_msg)

    # Confirmation to treasurer
    return (f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ CASH DEPOSIT\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Member:  {member['full_name']}\n"
            f"Amount:  UGX {amount:,}\n"
            f"Balance: UGX {new_balance:,}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")


# ═══════════════════════════════════════════════════════════════════════════════
# MOMO DEPOSITS (existing — improved with instant confirmation)
# ═══════════════════════════════════════════════════════════════════════════════

def _deposit_slip_image(image_bytes, phone, tenant):
    return ("Please paste or forward the MoMo confirmation text instead.\n\n"
            "Example: _REF MP240130456 50000_")

def _deposit_slip_text(text, phone, tenant):
    member = _get_member(phone, tenant["id"])
    if not member:
        return "You are not a registered member."
    momo = read_momo_text(text)
    if not momo:
        parts = text.upper().replace("REF","").replace("DEPOSIT","").split()
        if len(parts) >= 2:
            ref = parts[0]
            amt = int(parts[1].replace(",","")) if parts[1].replace(",","").isdigit() else 0
            if amt > 0:
                momo = {"transactionId":ref,"amount":amt,"network":"MTN","isConfirmation":True}
    if not momo or not momo.get("transactionId"):
        return ("I couldn't read the reference.\n\n"
                "Please type: *REF [transaction ID] [amount]*\n"
                "Example: _REF MP240130456 50000_")

    conn = get_db()
    dup = conn.execute("SELECT id FROM deposit_queue WHERE transaction_ref=? AND tenant_id=?",
                       (momo["transactionId"], tenant["id"])).fetchone()
    if dup:
        conn.close()
        return f"This reference has already been submitted.\nRef: {momo['transactionId']}"

    entry_id = conn.execute(
        "INSERT INTO deposit_queue (tenant_id,member_id,submitter_phone,transaction_ref,amount_ugx,method,ocr_raw) "
        "VALUES (?,?,?,?,?,'momo',?)",
        (tenant["id"], member["id"], phone, momo["transactionId"], momo["amount"], json.dumps(momo))
    ).lastrowid
    conn.commit()
    admins = conn.execute("SELECT phone FROM tenant_admins WHERE tenant_id=?", (tenant["id"],)).fetchall()
    conn.close()

    for admin in admins:
        whatsapp.send(admin["phone"],
            f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📥 Deposit Submitted\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Member: {member['full_name']}\n"
            f"{momo.get('network','MoMo')} Ref: {momo['transactionId']}\n"
            f"Amount: UGX {momo['amount']:,}\n"
            f"Queue #: {entry_id}\n\n"
            f"*APPROVE {entry_id}* or *REJECT {entry_id}*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")

    return (f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📤 Deposit Submitted\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Ref: {momo['transactionId']}\n"
            f"Amount: UGX {momo['amount']:,}\n"
            f"Queue #{entry_id}\n\n"
            f"Your treasurer will verify\n"
            f"and post to your account.\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")


# ═══════════════════════════════════════════════════════════════════════════════
# LOAN FLOW (existing — kept)
# ═══════════════════════════════════════════════════════════════════════════════

def _loan_flow(text, phone, member, tenant, session):
    rules = _get_rules(tenant["id"])
    rate = rules["interest_rate"] if rules else 10.0
    term = rules["loan_term_months"] if rules else 6
    mult = rules["loan_multiplier"] if rules else 3.0
    max_loan = int((member["savings_balance"] + member.get("share_value",0)) * mult)

    nums = re.findall(r"\d[\d,]*(?:k|K)?", text)
    amount = 0
    for n in nums:
        val = float(n.replace(",","").replace("K","").replace("k",""))
        amount = int(val * 1000 if n.lower().endswith("k") else val)
        if amount > 1000: break

    if amount == 0:
        return (f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"  💳 Loan Application\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"Savings: UGX {member['savings_balance']:,}\n"
                f"Max loan: UGX {max_loan:,}\n"
                f"Rate: {rate}%/month · {term} months\n\n"
                f"Reply: *loan [amount]*\n"
                f"Example: _loan 300000_\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━")

    if member["loan_balance"] > 0:
        return f"You have an active loan of UGX {member['loan_balance']:,}. Repay first."
    if amount > max_loan:
        return f"Amount exceeds your limit of UGX {max_loan:,}."

    monthly = int(amount * (1 + rate/100) / term)
    conn = get_db()
    loan_id = conn.execute(
        "INSERT INTO sacco_loans (tenant_id,member_id,principal_ugx,interest_rate,term_months,monthly_payment,balance_ugx) "
        "VALUES (?,?,?,?,?,?,?)",
        (tenant["id"], member["id"], amount, rate, term, monthly, int(amount*(1+rate/100)))
    ).lastrowid
    _audit(conn, tenant["id"], phone, "LOAN_APPLIED", loan_id)
    conn.commit()
    conn.close()

    # Notify admins
    admins = _get_admins(tenant["id"])
    for a in admins:
        whatsapp.send(a,
            f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  💳 Loan Application\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Member: {member['full_name']}\n"
            f"Amount: UGX {amount:,}\n"
            f"Savings: UGX {member['savings_balance']:,}\n"
            f"Loan #{loan_id}\n\n"
            f"*APPROVE {loan_id}* or *REJECT {loan_id}*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")

    return (f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📤 Loan Application Sent\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Amount: UGX {amount:,}\n"
            f"Rate: {rate}%/month\n"
            f"Term: {term} months\n"
            f"Monthly payment: UGX {monthly:,}\n"
            f"Loan #{loan_id}\n\n"
            f"Waiting for admin approval.\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")

def _guarantor_response(answer, phone, tenant, session):
    is_yes = answer.upper() in ("YES","NDAKIRIZA","AGREE")
    conn = get_db()
    loans = conn.execute(
        "SELECT * FROM sacco_loans WHERE tenant_id=? AND status='pending'",
        (tenant["id"],)).fetchall()
    for loan in loans:
        loan = dict(loan)
        gphones = json.loads(loan.get("guarantor_phones","[]"))
        confirmed = json.loads(loan.get("guarantors_confirmed","[]"))
        if phone in gphones and phone not in confirmed:
            if is_yes:
                confirmed.append(phone)
                conn.execute("UPDATE sacco_loans SET guarantors_confirmed=? WHERE id=?",
                             (json.dumps(confirmed), loan["id"]))
                conn.commit()
                conn.close()
                return f"✅ You have guaranteed loan #{loan['id']}. Thank you."
            else:
                conn.close()
                return f"❌ You declined to guarantee loan #{loan['id']}."
    conn.close()
    return "No pending guarantor requests for you."


# ═══════════════════════════════════════════════════════════════════════════════
# MERRY-GO-ROUND
# ═══════════════════════════════════════════════════════════════════════════════

def _round_done(admin_phone, tenant):
    rules = _get_rules(tenant["id"])
    if not rules or not rules.get("is_merry_go_round"):
        return "This group is not set up as a merry-go-round."
    current = rules.get("current_round", 1)
    conn = get_db()
    recipient = conn.execute(
        "SELECT r.*, m.full_name, m.phone FROM rotation_order r "
        "JOIN sacco_members m ON m.id=r.member_id "
        "WHERE r.tenant_id=? AND r.position=?",
        (tenant["id"], current)).fetchone()
    if not recipient:
        conn.close()
        return "No member at this position in the rotation."
    recipient = dict(recipient)
    pot = rules["round_amount"] * conn.execute(
        "SELECT COUNT(*) n FROM sacco_members WHERE tenant_id=? AND status='active'",
        (tenant["id"],)).fetchone()["n"]

    # Mark received
    conn.execute("UPDATE rotation_order SET received=1, received_at=? WHERE id=?",
                 (datetime.now().isoformat(), recipient["id"]))
    conn.execute("UPDATE sacco_rules SET current_round=? WHERE tenant_id=?",
                 (current+1, tenant["id"]))
    _audit(conn, tenant["id"], admin_phone, "ROUND_DONE", recipient["member_id"])
    conn.commit()

    # Get next
    nxt = conn.execute(
        "SELECT m.full_name FROM rotation_order r JOIN sacco_members m ON m.id=r.member_id "
        "WHERE r.tenant_id=? AND r.position=?",
        (tenant["id"], current+1)).fetchone()
    conn.close()
    next_name = nxt["full_name"] if nxt else "End of rotation"

    # Notify all members
    members = _get_all_members(tenant["id"])
    for m in members:
        pos = _get_position(m["id"], tenant["id"])
        pos_text = f"\nYour position: #{pos}" if pos else ""
        whatsapp.send(m["phone"],
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  🎉 {tenant['name']} — Round {current}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"UGX {pot:,} paid to *{recipient['full_name']}*\n"
            f"Next: {next_name} (Round {current+1}){pos_text}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  🎉 ROUND {current} COMPLETE\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Pot: UGX {pot:,}\n"
            f"Recipient: {recipient['full_name']}\n"
            f"Next: {next_name}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def _my_turn(member, tenant):
    rules = _get_rules(tenant["id"])
    if not rules or not rules.get("is_merry_go_round"):
        return _balance(member, tenant)
    pos = _get_position(member["id"], tenant["id"])
    if not pos:
        return "You're not in the rotation order yet."
    current = rules.get("current_round", 1)
    remaining = pos - current
    conn = get_db()
    rot = conn.execute("SELECT received FROM rotation_order WHERE tenant_id=? AND member_id=?",
                       (tenant["id"], member["id"])).fetchone()
    conn.close()
    received = rot["received"] if rot else 0
    contrib_total = (current - 1) * rules.get("round_amount", 0)
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  {tenant['name']} — Your Status\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Your position: #{pos}\n"
            f"Current round: {current}\n"
            f"{'✅ You have received your pot!' if received else f'Rounds until your turn: {max(0,remaining)}'}\n"
            f"Contributed: UGX {contrib_total:,}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def _set_rotation(text, phone, tenant):
    """SET ROTATION 1 Sarah 2 John 3 Mary..."""
    clean = text.replace("SET ROTATION","",1).strip()
    entries = re.findall(r"(\d+)\s+([A-Za-z ]+?)(?=\d|$)", clean)
    if not entries:
        return "Format: *SET ROTATION 1 Sarah 2 John 3 Mary*"
    conn = get_db()
    conn.execute("DELETE FROM rotation_order WHERE tenant_id=?", (tenant["id"],))
    added = []
    for pos, name in entries:
        member = _find_member(name.strip(), tenant["id"])
        if member:
            conn.execute("INSERT INTO rotation_order (tenant_id,member_id,position) VALUES (?,?,?)",
                         (tenant["id"], member["id"], int(pos)))
            added.append(f"  {pos}. {member['full_name']}")
    conn.commit()
    conn.close()
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ Rotation Order Set\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
            "\n".join(added) + "\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")


# ═══════════════════════════════════════════════════════════════════════════════
# MEETINGS
# ═══════════════════════════════════════════════════════════════════════════════

def _schedule_meeting(text, phone, tenant):
    """MEETING Saturday 2pm Nakasero Church"""
    clean = text.replace("MEETING","",1).strip()
    conn = get_db()
    mid = conn.execute(
        "INSERT INTO meetings (tenant_id,location,status) VALUES (?,?,'scheduled')",
        (tenant["id"], clean)).lastrowid
    total = conn.execute("SELECT COUNT(*) n FROM sacco_members WHERE tenant_id=? AND status='active'",
                         (tenant["id"],)).fetchone()["n"]
    conn.execute("UPDATE meetings SET total_members=? WHERE id=?", (total, mid))
    # Get pending items for agenda
    pending_loans = conn.execute("SELECT COUNT(*) n FROM sacco_loans WHERE tenant_id=? AND status='pending'",
                                 (tenant["id"],)).fetchone()["n"]
    pending_deps = conn.execute("SELECT COUNT(*) n FROM deposit_queue WHERE tenant_id=? AND status='pending'",
                                (tenant["id"],)).fetchone()["n"]
    conn.commit()

    agenda = "  • Contributions collection\n"
    if pending_loans: agenda += f"  • {pending_loans} loan application(s) to discuss\n"
    if pending_deps: agenda += f"  • {pending_deps} pending deposit(s) to verify\n"
    agenda += "  • Monthly report\n  • AOB"

    members = _get_all_members(tenant["id"])
    for m in members:
        whatsapp.send(m["phone"],
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📅 {tenant['name']} — Meeting\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📍 {clean}\n\n"
            f"Agenda:\n{agenda}\n\n"
            f"Reply ✅ to confirm attendance\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")
    conn.close()
    return f"✅ Meeting scheduled. {len(members)} members notified."

def _meeting_done(text, phone, tenant):
    """MEETING DONE 15 present 750000 collected"""
    nums = re.findall(r"\d[\d,]*", text.replace("MEETING DONE","",1))
    attendees = int(nums[0].replace(",","")) if len(nums) > 0 else 0
    collected = int(nums[1].replace(",","")) if len(nums) > 1 else 0
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) n FROM sacco_members WHERE tenant_id=? AND status='active'",
                         (tenant["id"],)).fetchone()["n"]
    conn.execute("INSERT INTO meetings (tenant_id,attendees,total_members,amount_collected,status) VALUES (?,?,?,?,'completed')",
                 (tenant["id"], attendees, total, collected))
    conn.commit()
    conn.close()

    members = _get_all_members(tenant["id"])
    for m in members:
        whatsapp.send(m["phone"],
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ Meeting Summary\n"
            f"  {datetime.now().strftime('%d %b %Y')}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👥 Attendance: {attendees} of {total}\n"
            f"💰 Collected:  UGX {collected:,}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return f"✅ Meeting recorded. {len(members)} members notified."


# ═══════════════════════════════════════════════════════════════════════════════
# MEMBER SELF-REGISTRATION
# ═══════════════════════════════════════════════════════════════════════════════

def _not_member_msg(tenant):
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  🏦 {tenant['name']}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"You're not a member yet.\n\n"
            f"Would you like to request membership?\n"
            f"Reply with your full name to apply.\n"
            f"The admin will approve you.\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def _approve_member_request(text, admin_phone, tenant):
    phone = re.sub(r"\D","", text.replace("APPROVE MEMBER","",1).strip())
    conn = get_db()
    m = conn.execute("SELECT * FROM sacco_members WHERE tenant_id=? AND phone=? AND status='pending_approval'",
                     (tenant["id"], phone)).fetchone()
    if not m:
        conn.close()
        return f"No pending request from +{phone}"
    conn.execute("UPDATE sacco_members SET status='active' WHERE id=?", (m["id"],))
    _audit(conn, tenant["id"], admin_phone, "MEMBER_APPROVED", m["id"])
    conn.commit()
    conn.close()
    whatsapp.send(phone,
        f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"  🎉 Welcome to {tenant['name']}!\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Your membership has been approved.\n"
        f"Type *balance* to check your account.\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━")
    return f"✅ {m['full_name']} approved as member."


# ═══════════════════════════════════════════════════════════════════════════════
# ANNUAL REPORT & DIVIDENDS
# ═══════════════════════════════════════════════════════════════════════════════

def _annual_report(tenant):
    conn = get_db()
    stats = conn.execute(
        "SELECT COUNT(*) members, COALESCE(SUM(savings_balance),0) savings, "
        "COALESCE(SUM(share_value),0) shares, COALESCE(SUM(loan_balance),0) loans "
        "FROM sacco_members WHERE tenant_id=? AND status='active'",
        (tenant["id"],)).fetchone()
    interest = conn.execute(
        "SELECT COALESCE(SUM(amount_ugx),0) amt FROM sacco_transactions "
        "WHERE tenant_id=? AND type='interest_payment'", (tenant["id"],)).fetchone()["amt"]
    fines = conn.execute(
        "SELECT COALESCE(SUM(amount_ugx),0) amt FROM sacco_transactions "
        "WHERE tenant_id=? AND type='late_fine'", (tenant["id"],)).fetchone()["amt"]
    total_shares = int(stats["shares"]) if stats["shares"] else 0
    conn.close()

    income = interest + fines
    expenses = 0  # Could track Weza subscription here
    distributable = income - expenses
    per_share = int(distributable / max(total_shares / 10000, 1)) if total_shares > 0 else 0

    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📊 {tenant['name']}\n"
            f"  Annual Report {datetime.now().year}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👥 Members: {stats['members']}\n"
            f"💰 Total savings: UGX {int(stats['savings']):,}\n"
            f"📊 Total shares: UGX {total_shares:,}\n"
            f"💳 Loans outstanding: UGX {int(stats['loans']):,}\n\n"
            f"📈 Income:\n"
            f"   Interest earned: UGX {interest:,}\n"
            f"   Fines collected: UGX {fines:,}\n\n"
            f"💵 Available for dividends: UGX {distributable:,}\n"
            f"   Per share: UGX {per_share:,}\n\n"
            f"Reply *APPROVE DIVIDENDS* to distribute.\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

def _distribute_dividends(admin_phone, tenant):
    conn = get_db()
    interest = conn.execute(
        "SELECT COALESCE(SUM(amount_ugx),0) amt FROM sacco_transactions "
        "WHERE tenant_id=? AND type='interest_payment'", (tenant["id"],)).fetchone()["amt"]
    fines = conn.execute(
        "SELECT COALESCE(SUM(amount_ugx),0) amt FROM sacco_transactions "
        "WHERE tenant_id=? AND type='late_fine'", (tenant["id"],)).fetchone()["amt"]
    distributable = interest + fines
    members = conn.execute(
        "SELECT * FROM sacco_members WHERE tenant_id=? AND status='active' AND share_value > 0",
        (tenant["id"],)).fetchall()
    total_shares = sum(m["share_value"] for m in members)
    if total_shares == 0:
        conn.close()
        return "No shares held by members. Cannot distribute dividends."

    lines = []
    for m in members:
        m = dict(m)
        payout = int(distributable * m["share_value"] / total_shares)
        if payout > 0:
            new_bal = m["savings_balance"] + payout
            conn.execute("UPDATE sacco_members SET savings_balance=? WHERE id=?", (new_bal, m["id"]))
            conn.execute("INSERT INTO sacco_transactions (tenant_id,member_id,type,amount_ugx,balance_after,notes) VALUES (?,?,'dividend_payout',?,?,?)",
                         (tenant["id"], m["id"], payout, new_bal, f"Annual dividend {datetime.now().year}"))
            lines.append(f"  {m['full_name']}: UGX {payout:,}")
            whatsapp.send(m["phone"],
                f"🎉 *Dividend Payout*\n"
                f"UGX {payout:,} added to your savings.\n"
                f"New balance: UGX {new_bal:,}")
    _audit(conn, tenant["id"], admin_phone, "DIVIDENDS_DISTRIBUTED", None)
    conn.commit()
    conn.close()
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ Dividends Distributed\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
            "\n".join(lines) + "\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")


# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN: APPROVE / REJECT / MEMBERS / REPORT / RULES
# ═══════════════════════════════════════════════════════════════════════════════

def _queue(tenant):
    conn = get_db()
    deps = conn.execute(
        "SELECT d.*, m.full_name FROM deposit_queue d "
        "JOIN sacco_members m ON m.id=d.member_id "
        "WHERE d.tenant_id=? AND d.status='pending' ORDER BY d.submitted_at",
        (tenant["id"],)).fetchall()
    loans = conn.execute(
        "SELECT l.*, m.full_name FROM sacco_loans l "
        "JOIN sacco_members m ON m.id=l.member_id "
        "WHERE l.tenant_id=? AND l.status='pending'",
        (tenant["id"],)).fetchall()
    conn.close()
    if not deps and not loans:
        return "✅ No pending items in the queue."
    msg = f"━━━━━━━━━━━━━━━━━━━━━━━━━\n  📥 Pending Queue\n━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    for d in deps:
        msg += f"*#{d['id']}* {d['full_name']} — UGX {d['amount_ugx']:,} ({d.get('method','momo')})\n  Ref: {d['transaction_ref']}\n  APPROVE {d['id']} · REJECT {d['id']}\n\n"
    for l in loans:
        msg += f"*Loan #{l['id']}* {l['full_name']} — UGX {l['principal_ugx']:,}\n  APPROVE {l['id']} · REJECT {l['id']}\n\n"
    return msg.strip()

def _approve(text, admin_phone, tenant):
    item_id = int(re.sub(r"\D","", text.replace("APPROVE","",1).strip()) or 0)
    if not item_id: return "Usage: *APPROVE [id]*"
    conn = get_db()
    # Check deposit queue
    dep = conn.execute("SELECT * FROM deposit_queue WHERE id=? AND tenant_id=? AND status='pending'",
                       (item_id, tenant["id"])).fetchone()
    if dep:
        dep = dict(dep)
        member = conn.execute("SELECT * FROM sacco_members WHERE id=?", (dep["member_id"],)).fetchone()
        new_bal = member["savings_balance"] + dep["amount_ugx"]
        conn.execute("UPDATE sacco_members SET savings_balance=? WHERE id=?", (new_bal, dep["member_id"]))
        conn.execute("UPDATE deposit_queue SET status='approved' WHERE id=?", (item_id,))
        conn.execute("INSERT INTO sacco_transactions (tenant_id,member_id,type,amount_ugx,balance_after,transaction_ref,approved_by) VALUES (?,?,'deposit',?,?,?,?)",
                     (tenant["id"], dep["member_id"], dep["amount_ugx"], new_bal, dep["transaction_ref"], admin_phone))
        _audit(conn, tenant["id"], admin_phone, "DEPOSIT_APPROVED", item_id)
        conn.commit()
        # Notify member
        whatsapp.send(member["phone"],
            f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ {tenant['name']}\n"
            f"  Deposit Approved\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Amount: UGX {dep['amount_ugx']:,}\n"
            f"Ref: {dep['transaction_ref']}\n"
            f"New balance: UGX {new_bal:,}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")
        conn.close()
        return f"✅ Deposit #{item_id} approved. {member['full_name']}: UGX {new_bal:,}"

    # Check loan
    loan = conn.execute("SELECT l.*, m.full_name, m.phone FROM sacco_loans l JOIN sacco_members m ON m.id=l.member_id WHERE l.id=? AND l.tenant_id=? AND l.status='pending'",
                        (item_id, tenant["id"])).fetchone()
    if loan:
        loan = dict(loan)
        conn.execute("UPDATE sacco_loans SET status='approved', approved_at=? WHERE id=?",
                     (datetime.now().isoformat(), item_id))
        conn.execute("UPDATE sacco_members SET loan_balance=? WHERE id=?",
                     (loan["balance_ugx"], loan["member_id"]))
        conn.execute("INSERT INTO sacco_transactions (tenant_id,member_id,type,amount_ugx,balance_after,approved_by) VALUES (?,?,'loan_disbursed',?,?,?)",
                     (tenant["id"], loan["member_id"], loan["principal_ugx"], loan["balance_ugx"], admin_phone))
        _audit(conn, tenant["id"], admin_phone, "LOAN_APPROVED", item_id)
        conn.commit()
        whatsapp.send(loan["phone"],
            f"━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  ✅ Loan Approved!\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Amount: UGX {loan['principal_ugx']:,}\n"
            f"Monthly: UGX {loan['monthly_payment']:,}\n"
            f"Term: {loan['term_months']} months\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━")
        conn.close()
        return f"✅ Loan #{item_id} approved for {loan['full_name']}."
    conn.close()
    return f"Item #{item_id} not found in pending queue."

def _reject(text, admin_phone, tenant):
    parts = text.replace("REJECT","",1).strip().split(None,1)
    item_id = int(re.sub(r"\D","",parts[0]) or 0) if parts else 0
    reason = parts[1] if len(parts)>1 else "No reason given"
    if not item_id: return "Usage: *REJECT [id] [reason]*"
    conn = get_db()
    conn.execute("UPDATE deposit_queue SET status='rejected' WHERE id=? AND tenant_id=?",
                 (item_id, tenant["id"]))
    conn.execute("UPDATE sacco_loans SET status='rejected', rejection_reason=? WHERE id=? AND tenant_id=?",
                 (reason, item_id, tenant["id"]))
    _audit(conn, tenant["id"], admin_phone, "REJECTED", item_id)
    conn.commit()
    conn.close()
    return f"❌ Item #{item_id} rejected: {reason}"

def _add_member(text, admin_phone, tenant):
    clean = text.replace("ADD MEMBER","",1).strip()
    parts = clean.split()
    if len(parts) < 2: return "Format: *ADD MEMBER [phone] [name]*"
    phone = re.sub(r"\D","",parts[0])
    name = " ".join(parts[1:])
    conn = get_db()
    existing = conn.execute("SELECT id FROM sacco_members WHERE tenant_id=? AND phone=?",
                            (tenant["id"], phone)).fetchone()
    if existing:
        conn.close()
        return f"+{phone} is already a member."
    conn.execute("INSERT INTO sacco_members (tenant_id,phone,full_name,status) VALUES (?,?,?,'active')",
                 (tenant["id"], phone, name))
    _audit(conn, tenant["id"], admin_phone, "MEMBER_ADDED", None)
    conn.commit()
    conn.close()
    whatsapp.send(phone,
        f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"  🎉 Welcome to {tenant['name']}!\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"You've been added as a member.\n"
        f"Type *balance* to see your account.\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━")
    return f"✅ {name} (+{phone}) added."

def _admin_balance(text, tenant):
    q = text.replace("BALANCE","",1).strip()
    m = _find_member(q, tenant["id"])
    if not m: return f"Member '{q}' not found."
    return _balance(m, tenant)

def _list_members(tenant):
    conn = get_db()
    members = conn.execute(
        "SELECT full_name, phone, savings_balance, loan_balance, shares, status "
        "FROM sacco_members WHERE tenant_id=? ORDER BY full_name",
        (tenant["id"],)).fetchall()
    conn.close()
    if not members: return "No members registered yet."
    lines = []
    for m in members:
        status = "🟢" if m["status"]=="active" else ("⏳" if m["status"]=="pending_approval" else "🔴")
        lines.append(f"  {status} {m['full_name']}\n     +{m['phone']} · UGX {m['savings_balance']:,}")
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  👥 {tenant['name']} Members\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
            "\n".join(lines) + "\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def _monthly_report(tenant):
    conn = get_db()
    stats = conn.execute(
        "SELECT COUNT(*) members, COALESCE(SUM(savings_balance),0) savings, COALESCE(SUM(loan_balance),0) loans "
        "FROM sacco_members WHERE tenant_id=? AND status='active'", (tenant["id"],)).fetchone()
    month = conn.execute(
        "SELECT COALESCE(SUM(amount_ugx),0) deps, COUNT(*) dep_cnt FROM sacco_transactions "
        "WHERE tenant_id=? AND type IN ('deposit','cash_deposit') AND created_at >= date('now','start of month')",
        (tenant["id"],)).fetchone()
    pending = conn.execute("SELECT COUNT(*) n FROM deposit_queue WHERE tenant_id=? AND status='pending'",
                           (tenant["id"],)).fetchone()["n"]
    conn.close()
    mo = datetime.now().strftime("%B %Y")
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📊 {tenant['name']} — {mo}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👥 Active members:    {stats['members']}\n"
            f"💰 Total savings:     UGX {int(stats['savings']):,}\n"
            f"💳 Loans outstanding: UGX {int(stats['loans']):,}\n\n"
            f"This month:\n"
            f"  Deposits: {month['dep_cnt']} · UGX {int(month['deps']):,}\n\n"
            f"⏳ Pending approvals: {pending}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

def _suspend(text, admin_phone, tenant, do_suspend):
    cmd = "SUSPEND" if do_suspend else "REINSTATE"
    phone = re.sub(r"\D","", text.replace(cmd,"",1).strip())
    status = "suspended" if do_suspend else "active"
    conn = get_db()
    conn.execute("UPDATE sacco_members SET status=? WHERE tenant_id=? AND phone=?",
                 (status, tenant["id"], phone))
    _audit(conn, tenant["id"], admin_phone, f"MEMBER_{cmd}ED", None)
    conn.commit(); conn.close()
    return f"{'🔴' if do_suspend else '🟢'} Member +{phone} {status}."

def _show_rules(tenant):
    rules = _get_rules(tenant["id"])
    if not rules:
        return "No rules set. Use: *SET RULE monthly_contribution 50000*"
    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  📜 {tenant['name']} Rules\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
           f"Monthly contribution: UGX {rules['monthly_contrib_ugx']:,}\n"
           f"Contribution day:     {rules['contrib_day']}\n"
           f"Grace period:         {rules['grace_days']} days\n"
           f"Late penalty:         UGX {rules['late_penalty_ugx']:,}\n"
           f"Loan limit:           {rules['loan_multiplier']}× savings\n"
           f"Interest rate:        {rules['interest_rate']}%/month\n"
           f"Loan term:            {rules['loan_term_months']} months\n")
    if rules.get("is_merry_go_round"):
        msg += f"\n🔄 Merry-go-round: UGX {rules['round_amount']:,}/round\n"
        msg += f"   Current round: {rules['current_round']}\n"
    msg += f"━━━━━━━━━━━━━━━━━━━━━━━━━"
    return msg

def _set_rule(text, admin_phone, tenant):
    parts = text.replace("SET RULE","",1).strip().split()
    if len(parts)<2: return "Format: *SET RULE [field] [value]*"
    field_map = {"monthly_contribution":"monthly_contrib_ugx","loan_multiplier":"loan_multiplier",
                 "interest_rate":"interest_rate","loan_term":"loan_term_months",
                 "late_penalty":"late_penalty_ugx","grace_days":"grace_days",
                 "merry_go_round":"is_merry_go_round","round_amount":"round_amount",
                 "share_price":"share_price","contrib_day":"contrib_day"}
    key = parts[0].lower()
    db_field = field_map.get(key, key)
    value = " ".join(parts[1:])
    conn = get_db()
    existing = conn.execute("SELECT id FROM sacco_rules WHERE tenant_id=?", (tenant["id"],)).fetchone()
    if existing:
        conn.execute(f"UPDATE sacco_rules SET {db_field}=? WHERE tenant_id=?", (value, tenant["id"]))
    else:
        conn.execute(f"INSERT INTO sacco_rules (tenant_id, {db_field}) VALUES (?,?)", (tenant["id"], value))
    _audit(conn, tenant["id"], admin_phone, "RULE_UPDATED", None)
    conn.commit(); conn.close()
    return f"✅ Updated: {key} → {value}"


# ═══════════════════════════════════════════════════════════════════════════════
# HELP
# ═══════════════════════════════════════════════════════════════════════════════

def _help(is_admin, tenant):
    rules = _get_rules(tenant["id"])
    is_mgr = rules.get("is_merry_go_round") if rules else False
    if is_admin:
        msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
               f"  🏦 {tenant['name']} — Admin\n"
               f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
               f"👥 MEMBERS · QUEUE · REPORT\n"
               f"✅ APPROVE [id] · ❌ REJECT [id]\n"
               f"➕ ADD MEMBER [phone] [name]\n"
               f"💵 DEPOSIT [name] [amount] cash\n"
               f"📅 MEETING [day] [time] [place]\n"
               f"📅 MEETING DONE [count] present [amount]\n"
               f"📜 RULES · SET RULE [field] [value]\n"
               f"📊 ANNUAL REPORT\n")
        if is_mgr:
            msg += f"🔄 ROUND DONE · SET ROTATION\n"
        msg += f"\n━━━━━━━━━━━━━━━━━━━━━━━━━"
        return msg
    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  🏦 {tenant['name']}\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
           f"Just ask naturally:\n"
           f"  💰 \"balance\" or \"my money\"\n"
           f"  📄 \"statement\" or \"history\"\n"
           f"  💳 \"loan 300000\"\n"
           f"  📜 \"rules\"\n\n"
           f"To deposit: paste your MoMo\n"
           f"confirmation message here.\n")
    if is_mgr:
        msg += f"\n🔄 \"my turn\" to check rotation\n"
    msg += f"━━━━━━━━━━━━━━━━━━━━━━━━━"
    return msg


# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _tenant(session):
    if "tenant" in session: return session["tenant"]
    conn = get_db()
    t = conn.execute("SELECT * FROM tenants WHERE id=?", (session["tenant_id"],)).fetchone()
    conn.close()
    if t: session["tenant"] = dict(t)
    return dict(t) if t else {}

def _get_member(phone, tenant_id):
    conn = get_db()
    m = conn.execute("SELECT * FROM sacco_members WHERE tenant_id=? AND phone=? AND status='active'",
                     (tenant_id, phone)).fetchone()
    conn.close()
    return dict(m) if m else None

def _find_member(query, tenant_id):
    """Find member by name fragment or phone."""
    conn = get_db()
    q = query.strip()
    # Try phone
    digits = re.sub(r"\D","",q)
    if digits:
        m = conn.execute("SELECT * FROM sacco_members WHERE tenant_id=? AND phone LIKE ?",
                         (tenant_id, f"%{digits}%")).fetchone()
        if m: conn.close(); return dict(m)
    # Try name
    m = conn.execute("SELECT * FROM sacco_members WHERE tenant_id=? AND LOWER(full_name) LIKE ?",
                     (tenant_id, f"%{q.lower()}%")).fetchone()
    conn.close()
    return dict(m) if m else None

def _get_rules(tenant_id):
    conn = get_db()
    r = conn.execute("SELECT * FROM sacco_rules WHERE tenant_id=?", (tenant_id,)).fetchone()
    conn.close()
    return dict(r) if r else None

def _is_admin(phone, tenant_id):
    conn = get_db()
    row = conn.execute("SELECT 1 FROM tenant_admins WHERE tenant_id=? AND phone=?",
                       (tenant_id, phone)).fetchone()
    conn.close()
    return row is not None

def _get_admins(tenant_id):
    conn = get_db()
    rows = conn.execute("SELECT phone FROM tenant_admins WHERE tenant_id=?", (tenant_id,)).fetchall()
    conn.close()
    return [r["phone"] for r in rows]

def _get_all_members(tenant_id):
    conn = get_db()
    rows = conn.execute("SELECT * FROM sacco_members WHERE tenant_id=? AND status='active'",
                        (tenant_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def _get_position(member_id, tenant_id):
    conn = get_db()
    r = conn.execute("SELECT position FROM rotation_order WHERE tenant_id=? AND member_id=?",
                     (tenant_id, member_id)).fetchone()
    conn.close()
    return r["position"] if r else None

def _admin_name(phone, tenant_id):
    m = _find_member(phone, tenant_id)
    return m["full_name"] if m else f"+{phone}"

def _audit(conn, tenant_id, actor, action, target_id):
    conn.execute("INSERT INTO audit_log (tenant_id,actor_phone,action,target_id) VALUES (?,?,?,?)",
                 (tenant_id, actor, action, target_id))
