"""
app/modules/groups.py

Handles wedding committees, funeral groups, harambees, and any
event-based fundraising group.
"""

import json
import re
from datetime import datetime
from app.database import get_db
from app.services import gemini, whatsapp, pdf_gen
from app.services.admin_controls import (
    get_menu, handle_menu_number, broadcast, remind_unpaid_pledges,
    handle_broadcast_context
)
from app.services import session_store as sessions

FINANCIAL_RE = re.compile(
    r"\b(pledge|paid|pay|contribute|contribution|ugx|shilling|\d{3,}|balance|total|budget|owing|cleared|collected)\b",
    re.IGNORECASE
)


def handle(message: str, phone: str, session: dict, image_bytes: bytes = None) -> str:
    tenant   = _get_tenant(session["tenant_id"])
    is_admin = _check_admin(phone, tenant["id"])
    text     = message.strip()
    textup   = text.upper()
    tl       = text.lower()

    if image_bytes:
        return _handle_payment_screenshot(image_bytes, phone, tenant, session)

    if not text:
        return ""

    # ── Admin broadcast context ───────────────────────────────────────────────
    if is_admin:
        bc = handle_broadcast_context(text, phone, tenant, session)
        if bc is not None:
            return bc

    if textup in ("HELP", "?", "MENU"):
        if is_admin:
            return get_menu("GROUPS")
        return _help(False)

    # ── Natural language budget setting ────────────────────────────────────────
    # "set budget 5000000" / "target is 5m" / "we need 8 million"
    if is_admin and any(w in tl for w in ["budget","target","goal","we need","raise"]):
        import re
        nums = re.findall(r"(\d[\d,]*(?:\.\d+)?)\s*(?:million|m)?", text, re.I)
        if nums:
            raw = nums[0].replace(",","")
            amount = float(raw)
            if "million" in tl or (amount < 1000 and "m" in tl.split()):
                amount *= 1_000_000
            amount = int(amount)
            if amount > 0:
                event = _get_active_event(tenant["id"])
                if event:
                    conn = get_db()
                    conn.execute("UPDATE group_events SET target_budget=? WHERE id=?",
                                 (amount, event["id"]))
                    conn.commit()
                    conn.close()
                    return (f"Budget set to *UGX {amount:,}* for {event['event_name']}. ✓\n\n"
                            f"Share your Weza number so contributors can start pledging.")

    # ── Natural language event type / description ──────────────────────────────
    if is_admin:
        EVENT_TYPES = {"wedding":"wedding","funeral":"funeral","burial":"funeral",
                       "harambee":"harambee","fundrais":"harambee","church":"general",
                       "memorial":"funeral","introduction":"wedding","kwanjula":"wedding"}
        for word, etype in EVENT_TYPES.items():
            if word in tl:
                event = _get_active_event(tenant["id"])
                if event and event["event_type"] == "general":
                    conn = get_db()
                    conn.execute("UPDATE group_events SET event_type=? WHERE id=?",
                                 (etype, event["id"]))
                    conn.commit()
                    conn.close()
                    # Don't return — let it fall through to other handlers

    if is_admin and textup.isdigit() and 1 <= int(textup) <= 8:
        return handle_menu_number(int(textup), "GROUPS", phone, tenant, session)

    if is_admin and textup.startswith("BROADCAST "):
        return broadcast(tenant, text[10:].strip(), phone)

    if is_admin and textup in ("REMIND", "REMINDER"):
        return remind_unpaid_pledges(tenant, phone)

    # Admin commands
    if is_admin:
        if textup.startswith("CREATE EVENT "):
            return _create_event(text, phone, tenant)
        if textup == "PLEDGES":
            return _list_pledges(tenant)
        if textup == "UNPAID":
            return _list_unpaid(tenant)
        if textup == "REPORT":
            return _transparency_report(tenant)
        if textup == "CLOSE EVENT":
            return _close_event(phone, tenant)

    # Catchup summary
    if "CATCHUP" in textup or "@BOT CATCHUP" in text.lower():
        return _catchup(tenant)

    event = _get_active_event(tenant["id"])
    if not event:
        if is_admin:
            return ("No active event.\n\nCreate one:\n"
                    "*CREATE EVENT [name] [type] [budget]*\n"
                    "Types: wedding | funeral | harambee | general\n\n"
                    "Example: _CREATE EVENT Nakato Wedding wedding 5000000_")
        return "No active event right now. Ask your organiser to set one up."

    if textup in ("TOTAL", "PROGRESS", "STATUS"):
        return _progress(event)

    if textup == "MY PLEDGE":
        return _my_pledge(phone, event)

    if textup.startswith("PLEDGE "):
        amount = _parse_amount(text.replace("PLEDGE ", "", 1))
        return _record_pledge(phone, _get_sender_name(phone, tenant), event, tenant, amount, is_draft=False)

    if textup.startswith("PAID "):
        return _record_payment(text, phone, _get_sender_name(phone, tenant), event, tenant)

    # Shadow ledger — passive financial detection
    if FINANCIAL_RE.search(text):
        intent = gemini.detect_financial_intent(text, _get_sender_name(phone, tenant))
        if intent.get("isPledge") and intent.get("amount", 0) > 0 and intent.get("confidence", 0) > 0.7:
            _record_pledge(phone, intent.get("personName", "Unknown"), event, tenant,
                           intent["amount"], is_draft=True)
    return ""  # silent for non-matching group messages


# ── Create event ──────────────────────────────────────────────────────────────

def _create_event(text: str, phone: str, tenant: dict) -> str:
    parts = text.replace("CREATE EVENT ", "", 1).strip().split()
    if len(parts) < 2:
        return ("Format: *CREATE EVENT [name] [type] [budget]*\n"
                "Example: _CREATE EVENT Nakato Wedding wedding 5000000_")

    budget = _parse_amount(parts[-1])
    etype  = parts[-2].lower() if len(parts) > 2 else "general"
    name   = " ".join(parts[:-2]) if len(parts) > 2 else " ".join(parts[:-1])
    if budget == 0:
        budget = _parse_amount(parts[-1])
        etype  = "general"
        name   = " ".join(parts[:-1])

    conn = get_db()
    conn.execute("UPDATE group_events SET status='closed' WHERE tenant_id=? AND status='active'", (tenant["id"],))
    conn.execute(
        "INSERT INTO group_events (tenant_id, event_name, event_type, target_budget) VALUES (?,?,?,?)",
        (tenant["id"], name, etype, budget)
    )
    conn.commit()
    conn.close()

    return (f"Event created!\n\n*{name}*\nType: {etype}\nBudget: UGX {budget:,}\n\n"
            "Members can now:\n"
            "_PLEDGE 50000_ — record a pledge\n"
            "_PAID 50000 MP123_ — confirm payment\n"
            "_TOTAL_ — see progress")


# ── Record pledge ─────────────────────────────────────────────────────────────

def _record_pledge(phone: str, name: str, event: dict, tenant: dict, amount: int, is_draft: bool) -> str:
    if amount <= 0:
        return "Please specify an amount. Example: _PLEDGE 50000_"

    conn = get_db()
    existing = conn.execute(
        "SELECT * FROM pledges WHERE event_id=? AND member_phone=?",
        (event["id"], phone)
    ).fetchone()

    if existing:
        conn.execute(
            "UPDATE pledges SET pledged_ugx=?, is_draft=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (amount, 1 if is_draft else 0, existing["id"])
        )
    else:
        conn.execute(
            """INSERT INTO pledges (event_id, tenant_id, member_phone, member_name, pledged_ugx, is_draft)
               VALUES (?,?,?,?,?,?)""",
            (event["id"], tenant["id"], phone, name, amount, 1 if is_draft else 0)
        )
    conn.commit()
    conn.close()

    if is_draft:
        return ""  # silent for shadow ledger

    return (f"Pledge recorded!\n\n*{event['event_name']}*\n"
            f"Your pledge: UGX {amount:,}\n\n"
            "When you pay:\n*PAID [amount] [MoMo ref]*\nExample: _PAID 50000 MP123456_")


# ── Record payment ─────────────────────────────────────────────────────────────

def _record_payment(text: str, phone: str, name: str, event: dict, tenant: dict) -> str:
    parts  = text.replace("PAID ", "", 1).split()
    amount = _parse_amount(parts[0]) if parts else 0
    ref    = parts[1] if len(parts) > 1 else None

    if amount <= 0:
        return "Format: *PAID [amount] [MoMo ref]*\nExample: _PAID 50000 MP123456_"

    # Duplicate check
    if ref:
        conn = get_db()
        dup = conn.execute(
            "SELECT id FROM pledges WHERE event_id=? AND transaction_ref=?",
            (event["id"], ref)
        ).fetchone()
        if dup:
            conn.close()
            return f"This reference has already been recorded.\nRef: {ref}"
        conn.close()

    conn = get_db()
    pledge = conn.execute(
        "SELECT * FROM pledges WHERE event_id=? AND member_phone=?",
        (event["id"], phone)
    ).fetchone()

    if pledge:
        new_paid  = pledge["paid_ugx"] + amount
        new_status = "cleared" if new_paid >= pledge["pledged_ugx"] else "partial"
        conn.execute(
            "UPDATE pledges SET paid_ugx=?, status=?, transaction_ref=?, is_draft=0, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (new_paid, new_status, ref, pledge["id"])
        )
    else:
        conn.execute(
            """INSERT INTO pledges (event_id, tenant_id, member_phone, member_name, pledged_ugx, paid_ugx, status, transaction_ref, is_draft)
               VALUES (?,?,?,?,?,?,'cleared',?,0)""",
            (event["id"], tenant["id"], phone, name, amount, amount, ref)
        )

    conn.execute(
        "UPDATE group_events SET collected_total=collected_total+? WHERE id=?",
        (amount, event["id"])
    )
    conn.commit()

    ev = conn.execute("SELECT * FROM group_events WHERE id=?", (event["id"],)).fetchone()
    conn.close()

    pct = int(ev["collected_total"] / ev["target_budget"] * 100) if ev["target_budget"] else 0
    return (f"Payment recorded!\n\n"
            f"{name}: UGX {amount:,}{f' | Ref: {ref}' if ref else ''}\n\n"
            f"*{ev['event_name']} — {pct}% reached*\n"
            f"Collected: UGX {ev['collected_total']:,} / UGX {ev['target_budget']:,}")


# ── Payment screenshot from buyer ─────────────────────────────────────────────

def _handle_payment_screenshot(image_bytes: bytes, phone: str, tenant: dict, session: dict) -> str:
    event = _get_active_event(tenant["id"])
    if not event:
        return "No active event to record payment for."

    momo = gemini.read_momo_screenshot(image_bytes)
    if not momo or not momo.get("isConfirmation"):
        return "I couldn't read that screenshot. Please send the full MoMo confirmation."

    return _record_payment(
        f"PAID {momo.get('amount', 0)} {momo.get('transactionId', '')}",
        phone, _get_sender_name(phone, tenant), event, tenant
    )


# ── Progress ──────────────────────────────────────────────────────────────────

def _progress(event: dict) -> str:
    conn = get_db()
    stats = conn.execute(
        """SELECT COUNT(*) total, COUNT(CASE WHEN status='cleared' THEN 1 END) cleared,
                  SUM(pledged_ugx) pledged
           FROM pledges WHERE event_id=? AND is_draft=0""",
        (event["id"],)
    ).fetchone()
    conn.close()

    pct = int(event["collected_total"] / event["target_budget"] * 100) if event["target_budget"] else 0
    remaining = max(0, event["target_budget"] - event["collected_total"])

    return (f"*{event['event_name']}*\n\n"
            f"Budget:    UGX {event['target_budget']:,}\n"
            f"Collected: UGX {event['collected_total']:,} ({pct}%)\n"
            f"Remaining: UGX {remaining:,}\n\n"
            f"Pledges:   {stats['total']} total | {stats['cleared']} cleared\n"
            f"Total pledged: UGX {int(stats['pledged'] or 0):,}")


# ── My pledge ─────────────────────────────────────────────────────────────────

def _my_pledge(phone: str, event: dict) -> str:
    conn = get_db()
    p = conn.execute(
        "SELECT * FROM pledges WHERE event_id=? AND member_phone=?",
        (event["id"], phone)
    ).fetchone()
    conn.close()

    if not p:
        return (f"No pledge for *{event['event_name']}* yet.\n\nTo pledge: _PLEDGE 50000_")

    balance = p["pledged_ugx"] - p["paid_ugx"]
    return (f"*Your pledge — {event['event_name']}*\n\n"
            f"Pledged: UGX {p['pledged_ugx']:,}\n"
            f"Paid:    UGX {p['paid_ugx']:,}\n"
            f"Balance: UGX {balance:,}\n"
            f"Status:  {p['status'].upper()}\n"
            + (f"Ref:     {p['transaction_ref']}" if p["transaction_ref"] else ""))


# ── Catchup summary ────────────────────────────────────────────────────────────

def _catchup(tenant: dict) -> str:
    event = _get_active_event(tenant["id"])
    if not event:
        return "No active event to summarise."

    conn = get_db()
    pledges = conn.execute(
        "SELECT member_name, pledged_ugx, paid_ugx, status FROM pledges WHERE event_id=? ORDER BY updated_at DESC LIMIT 20",
        (event["id"],)
    ).fetchall()
    conn.close()

    summary = gemini.summarise_group_activity(
        event["event_name"], event["target_budget"],
        event["collected_total"], [dict(p) for p in pledges]
    )
    return f"*Catchup — {event['event_name']}*\n\n{summary}"


# ── Admin: pledge list ────────────────────────────────────────────────────────

def _list_pledges(tenant: dict) -> str:
    event = _get_active_event(tenant["id"])
    if not event:
        return "No active event."
    conn = get_db()
    rows = conn.execute(
        "SELECT member_name, member_phone, pledged_ugx, paid_ugx, status, is_draft FROM pledges WHERE event_id=? ORDER BY status, member_name",
        (event["id"],)
    ).fetchall()
    conn.close()
    if not rows:
        return "No pledges recorded yet."
    lines = [
        f"{r['member_name']} — UGX {r['paid_ugx']:,}/{r['pledged_ugx']:,} [{r['status']}]{' *DRAFT*' if r['is_draft'] else ''}"
        for r in rows
    ]
    return f"*{event['event_name']} — All Pledges*\n\n" + "\n".join(lines)


# ── Admin: unpaid ─────────────────────────────────────────────────────────────

def _list_unpaid(tenant: dict) -> str:
    event = _get_active_event(tenant["id"])
    if not event:
        return "No active event."
    conn = get_db()
    rows = conn.execute(
        """SELECT member_name, member_phone, pledged_ugx, paid_ugx
           FROM pledges WHERE event_id=? AND status IN ('pledged','partial') AND is_draft=0
           ORDER BY (pledged_ugx-paid_ugx) DESC""",
        (event["id"],)
    ).fetchall()
    conn.close()
    if not rows:
        return "Everyone has cleared their pledges!"
    lines = [f"{r['member_name']} (+{r['member_phone']})\n  Owes: UGX {r['pledged_ugx']-r['paid_ugx']:,}" for r in rows]
    return f"*Outstanding — {event['event_name']}*\n\n" + "\n\n".join(lines)


# ── Admin: transparency report ────────────────────────────────────────────────

def _transparency_report(tenant: dict) -> str:
    event = _get_active_event(tenant["id"])
    if not event:
        return "No active event."
    conn = get_db()
    pledges = conn.execute(
        "SELECT * FROM pledges WHERE event_id=? ORDER BY status", (event["id"],)
    ).fetchall()
    conn.close()
    pct = int(event["collected_total"]/event["target_budget"]*100) if event["target_budget"] else 0
    cleared = sum(1 for p in pledges if p["status"] == "cleared")
    pending = sum(1 for p in pledges if p["status"] in ("pledged","partial"))

    return (f"*Transparency Report — {event['event_name']}*\n"
            f"Generated: {datetime.now().strftime('%d %b %Y %I:%M %p')}\n\n"
            f"Budget:    UGX {event['target_budget']:,}\n"
            f"Collected: UGX {event['collected_total']:,} ({pct}%)\n"
            f"Remaining: UGX {max(0,event['target_budget']-event['collected_total']):,}\n\n"
            f"Cleared pledges: {cleared}\n"
            f"Pending pledges: {pending}")


# ── Admin: close event ────────────────────────────────────────────────────────

def _close_event(phone: str, tenant: dict) -> str:
    event = _get_active_event(tenant["id"])
    if not event:
        return "No active event."
    conn = get_db()
    conn.execute("UPDATE group_events SET status='closed' WHERE id=?", (event["id"],))
    conn.commit()
    conn.close()
    return f"Event *{event['event_name']}* closed.\nFinal: UGX {event['collected_total']:,} of UGX {event['target_budget']:,}"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _get_active_event(tenant_id: int) -> dict | None:
    conn = get_db()
    row  = conn.execute(
        "SELECT * FROM group_events WHERE tenant_id=? AND status='active' ORDER BY created_at DESC LIMIT 1",
        (tenant_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def _parse_amount(s: str) -> int:
    s = str(s).replace(",", "").strip()
    if s.lower().endswith("k"):
        return int(s[:-1]) * 1000
    try:
        return int(s)
    except ValueError:
        return 0


def _get_sender_name(phone: str, tenant: dict) -> str:
    conn = get_db()
    member = conn.execute(
        "SELECT full_name FROM sacco_members WHERE phone=? AND tenant_id=? LIMIT 1",
        (phone, tenant["id"])
    ).fetchone()
    conn.close()
    return member["full_name"] if member else f"+{phone}"


def _get_tenant(tenant_id: int) -> dict | None:
    conn = get_db()
    row  = conn.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def _check_admin(phone: str, tenant_id: int) -> bool:
    conn = get_db()
    row  = conn.execute(
        "SELECT 1 FROM tenant_admins WHERE tenant_id=? AND phone=?", (tenant_id, phone)
    ).fetchone()
    conn.close()
    return row is not None


def _help(is_admin: bool) -> str:
    msg = ("*Pledge commands:*\n"
           "_PLEDGE 50000_ — record your pledge\n"
           "_PAID 50000 MP123_ — mark as paid\n"
           "_MY PLEDGE_ — my status\n"
           "_TOTAL_ — event progress\n"
           "_CATCHUP_ — AI summary\n")
    if is_admin:
        msg += ("\n*Organiser commands:*\n"
                "_CREATE EVENT [name] [type] [budget]_\n"
                "_PLEDGES_ — all pledges\n"
                "_UNPAID_ — outstanding balances\n"
                "_REPORT_ — transparency summary\n"
                "_CLOSE EVENT_")
    msg += "\n\nType *EXIT* to leave."
    return msg
