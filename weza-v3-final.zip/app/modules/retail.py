"""
app/modules/retail.py — Marketplace Module v3

Connection-based: buyer finds product → connects to seller → they deal directly.
Seller records sale → builds trust score → appears higher in search.

Seller commands: ADD, REMOVE, PRICE, STOCK, SALES, SOLD, LEADS, VERIFY
Buyer flow: search → browse catalog → pick shop → connect to seller
"""
import json, re
from datetime import datetime
from app.database import get_db
from app.services import whatsapp
from app.services import session_store as sessions
from app.services.gemini import read_momo_text, parse_inventory_text
from app.services.admin_controls import (
    get_menu, handle_menu_number, broadcast,
    handle_broadcast_context, pending_orders
)
from app.services.verification import get_verify_prompt, process_verification_payment, get_verification_status, save_location, complete_verification

UPSELL = {"cement":"iron bars","iron bars":"binding wire","sugar":"flour",
          "flour":"cooking oil","rice":"cooking oil","paint":"brushes","tiles":"tile adhesive"}

def handle(message: str, phone: str, session: dict, image_bytes: bytes = None) -> str:
    tenant = _get_tenant(session["tenant_id"])
    is_admin = _check_admin(phone, tenant["id"])
    text = message.strip()
    textup = text.upper()
    tl = text.lower()
    ctx = session.get("context", {})

    # ── Photo handling ─────────────────────────────────────────────────────
    if image_bytes:
        if is_admin:
            # Admin sent photo — store as product image (ask for name+price next)
            session.setdefault("context", {})["pending_photo"] = True
            sessions.update_context(phone, session.get("context", {}))
            return ("📸 Photo received!\n\n"
                    "Now type the product name and price.\n"
                    "Example: _Red dress 45000_\n"
                    "Or: _Kitenge dress 45000 S M L XL_")
        return _buyer_momo_screenshot(image_bytes, phone, tenant, session)

    if not text: return ""

    # ── Admin broadcast context ────────────────────────────────────────────
    if is_admin:
        bc = handle_broadcast_context(text, phone, tenant, session)
        if bc is not None: return bc

    # ── Verification flow ──────────────────────────────────────────────────
    if is_admin and ctx.get("verifying"):
        return _handle_verification_step(text, phone, tenant, session)

    # ── Admin commands ─────────────────────────────────────────────────────
    if is_admin:
        if textup in ("HELP","?","MENU"):
            return _help(True, tenant)
        if textup == "STOCK":
            return _stock_list(tenant)
        if textup == "SALES":
            return _sales_report(tenant)
        if textup == "LEADS":
            return _leads_report(tenant)
        if textup == "VERIFY":
            vs = get_verification_status(tenant["id"])
            if tenant.get("is_verified"):
                return "✅ Your shop is already verified!"
            if vs["step"] == "needs_location":
                session.setdefault("context", {})["verifying"] = "location"
                return "📍 Share your shop location via WhatsApp.\nOr type your address."
            session.setdefault("context", {})["verifying"] = "payment"
            return get_verify_prompt()
        if textup.startswith("SOLD "):
            return _record_sale(text, phone, tenant)
        if textup.startswith("ADD "):
            return _add_product(text, phone, tenant)
        if textup.startswith("REMOVE "):
            return _remove_product(text, phone, tenant)
        if textup.startswith("PRICE "):
            return _update_price(text, phone, tenant)

        # Admin sent name+price after photo
        if ctx.get("pending_photo"):
            return _add_product_from_photo(text, phone, tenant, session)

        result = handle_menu_number(textup, phone, tenant)
        if result is not None: return result

    # ── Buyer browsing catalog ─────────────────────────────────────────────
    if textup in ("BROWSE","CATALOG","PRODUCTS"):
        return _show_catalog(tenant)

    # ── Buyer selecting from catalog (number reply) ────────────────────────
    if ctx.get("catalog_shown") and text.isdigit():
        return _select_product(int(text), phone, tenant, session)

    # ── Buyer wants to connect with seller ─────────────────────────────────
    CONNECT_WORDS = ["connect","seller","talk","contact","call","chat","direct"]
    if any(w in tl for w in CONNECT_WORDS):
        return _connect_to_seller(phone, tenant)

    # ── Product search (buyer) — only if it looks like shopping ──────────
    SHOP_SIGNALS = ["buy","need","want","price","cost","how much","show","find",
                    "nfuna","nataka","njagala","acheter","do you have","browse",
                    "catalog","products","what do you"]
    if any(w in tl for w in SHOP_SIGNALS):
        return _product_search(text, phone, tenant, session)

    # ── Short text that might be a product name (but NOT a keyword) ──────
    if len(text.split()) <= 2 and text.isalpha():
        # Check if it's a keyword for another tenant — if so, DON'T handle it
        conn = get_db()
        other = conn.execute("SELECT id FROM tenants WHERE UPPER(keyword)=? AND is_active=1",
                             (textup,)).fetchone()
        conn.close()
        if other:
            return None  # Signal to router: "I can't handle this, it's for another tenant"
        # Not a keyword — try as product search within this shop
        return _product_search(text, phone, tenant, session)

    # ── Anything else — return None to let the router handle it ──────────
    # This prevents the "stuck in shop" trap
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# BUYER FLOW
# ═══════════════════════════════════════════════════════════════════════════════

def _show_catalog(tenant):
    conn = get_db()
    products = conn.execute(
        "SELECT * FROM products WHERE tenant_id=? AND is_available=1 ORDER BY category, name",
        (tenant["id"],)).fetchall()
    conn.close()
    if not products:
        return "No products listed yet."

    verified = " ✅" if tenant.get("is_verified") else ""
    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  🛒 {tenant['name']}{verified}\n")
    if tenant.get("location"):
        msg += f"  📍 {tenant['location']}\n"
    msg += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"

    for i, p in enumerate(products, 1):
        p = dict(p)
        sizes = ""
        if p.get("sizes") and p["sizes"] != "[]":
            try: sizes = f"\n     Sizes: {', '.join(json.loads(p['sizes']))}"
            except: pass
        stock = ""
        if p.get("stock_qty",0) > 0:
            stock = f" ({p['stock_qty']} in stock)"
        msg += (f"{i}️⃣ *{p['name']}*\n"
                f"   UGX {p['price_ugx']:,}/{p['unit']}{stock}{sizes}\n\n")

    msg += (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"Reply with a number for details.\n"
            f"📞 Contact seller: wa.me/{tenant.get('wa_direct', tenant['owner_phone'])}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return msg

def _select_product(num, phone, tenant, session):
    conn = get_db()
    products = conn.execute(
        "SELECT * FROM products WHERE tenant_id=? AND is_available=1 ORDER BY category, name",
        (tenant["id"],)).fetchall()
    conn.close()
    if num < 1 or num > len(products):
        return f"Reply with a number between 1 and {len(products)}."
    p = dict(products[num-1])

    # Record lead
    conn = get_db()
    conn.execute("INSERT INTO leads (buyer_phone,tenant_id,product_name,product_id) VALUES (?,?,?,?)",
                 (phone, tenant["id"], p["name"], p["id"]))
    conn.execute("UPDATE tenants SET total_leads=total_leads+1 WHERE id=?", (tenant["id"],))
    conn.commit()
    conn.close()

    seller_phone = tenant.get("wa_direct") or tenant["owner_phone"]
    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  {p['name']}\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
           f"💰 UGX {p['price_ugx']:,}/{p['unit']}\n")
    if p.get("bulk_price_ugx"):
        msg += f"📦 Bulk ({p['bulk_min_qty']}+): UGX {p['bulk_price_ugx']:,} each\n"
    if p.get("description"):
        msg += f"\n{p['description']}\n"
    msg += (f"\n📞 *Contact seller:*\n"
            f"wa.me/{seller_phone}\n\n"
            f"I've let them know you're interested!\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")

    # Notify seller
    whatsapp.send(tenant["owner_phone"],
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"  🔔 NEW CUSTOMER LEAD\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Looking for: {p['name']}\n"
        f"Budget: UGX {p['price_ugx']:,}\n"
        f"Buyer: +{phone}\n\n"
        f"They may message you.\n"
        f"After sale: *SOLD {p['name'].lower()} 1 {p['price_ugx']} [momo ref]*\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━")
    return msg

def _connect_to_seller(phone, tenant):
    seller_phone = tenant.get("wa_direct") or tenant["owner_phone"]
    conn = get_db()
    conn.execute("INSERT INTO leads (buyer_phone,tenant_id,product_name) VALUES (?,?,'direct_contact')",
                 (phone, tenant["id"]))
    conn.execute("UPDATE tenants SET total_leads=total_leads+1 WHERE id=?", (tenant["id"],))
    conn.commit(); conn.close()
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📞 {tenant['name']}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"WhatsApp: wa.me/{seller_phone}\n")

def _product_search(text, phone, tenant, session):
    conn = get_db()
    kw = text.lower().strip()
    # Remove common non-product words before searching
    skip = {"i","a","the","want","need","buy","please","do","you","have","any","some",
            "me","show","find","get","nfuna","nataka","njagala","looking","for"}
    words = [w for w in kw.split() if w not in skip and len(w) > 1]
    search_term = " ".join(words) if words else kw

    products = conn.execute(
        "SELECT * FROM products WHERE tenant_id=? AND is_available=1 AND "
        "(LOWER(name) LIKE ? OR LOWER(category) LIKE ? OR LOWER(COALESCE(name_luganda,'')) LIKE ?)",
        (tenant["id"], f"%{search_term}%", f"%{search_term}%", f"%{search_term}%")).fetchall()
    conn.close()

    if not products:
        # Nothing in this shop — search ALL shops
        from app.services.weza_ai import search_products, search_products_broad
        global_results = search_products(search_term) if len(search_term) > 1 else []
        if not global_results:
            global_results = search_products_broad(text)
        if global_results:
            from app.services.weza_ai import _format_product_results
            return ("🔍 Not found at *" + tenant["name"] + "*, but found elsewhere:\n\n"
                    + _format_product_results(global_results, search_term)
                    + "\n\nType *EXIT* to leave this shop.")
        return (f"🔍 No results for \"{text}\" anywhere on Weza.\n\n"
                f"Type *BROWSE* to see {tenant['name']}'s products,\n"
                f"or *EXIT* to go home.")
    if len(products) == 1:
        session.setdefault("context", {})["catalog_shown"] = True
        return _select_product(1, phone, tenant, session)
    session.setdefault("context", {})["catalog_shown"] = True
    return _show_catalog(tenant)


# ═══════════════════════════════════════════════════════════════════════════════
# SELLER: RECORD SALE
# ═══════════════════════════════════════════════════════════════════════════════

def _record_sale(text, phone, tenant):
    """SOLD [product] [qty] [amount] [momo_ref]"""
    clean = text.replace("SOLD","",1).strip()
    # Extract numbers
    nums = re.findall(r"\d[\d,]*", clean)
    qty = int(nums[0].replace(",","")) if len(nums)>=1 and int(nums[0].replace(",",""))<=1000 else 1
    amount = 0
    for n in nums:
        val = int(n.replace(",",""))
        if val > 1000:
            amount = val; break
    ref = ""
    ref_match = re.search(r"(MP\d{6,}|AT-\d+|[A-Z]{2,}\d{6,})", clean, re.I)
    if ref_match: ref = ref_match.group(1)
    # Product name = everything before the first number
    pname = re.split(r"\d", clean)[0].strip()
    if not pname and not amount:
        return "Format: *SOLD [product] [qty] [amount] [momo ref]*\nExample: _SOLD boots 1 80000 MP240901_"

    conn = get_db()
    # Record order
    conn.execute("INSERT INTO orders (tenant_id,buyer_phone,items,total_ugx,payment_ref,status) VALUES (?,?,?,?,?,'completed')",
                 (tenant["id"], "walk-in", json.dumps([{"name":pname,"qty":qty}]), amount, ref))
    conn.execute("UPDATE tenants SET total_orders=total_orders+1, total_revenue=total_revenue+? WHERE id=?",
                 (amount, tenant["id"]))
    # Decrement stock
    if pname:
        prod = conn.execute("SELECT id, stock_qty, restock_alert FROM products WHERE tenant_id=? AND LOWER(name) LIKE ?",
                            (tenant["id"], f"%{pname.lower()}%")).fetchone()
        if prod:
            new_qty = max(0, (prod["stock_qty"] or 0) - qty)
            conn.execute("UPDATE products SET stock_qty=? WHERE id=?", (new_qty, prod["id"]))

    # Today's stats
    today = conn.execute("SELECT COUNT(*) cnt, COALESCE(SUM(total_ugx),0) rev FROM orders WHERE tenant_id=? AND status='completed' AND DATE(created_at)=DATE('now')",
                         (tenant["id"],)).fetchone()
    conn.commit(); conn.close()

    msg = (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
           f"  ✅ SALE RECORDED\n"
           f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n")
    if pname: msg += f"Product:  {pname.title()} × {qty}\n"
    if amount: msg += f"Amount:   UGX {amount:,}\n"
    if ref: msg += f"MoMo Ref: {ref}\n"
    msg += (f"\n📊 Today: {today['cnt']} sales · UGX {int(today['rev']):,}\n")
    # Stock warning
    if pname and prod and (prod["stock_qty"] or 0) - qty <= (prod["restock_alert"] or 5):
        new_qty = max(0, (prod["stock_qty"] or 0) - qty)
        msg += f"⚠️ {pname.title()} stock: {new_qty} remaining\n"
    msg += f"━━━━━━━━━━━━━━━━━━━━━━━━━"
    return msg


# ═══════════════════════════════════════════════════════════════════════════════
# SELLER: PRODUCT MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

def _add_product(text, phone, tenant):
    """ADD cement 38000 bag or ADD Red Dress 45000 S M L"""
    clean = text.replace("ADD","",1).strip()
    items = parse_inventory_text(clean)
    if items:
        conn = get_db()
        for item in items:
            conn.execute("INSERT INTO products (tenant_id,name,price_ugx,unit,name_search) VALUES (?,?,?,?,?)",
                         (tenant["id"], item["name"].title(), item["price"], item.get("unit","item"),
                          item["name"].lower()))
        conn.commit(); conn.close()
        names = ", ".join(i["name"].title() for i in items)
        return f"✅ Added: {names}"

    # Try simple format: name price [sizes...]
    parts = clean.split()
    if len(parts) >= 2:
        # Find price (first number > 100)
        price = 0; price_idx = -1
        for i, p in enumerate(parts):
            try:
                v = int(p.replace(",","").replace("k","000").replace("K","000"))
                if v > 100: price = v; price_idx = i; break
            except: pass
        if price > 0 and price_idx > 0:
            name = " ".join(parts[:price_idx])
            sizes = parts[price_idx+1:] if price_idx+1 < len(parts) else []
            # Check if remaining parts are sizes or unit
            unit = "item"
            size_list = []
            for s in sizes:
                if s.lower() in ("kg","bag","piece","box","pair","set","meter","litre","item"):
                    unit = s.lower()
                else:
                    size_list.append(s.upper())
            conn = get_db()
            conn.execute("INSERT INTO products (tenant_id,name,price_ugx,unit,sizes,name_search) VALUES (?,?,?,?,?,?)",
                         (tenant["id"], name.title(), price, unit, json.dumps(size_list) if size_list else "[]", name.lower()))
            conn.commit(); conn.close()
            size_note = f"\nSizes: {', '.join(size_list)}" if size_list else ""
            return f"✅ *{name.title()}* — UGX {price:,}/{unit}{size_note}\n\nSend another, or type *DONE*."
    return "Format: *ADD [name] [price] [unit]*\nExample: _ADD cement 38000 bag_\nOr: _ADD Red Dress 45000 S M L XL_"

def _add_product_from_photo(text, phone, tenant, session):
    """After photo sent, parse name + price from text."""
    session.get("context", {}).pop("pending_photo", None)
    sessions.update_context(phone, session.get("context", {}))
    # Reuse add logic
    result = _add_product(f"ADD {text}", phone, tenant)
    if "✅" in result:
        return result
    return f"I couldn't parse that. Try: _name price_\nExample: _Red dress 45000_"

def _update_price(text, phone, tenant):
    clean = text.replace("PRICE","",1).strip()
    parts = clean.rsplit(None, 1)
    if len(parts) < 2: return "Format: *PRICE [name] [new price]*"
    name, price_str = parts
    try: price = int(price_str.replace(",",""))
    except: return "Price must be a number."
    conn = get_db()
    conn.execute("UPDATE products SET price_ugx=?, updated_at=CURRENT_TIMESTAMP WHERE tenant_id=? AND LOWER(name) LIKE ?",
                 (price, tenant["id"], f"%{name.lower()}%"))
    conn.commit(); conn.close()
    return f"✅ {name.title()} updated to UGX {price:,}"

def _remove_product(text, phone, tenant):
    name = text.replace("REMOVE","",1).strip()
    conn = get_db()
    conn.execute("UPDATE products SET is_available=0 WHERE tenant_id=? AND LOWER(name) LIKE ?",
                 (tenant["id"], f"%{name.lower()}%"))
    conn.commit(); conn.close()
    return f"✅ {name.title()} removed."

def _stock_list(tenant):
    conn = get_db()
    products = conn.execute("SELECT * FROM products WHERE tenant_id=? AND is_available=1 ORDER BY category, name",
                            (tenant["id"],)).fetchall()
    conn.close()
    if not products: return "No products listed. Use *ADD [name] [price]* to add."
    lines = []
    for p in products:
        p = dict(p)
        photo = "📷" if p.get("image_id") else "  "
        stock = f"({p['stock_qty']})" if p.get("stock_qty",0)>0 else ""
        lines.append(f"  {photo} {p['name']:20} UGX {p['price_ugx']:>10,}/{p['unit']} {stock}")
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📦 {tenant['name']} — Stock\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
            "\n".join(lines) + f"\n\n{len(products)} products listed\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

def _sales_report(tenant):
    conn = get_db()
    today = conn.execute("SELECT COUNT(*) cnt, COALESCE(SUM(total_ugx),0) rev FROM orders WHERE tenant_id=? AND status='completed' AND DATE(created_at)=DATE('now')",
                         (tenant["id"],)).fetchone()
    month = conn.execute("SELECT COUNT(*) cnt, COALESCE(SUM(total_ugx),0) rev FROM orders WHERE tenant_id=? AND status='completed' AND created_at >= date('now','start of month')",
                         (tenant["id"],)).fetchone()
    total = conn.execute("SELECT total_orders, total_revenue, total_leads FROM tenants WHERE id=?",
                         (tenant["id"],)).fetchone()
    conn.close()
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  📊 {tenant['name']} — Sales\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Today:     {today['cnt']} sales · UGX {int(today['rev']):,}\n"
            f"This month:{month['cnt']} sales · UGX {int(month['rev']):,}\n"
            f"All time:  {total['total_orders']} sales · UGX {total['total_revenue']:,}\n"
            f"Total leads: {total['total_leads']}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

def _leads_report(tenant):
    conn = get_db()
    leads = conn.execute("SELECT * FROM leads WHERE tenant_id=? ORDER BY created_at DESC LIMIT 10",
                         (tenant["id"],)).fetchall()
    conn.close()
    if not leads: return "No leads yet. Buyers will appear here when they find your shop."
    lines = []
    for l in leads:
        l = dict(l)
        lines.append(f"  +{l['buyer_phone']} — {l.get('product_name','browse')} · {l['created_at'][:10]}")
    return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  🔔 Recent Leads\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
            "\n".join(lines) + "\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━")


# ═══════════════════════════════════════════════════════════════════════════════
# VERIFICATION FLOW
# ═══════════════════════════════════════════════════════════════════════════════

def _handle_verification_step(text, phone, tenant, session):
    step = session.get("context", {}).get("verifying")
    if step == "payment":
        result = process_verification_payment(text, tenant["id"])
        if result:
            session["context"]["verifying"] = "location"
            sessions.update_context(phone, session["context"])
            return (f"✅ Payment confirmed! Ref: {result['ref']}\n\n"
                    f"Now share your shop location 📍\n"
                    f"Or type your address.")
        return "I couldn't read the payment. Paste the MoMo confirmation text."
    if step == "location":
        save_location(tenant["id"], 0, 0, text)  # Text address for now
        complete_verification(tenant["id"])
        session["context"].pop("verifying", None)
        sessions.update_context(phone, session["context"])
        return (f"━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"  🎉 VERIFIED! ✅\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"*{tenant['name']}* is now verified!\n\n"
                f"• ✅ badge on your shop\n"
                f"• Appear first in search\n"
                f"• Professional Status cards daily\n"
                f"• Web page: weza.app/shop/{tenant['keyword']}\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━")
    return ""


def _buyer_momo_screenshot(image_bytes, phone, tenant, session):
    return ("Thanks for the image! To record payment,\n"
            "please paste or type the MoMo confirmation text.\n"
            "Example: _REF MP240130456 50000_")


# ═══════════════════════════════════════════════════════════════════════════════
# HELP
# ═══════════════════════════════════════════════════════════════════════════════

def _help(is_admin, tenant):
    verified = " ✅" if tenant.get("is_verified") else ""
    if is_admin:
        return (f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"  🛒 {tenant['name']}{verified} — Admin\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📦 STOCK — view all products\n"
                f"📊 SALES — revenue report\n"
                f"🔔 LEADS — buyer inquiries\n"
                f"➕ ADD [name] [price] — add product\n"
                f"   _or send photo + name price_\n"
                f"💰 SOLD [product] [qty] [amt] [ref]\n"
                f"💲 PRICE [name] [new price]\n"
                f"❌ REMOVE [name]\n"
                f"✅ VERIFY — get verified badge\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return _show_catalog(tenant)


def _get_tenant(tid):
    conn = get_db()
    t = conn.execute("SELECT * FROM tenants WHERE id=?", (tid,)).fetchone()
    conn.close()
    return dict(t) if t else {}

def _check_admin(phone, tid):
    conn = get_db()
    r = conn.execute("SELECT 1 FROM tenant_admins WHERE tenant_id=? AND phone=?", (tid, phone)).fetchone()
    conn.close()
    return r is not None
