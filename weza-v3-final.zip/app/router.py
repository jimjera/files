"""
app/router.py  —  Weza AI-Centric Router v6

ALL messages flow through the AI brain for intent classification.
No keyword matching — the AI extracts products, detects language,
and routes to the appropriate service.

Flow:
  message → AI classifies intent + extracts entities → route to service → respond
"""

import re, json
from app.database import get_db
from app.services import session_store as sessions, whatsapp
from app.services.weza_ai import (
    process_message, detect_intent,
    extract_group_name, classify_group, contextual_response,
    search_products, search_products_broad, registration_turn
)
from app.modules import sacco, groups, retail


def _log_message(phone, direction, content, intent=None, language=None, tier=0):
    """Log every message for analytics."""
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO message_log (phone,direction,content,intent,language,ai_tier) VALUES (?,?,?,?,?,?)",
            (phone, direction, content[:500] if content else "", intent, language, tier))
        conn.commit(); conn.close()
    except: pass

_reg    = {}   # registration sessions
_picker  = {}   # admin group picker sessions
ICONS = {"SACCO": "🏦", "GROUPS": "👥", "RETAIL": "🛒"}

# Words that always mean EXIT regardless of context
EXIT_WORDS = {
    "EXIT","HOME","BACK","RUDI","QUITTER","SALIR","CANCEL","STOP",
    "LETS LEAVE THIS","LEAVE THIS","STOP THIS","FORGET IT","NEVERMIND",
    "NEVER MIND","ACHA","WACHA","SIMAMA","SOMA"
}


def process(phone: str, message: str, image_bytes: bytes = None,
            group_id: str = None) -> str:
    phone   = whatsapp.format_phone(phone)
    text    = message.strip()
    textup  = text.upper()
    tl_exit = text.lower().strip()

    # Log inbound message
    _log_message(phone, "inbound", text)

    # ── Group shadow ledger ────────────────────────────────────────────────────
    if group_id:
        _shadow_ledger(phone, text, group_id)
        return ""

    # ── EXIT from anything — always works ──────────────────────────────────────
    # ── MENU — show admin control panel ───────────────────────────────────────
    # ── Deep link from Status card: "Shop SARAH" ────────────────────────
    if textup.startswith("SHOP "):
        keyword = textup[5:].strip()
        conn = get_db()
        tenant = conn.execute("SELECT * FROM tenants WHERE UPPER(keyword)=? AND is_active=1", (keyword,)).fetchone()
        conn.close()
        if tenant:
            tenant = dict(tenant)
            s = sessions.create(phone, tenant); s["tenant"] = tenant
            s.setdefault("context", {})["catalog_shown"] = True
            from app.modules.retail import _show_catalog
            reply = _show_catalog(tenant)
            # Track analytics
            try:
                conn = get_db()
                conn.execute("INSERT INTO analytics_events (event_type,user_phone,shop_id,data) VALUES ('deep_link',?,?,?)",
                             (phone, tenant["id"], f'{{"keyword":"{keyword}"}}'))
                conn.commit(); conn.close()
            except: pass
            _log_message(phone, "outbound", reply[:200], intent="deep_link_catalog")
            whatsapp.send(phone, reply)
            return reply

    if textup == "MENU":
        session = sessions.get(phone)
        if session:
            _load_tenant(session)
            tenant = session.get("tenant", {})
            is_adm = _is_admin_of(phone, tenant.get("id"))
            if is_adm:
                from app.services.admin_controls import get_menu
                reply = get_menu(tenant.get("module_type","SACCO"))
            else:
                from app.modules import sacco, groups, retail
                reply = _dispatch(session["module_type"],"HELP",phone,session,None)
        else:
            # Not in a session — connect to their group first
            ug = _get_user_groups(phone)
            if len(ug) == 1:
                s = sessions.create(phone, ug[0])
                s["tenant"] = ug[0]
                is_adm = _is_admin_of(phone, ug[0]["id"])
                if is_adm:
                    from app.services.admin_controls import get_menu
                    reply = get_menu(ug[0]["module_type"])
                else:
                    reply = _dispatch(ug[0]["module_type"], "HELP", phone, s, None)
            elif len(ug) > 1:
                reply = _my_groups_msg(phone, ug)
            else:
                reply = ("You are not in any group yet.\n\n"
                         "Say *register* to create one.")
        whatsapp.send(phone, reply)
        return reply

    if textup in EXIT_WORDS or any(w in textup for w in ["LETS LEAVE","LEAVE THIS","STOP THE PROCESS","LETS STOP"]):
        sessions.clear(phone)
        _reg.pop(phone, None)
        reply = _exit_message(phone)
        whatsapp.send(phone, reply)
        return reply

    if textup == "SWITCH":
        sessions.clear(phone)
        _reg.pop(phone, None)
        reply = _my_groups_msg(phone)
        whatsapp.send(phone, reply)
        return reply

    # ── Mid-registration ───────────────────────────────────────────────────────
    if phone in _reg:
        reply = _register_step(phone, text)
        whatsapp.send(phone, reply)
        return reply

    # ── Active session ─────────────────────────────────────────────────────────
    session = sessions.get(phone)
    if session:
        _load_tenant(session)
        current_tenant = session.get("tenant", {})

        # Natural language exit detection inside sessions
        EXIT_PHRASES = ["go home","go back","take me home","go to menu","main menu",
                        "i want to leave","leave","back to start","start over","rudi nyumbani"]
        if any(p in tl_exit for p in EXIT_PHRASES):
            sessions.clear(phone)
            reply = _exit_message(phone)
            whatsapp.send(phone, reply)
            return reply

        # ── CHECK FOR KEYWORD SWITCH — can the user switch to another tenant? ──
        # This prevents the "stuck in shop" trap
        fw = textup.split()[0] if text else ""
        if len(fw) >= 3 and fw != current_tenant.get("keyword", "").upper():
            conn = get_db()
            other_tenant = conn.execute(
                "SELECT * FROM tenants WHERE UPPER(keyword)=? AND is_active=1", (fw,)
            ).fetchone()
            conn.close()
            if other_tenant:
                # User wants a different tenant — switch!
                sessions.clear(phone)
                _log_message(phone, "outbound", "", intent="session_switch")
                return _connect(phone, dict(other_tenant), text, image_bytes)

        # Deep link inside session: "Shop KEYWORD"
        if textup.startswith("SHOP "):
            kw = textup[5:].strip()
            if kw != current_tenant.get("keyword", "").upper():
                conn = get_db()
                other = conn.execute("SELECT * FROM tenants WHERE UPPER(keyword)=? AND is_active=1", (kw,)).fetchone()
                conn.close()
                if other:
                    sessions.clear(phone)
                    other = dict(other)
                    s = sessions.create(phone, other); s["tenant"] = other
                    s.setdefault("context", {})["catalog_shown"] = True
                    from app.modules.retail import _show_catalog
                    reply = _show_catalog(other)
                    _log_message(phone, "outbound", reply[:200], intent="deep_link_switch")
                    whatsapp.send(phone, reply)
                    return reply

        # High-confidence register intent → start new registration
        quick = detect_intent(text)
        if quick.get("intent") == "register" and quick.get("confidence", 0) > 0.85:
            sessions.clear(phone)
            _reg[phone] = {"step": 1, "data": {}, "history": []}
            reply = "Tukole! 🎉 What would you like to call your new group or shop?"
            whatsapp.send(phone, reply)
            return reply

        reply = _dispatch(session["module_type"], text, phone, session, image_bytes)

        # If the module returned None, it can't handle this message
        # Clear session and fall through to AI/keyword processing below
        if reply is None:
            sessions.clear(phone)
            _log_message(phone, "system", "Module returned None, clearing session", intent="session_cleared")
            # Don't return — fall through to keyword check and AI below
        else:
            whatsapp.send(phone, reply)
            return reply

    # ── Explicit keyword typed ─────────────────────────────────────────────────
    fw = textup.split()[0] if text else ""
    if len(fw) >= 3:
        conn   = get_db()
        tenant = conn.execute(
            "SELECT * FROM tenants WHERE UPPER(keyword)=? AND is_active=1", (fw,)
        ).fetchone()
        conn.close()
        if tenant:
            return _connect(phone, dict(tenant), message, image_bytes)

    # ── Follow-up detection: "any other option", "what else", "alternatives" ───
    FOLLOWUP_WORDS = ["other option","another option","what else","alternatives",
                      "any other","else","different","other shops","cheaper",
                      "more options","other stores","show more","what about"]
    tl_check = text.lower()
    if any(w in tl_check for w in FOLLOWUP_WORDS):
        # Get all shops for any recently relevant product, or show categories
        from app.services.weza_ai import get_available_categories, search_products_broad, contextual_response
        broad = search_products_broad(text)
        if not broad:
            # No product context — show what categories we have
            cats = get_available_categories()
            if cats:
                lines = []
                seen_shops = set()
                for c in cats[:6]:
                    if c['shop'] not in seen_shops:
                        seen_shops.add(c['shop'])
                        lines.append(f"🏪 *{c['shop']}* — {c['category']}")
                reply = "Here's what's available on Weza:\n\n" + "\n".join(lines)
                reply += "\n\nTell me what you need and I'll search for it."
            else:
                reply = "No shops are listed yet. Type *REGISTER* to add your shop."
            whatsapp.send(phone, reply)
            return reply

    # ── AI processes the message with full database context ────────────────────
    result = process_message(phone, text)
    action = result.get("action", "none")
    reply  = result.get("reply", "")

    # Log the AI classification
    _log_message(phone, "classified", "", 
                 intent=result.get("intent"), 
                 language=result.get("language"),
                 tier=result.get("tier", 3))

    # ── Connect to a keyword the AI detected ─────────────────────────────────
    if action == "connect_keyword":
        entities = result.get("entities", {})
        kw = (entities.get("group_name") or "").upper()
        if kw:
            conn = get_db()
            tenant = conn.execute("SELECT * FROM tenants WHERE UPPER(keyword)=? AND is_active=1", (kw,)).fetchone()
            conn.close()
            if tenant:
                r = _connect(phone, dict(tenant), text, image_bytes)
                _log_message(phone, "outbound", r, intent="connected")
                return r

    # Execute the action the AI decided on
    if action == "start_register":
        _reg[phone] = {"step": 1, "data": {}, "history": []}

        # If trigger is just "register" or similar single word — ask for name directly
        trigger_clean = text.strip().lower()
        generic_triggers = {"register","create","new group","start","open",
                            "tukole","kakole","register group","create group"}
        if trigger_clean in generic_triggers or len(text.split()) <= 2:
            reply = "Tukole! 🎉 What would you like to call your group or shop?"
        else:
            # Try to extract info from a richer trigger message
            from app.services.weza_ai import registration_turn as _rt
            pre = _rt(text, {}, [], [])
            if not pre.get("wants_exit"):
                _reg[phone]["data"] = {
                    k: v for k, v in pre.items()
                    if k in ("name","module_type","momo_number","momo_network","organiser_name")
                    and v and str(v).lower() not in ("null","none","")
                }
                _reg[phone]["history"] = [
                    {"role": "user", "content": text},
                    {"role": "assistant", "content": pre.get("reply","")}
                ]
                reply = pre.get("reply", "What would you like to call your group?")
            else:
                reply = "What would you like to call your group or shop?"

    elif action == "search_product":
        db_results = result.get("results", [])
        if db_results:
            reply = _format_results(db_results, result.get("product"))
        # else: AI already generated a contextual reply with category info

    elif action in ("show_balance", "balance"):
        ug = _get_user_groups(phone)
        sg = [g for g in ug if g["module_type"] == "SACCO"]
        if len(sg) == 1:
            s = sessions.create(phone, sg[0])
            s["tenant"] = sg[0]
            reply = sacco.handle("balance", phone, s, None)
        elif len(sg) > 1:
            lines = "\n".join(f"  *{g['keyword']}* — {g['name']}" for g in sg)
            reply = f"You are in {len(sg)} SACCOs:\n\n{lines}\n\nType a keyword to connect."

    elif action == "loan":
        ug = _get_user_groups(phone)
        sg = [g for g in ug if g["module_type"] == "SACCO"]
        if len(sg) == 1:
            s = sessions.create(phone, sg[0])
            s["tenant"] = sg[0]
            amt = result.get("entities", {}).get("amount")
            loan_msg = f"LOAN {int(amt)}" if amt else "LOAN"
            reply = sacco.handle(loan_msg, phone, s, None)

    elif action == "statement":
        ug = _get_user_groups(phone)
        sg = [g for g in ug if g["module_type"] == "SACCO"]
        if len(sg) == 1:
            s = sessions.create(phone, sg[0])
            s["tenant"] = sg[0]
            reply = sacco.handle("STATEMENT", phone, s, None)

    elif action == "show_pledges":
        ug = _get_user_groups(phone)
        eg = [g for g in ug if g["module_type"] == "GROUPS"]
        if len(eg) == 1:
            s = sessions.create(phone, eg[0])
            s["tenant"] = eg[0]
            reply = groups.handle("MY PLEDGE", phone, s, None)
        elif len(eg) > 1:
            lines = "\n".join(f"  *{g['keyword']}* — {g['name']}" for g in eg)
            reply = f"You have pledges in {len(eg)} groups:\n\n{lines}\n\nType a keyword to connect."

    elif action == "connect_sacco":
        ug = _get_user_groups(phone)
        sg = [g for g in ug if g["module_type"] == "SACCO"]
        if len(sg) == 1:
            return _connect(phone, sg[0], text, image_bytes)

    elif action == "connect_groups":
        ug = _get_user_groups(phone)
        eg = [g for g in ug if g["module_type"] == "GROUPS"]
        if len(eg) == 1:
            return _connect(phone, eg[0], text, image_bytes)

    if not reply:
        reply = "What can I help you with?"

    # Log outbound
    _log_message(phone, "outbound", reply, intent=result.get("intent"))
    whatsapp.send(phone, reply)
    return reply


# ═══════════════════════════════════════════════════════════════════════════════
# MARKETPLACE SEARCH
# ═══════════════════════════════════════════════════════════════════════════════

def _format_results(rows: list, product: str = None) -> str:
    """Format database search results into a WhatsApp message."""
    if not rows:
        return ""
    if len(rows) == 1:
        r = rows[0]
        msg = f"🏪 *{r['shop']}*"
        if r.get("location"): msg += f"\n📍 {r['location']}"
        msg += f"\n\n*{r['name'].title()}*"
        msg += f"\n💰 UGX {r['price_ugx']:,} per {r['unit']}"
        if r.get("bulk_price_ugx"):
            msg += f"\n📦 Bulk ({r['bulk_min_qty']}+ {r['unit']}s): UGX {r['bulk_price_ugx']:,} each"
        msg += f"\n\nPay via *{r['momo_network']} {r['momo_number']}*"
        msg += f"\n\nType *{r['shop_code']}* to place an order."
        return msg
    label = product.title() if product else "products"
    msg = f"Found *{label}* in {len(rows)} shops 🏪\n\n"
    for r in rows:
        msg += f"*{r['shop']}*"
        if r.get("location"): msg += f" · {r['location']}"
        msg += f"\n💰 UGX {r['price_ugx']:,}/{r['unit']}"
        if r.get("bulk_price_ugx"): msg += f" _(bulk {r['bulk_min_qty']}+: UGX {r['bulk_price_ugx']:,})_"
        msg += f"\n📱 {r['momo_network']} · {r['momo_number']}"
        msg += f"\nType *{r['shop_code']}* to order\n\n"
    msg += f"Best price: *{rows[0]['shop']}* at UGX {rows[0]['price_ugx']:,}/{rows[0]['unit']}"
    return msg


def _marketplace_search(text: str, phone: str, product: str = None) -> str:
    if not product:
        from app.services.weza_ai import detect_intent as _di
        product = _di(text).get("product")

    if not product:
        words = [w for w in text.split()
                 if len(w) > 3 and w.lower() not in
                 ("need","want","some","please","much","have","give",
                  "show","find","what","selling","price","buy","looking")]
        product = words[0].lower() if words else None

    if not product:
        return ""

    conn    = get_db()
    rows    = conn.execute(
        """SELECT p.name, p.price_ugx, p.bulk_price_ugx, p.bulk_min_qty,
                  p.unit, t.name AS shop, t.location,
                  t.momo_number, t.momo_network, t.keyword
           FROM products p JOIN tenants t ON t.id=p.tenant_id
           WHERE p.is_available=1 AND t.is_active=1 AND t.module_type='RETAIL'
             AND (LOWER(p.name) LIKE ? OR LOWER(p.name_luganda) LIKE ?)
           ORDER BY p.price_ugx ASC LIMIT 5""",
        (f"%{product.lower()}%",)*2
    ).fetchall()

    if not rows:
        for w in [x for x in product.split() if len(x) > 2]:
            rows = conn.execute(
                """SELECT p.name, p.price_ugx, p.bulk_price_ugx, p.bulk_min_qty,
                          p.unit, t.name AS shop, t.location,
                          t.momo_number, t.momo_network, t.keyword
                   FROM products p JOIN tenants t ON t.id=p.tenant_id
                   WHERE p.is_available=1 AND t.is_active=1 AND t.module_type='RETAIL'
                     AND LOWER(p.name) LIKE ?
                   ORDER BY p.price_ugx ASC LIMIT 4""",
                (f"%{w}%",)
            ).fetchall()
            if rows: product = w; break
    conn.close()

    if not rows:
        return ""  # Router will use AI's contextual reply instead

    rows = [dict(r) for r in rows]

    if len(rows) == 1:
        r   = rows[0]
        msg = f"🏪 *{r['shop']}*"
        if r["location"]: msg += f"\n📍 {r['location']}"
        msg += f"\n\n*{r['name'].title()}*"
        msg += f"\n💰 UGX {r['price_ugx']:,} per {r['unit']}"
        if r["bulk_price_ugx"]:
            msg += f"\n📦 Bulk ({r['bulk_min_qty']}+ {r['unit']}s): UGX {r['bulk_price_ugx']:,} each"
        msg += f"\n\nPay via *{r['momo_network']} {r['momo_number']}*"
        msg += f"\n\nType *{r['keyword']}* to place an order."
        return msg

    msg = f"Found *{product.title()}* in {len(rows)} shops 🏪\n\n"
    for r in rows:
        msg += f"*{r['shop']}*"
        if r["location"]: msg += f" · {r['location']}"
        msg += f"\n💰 UGX {r['price_ugx']:,}/{r['unit']}"
        if r["bulk_price_ugx"]: msg += f" _(bulk {r['bulk_min_qty']}+: UGX {r['bulk_price_ugx']:,})_"
        msg += f"\n📱 {r['momo_network']} · {r['momo_number']}"
        msg += f"\nType *{r['keyword']}* to order\n\n"
    msg += f"Best price: *{rows[0]['shop']}* at UGX {rows[0]['price_ugx']:,}/{rows[0]['unit']}"
    return msg


# ═══════════════════════════════════════════════════════════════════════════════
# REGISTRATION FLOW
# ═══════════════════════════════════════════════════════════════════════════════

def _register_step(phone: str, text: str) -> str:
    """
    Conversational registration. No rigid steps, no menus.
    Groq collects name, type, keyword, and MoMo naturally.
    Creates the group as soon as all 4 pieces are collected.
    """
    session = _reg[phone]
    collected = session.get("data", {})

    # Check if user wants to exit registration entirely
    tl = text.lower().strip()
    EXIT_REG = ["exit","cancel","stop","quit","leave","forget","nevermind",
                "never mind","acha","wacha","simama","stop this","lets leave",
                "i want to buy","i need to buy","i want cement","i need cement"]
    if any(w in tl for w in EXIT_REG):
        del _reg[phone]
        # If they mentioned a product, handle it
        result = process_message(phone, text)
        if result.get("action") == "search_product" and result.get("results"):
            return _format_results(result["results"], result.get("product"))
        return _exit_message(phone)

    # Get existing keywords to avoid duplicates
    conn = get_db()
    existing_kws = [r["keyword"] for r in
                    conn.execute("SELECT keyword FROM tenants").fetchall()]
    conn.close()

    # Let Groq process this turn with full conversation history
    history = session.get("history", [])
    result = registration_turn(text, collected, existing_kws, history)

    # Update conversation history (keep last 6 messages = 3 exchanges)
    history.append({"role": "user", "content": text})
    reply_text = result.get("reply", "")
    if reply_text:
        history.append({"role": "assistant", "content": reply_text})
    session["history"] = history[-6:]

    # User wants to exit
    if result.get("wants_exit"):
        del _reg[phone]
        out = process_message(phone, text)
        if out.get("action") == "search_product" and out.get("results"):
            return _format_results(out["results"], out.get("product"))
        return _exit_message(phone)

    # Update collected info with whatever Groq extracted
    for field in ["name", "module_type", "keyword", "momo_number", "momo_network"]:
        val = result.get(field)
        if val and str(val).strip().lower() not in ("null","none",""):
            collected[field] = str(val).strip()
    session["data"] = collected

    # Validate keyword uniqueness if one was just set
    if collected.get("keyword"):
        kw_clean = re.sub(r"[^A-Z0-9_]", "", collected["keyword"].upper())[:15]
        if len(kw_clean) < 4:
            kw_clean = re.sub(r"[^A-Z0-9]", "", collected.get("name","GROUP").upper())[:12]
            if len(kw_clean) < 4:
                kw_clean = "GROUP" + str(len(_reg))
        collected["keyword"] = kw_clean
        conn = get_db()
        if conn.execute("SELECT 1 FROM tenants WHERE keyword=?",(kw_clean,)).fetchone():
            collected.pop("keyword")  # Remove taken keyword, let AI suggest another
            result["reply"] += f"\n\n_(Note: {kw_clean} is taken — please choose a different code)_"
        conn.close()

    # Check if we have everything needed to create the group
    has_name = bool(collected.get("name"))
    has_type = bool(collected.get("module_type"))
    mod      = collected.get("module_type","")

    # Completion rules per type
    ready = result.get("ready", False)
    if not ready:
        if mod == "SACCO"  and has_name: ready = True
        if mod == "GROUPS" and has_name: ready = True
        if mod == "RETAIL" and has_name and collected.get("momo_number"): ready = True

    if ready and has_name and has_type:
        return _create_group(phone, collected)

    # Not complete yet — return Groq's next question
    return result.get("reply", "What should I call your group?")


def _create_group(phone: str, data: dict) -> str:
    """Create the group. Keyword is auto-generated — user never chooses it."""
    import re as _re
    mod_type = data["module_type"]
    name     = data["name"]

    # Auto-generate keyword from group name — user never needs to know this
    base_kw = _re.sub(r"[^A-Z0-9]", "", name.upper())[:12]
    if len(base_kw) < 4:
        base_kw = mod_type[:4] + base_kw
    keyword  = base_kw
    conn     = get_db()
    counter  = 1
    while conn.execute("SELECT 1 FROM tenants WHERE keyword=?", (keyword,)).fetchone():
        keyword = base_kw[:10] + str(counter)
        counter += 1

    # Payment info — MoMo or bank depending on type
    momo_num = _re.sub(r"\D","", data.get("momo_number","") or "")
    network  = data.get("momo_network","MTN") or "MTN"
    bank_name    = data.get("bank_name","")
    bank_account = data.get("bank_account","")
    collection   = data.get("collection_method","momo") or (
        "bank" if bank_name else "cash" if not momo_num else "momo"
    )

    tid = conn.execute(
        "INSERT INTO tenants "
        "(keyword,name,module_type,owner_phone,momo_number,momo_network,"
        "bank_name,bank_account,collection_method) VALUES (?,?,?,?,?,?,?,?,?)",
        (keyword, name, mod_type, phone,
         momo_num or None, network,
         bank_name or None, bank_account or None, collection)
    ).lastrowid
    conn.execute("INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')",(tid,phone))

    if mod_type == "GROUPS":
        # Auto-create the event using the group name — budget set to 0, updated later
        event_type = "general"
        tl_name = name.lower()
        if any(w in tl_name for w in ["wedding","marriage","kwanjula","ruracio"]):
            event_type = "wedding"
        elif any(w in tl_name for w in ["funeral","burial","memorial","death"]):
            event_type = "funeral"
        elif any(w in tl_name for w in ["harambee","fundrais","collection"]):
            event_type = "harambee"
        conn.execute(
            "INSERT INTO group_events "
            "(tenant_id, event_name, event_type, target_budget, collected_total, status) "
            "VALUES (?,?,?,0,0,'active')",
            (tid, name, event_type)
        )

    if mod_type == "SACCO":
        conn.execute("INSERT INTO sacco_rules (tenant_id) VALUES (?)", (tid,))
        conn.execute(
            "INSERT OR IGNORE INTO sacco_members "
            "(tenant_id,phone,full_name,member_number,status) VALUES (?,?,'Admin','M001','active')",
            (tid, phone)
        )
    conn.commit()
    new_tenant = conn.execute("SELECT * FROM tenants WHERE id=?", (tid,)).fetchone()
    conn.close()

    if phone in _reg:
        del _reg[phone]

    # Auto-connect admin to their new group
    if new_tenant:
        s = sessions.create(phone, dict(new_tenant))
        s["tenant"] = dict(new_tenant)

    # Build confirmation based on payment method
    if collection == "bank" and bank_name:
        payment_info = f"Bank: {bank_name}" + (f" | Account: {bank_account}" if bank_account else "")
    elif collection == "cash":
        payment_info = "Collection method: cash at meetings"
    elif momo_num:
        payment_info = f"MoMo: {momo_num} ({network})"
    else:
        payment_info = "Payment: to be configured"

    from app.services.admin_controls import get_menu

    first_steps = {
        "SACCO": (
            "Add your members:\n"
            "_ADD MEMBER 256701234567 Sarah Nakato_\n\n"
            "Set rules:\n"
            "_SET RULE monthly_contribution 50000_\n"
            "_SET RULE loan_multiplier 3_\n\n"
            "Members message this number — Weza connects them automatically."
        ),
        "GROUPS": (
            "Weza is now watching your group chat.\n"
            "Pledges and payments are recorded automatically.\n\n"
            "Or record manually: _PLEDGE 50000_ · _PAID 50000 MP123_"
        ),
        "RETAIL": (
            "Add products:\n_ADD cement 38000 bag_\n\n"
            "Buyers find your shop automatically when they search."
        ),
    }

    return (f"*{name}* is LIVE on Weza! 🎉\n\n"
            f"{payment_info}\n\n"
            f"{first_steps.get(mod_type, '')}\n\n"
            f"Type *MENU* anytime for your full control panel.")




# ═══════════════════════════════════════════════════════════════════════════════
# WHATSAPP GROUP DETECTION — Groups onboarding without registration
# ═══════════════════════════════════════════════════════════════════════════════

def handle_group_added(admin_phone: str, group_id: str, group_name: str = ""):
    """
    Called when Weza is added to a WhatsApp group as admin.
    Works for both SACCOs and community event groups.
    Triggers private onboarding conversation with the group admin.

    Meta WhatsApp Cloud API delivers this automatically.
    For testing: POST /api/simulate-group-add
    """
    # Already registered? Just show the menu
    conn = get_db()
    existing = conn.execute(
        "SELECT * FROM tenants WHERE wa_group_id=?", (group_id,)
    ).fetchone()
    conn.close()

    if existing:
        ex = dict(existing)
        from app.services.admin_controls import get_menu
        msg = f"Welcome back to *{ex['name']}* on Weza! 👋\n\n" + get_menu(ex["module_type"])
        whatsapp.send(admin_phone, msg)
        return msg

    # We already have the group name from WhatsApp.
    # Try to auto-classify it — no question needed for obvious names.
    display_name = group_name.strip() if group_name else ""

    auto_type = None
    if display_name:
        tl = display_name.lower()
        SACCO_WORDS = ["sacco","chama","vikoba","merry","table bank","cooperative",
                       "investment club","upatu","welfare","savings","credit union"]
        GROUP_WORDS = ["wedding","funeral","burial","harambee","fundrais",
                       "committee","church","mosque","kwanjula","ruracio",
                       "memorial","introduction","event"]
        if any(w in tl for w in SACCO_WORDS):
            auto_type = "SACCO"
        elif any(w in tl for w in GROUP_WORDS):
            auto_type = "GROUPS"

    if auto_type and display_name:
        # Crystal clear — create immediately, no questions
        _reg[admin_phone] = {
            "step": 1,
            "data": {
                "name": display_name,
                "module_type": auto_type,
                "wa_group_id": group_id,
            },
            "history": []
        }
        # Force completion
        result = _create_group(admin_phone, _reg[admin_phone]["data"])
        emoji = "🏦" if auto_type == "SACCO" else "👥"
        msg = (f"Oli otya! 👋 {emoji} I've been added to *{display_name}*\n\n"
               + result)
        whatsapp.send(admin_phone, msg)
        return msg

    # Name is ambiguous or missing — ask ONE question
    _reg[admin_phone] = {
        "step": 1,
        "data": {
            "name": display_name or None,
            "wa_group_id": group_id,
        },
        "history": []
    }

    if display_name:
        # Have name, just need type
        msg = (f"Oli otya! 👋 I've been added to *{display_name}*\n\n"
               f"Is this a *SACCO* (savings & loans) or an *event group* "
               f"(wedding, funeral, harambee)?")
    else:
        # No name — ask for it
        msg = (f"Oli otya! 👋 I've been added to your group as admin.\n\n"
               f"What is this group called?")

    whatsapp.send(admin_phone, msg)
    return msg


def _create_group_from_whatsapp(phone: str, data: dict) -> str:
    """Create a GROUPS tenant linked to a WhatsApp group ID."""
    import re as _re
    name     = data.get("name", "Community Group")
    group_id = data.get("wa_group_id", "")
    keyword  = _re.sub(r"[^A-Z0-9]", "", name.upper())[:12]
    if len(keyword) < 4: keyword = "GROUP" + keyword

    conn = get_db()
    counter = 1
    base = keyword
    while conn.execute("SELECT 1 FROM tenants WHERE keyword=?", (keyword,)).fetchone():
        keyword = base[:10] + str(counter); counter += 1

    tid = conn.execute(
        "INSERT INTO tenants (keyword,name,module_type,owner_phone,wa_group_id) "
        "VALUES (?,?,'GROUPS',?,?)",
        (keyword, name, phone, group_id or None)
    ).lastrowid
    conn.execute(
        "INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')",
        (tid, phone)
    )
    conn.commit()
    conn.close()

    if phone in _reg:
        del _reg[phone]

    from app.services.admin_controls import get_menu
    return (f"*{name}* is ready! 🎉\n\n"
            f"I'm now watching your group chat and will automatically "
            f"record any pledges and payments I see.\n\n"
            f"Your control panel:\n\n" + get_menu("GROUPS"))

def _exit_message(phone: str) -> str:
    ug = _get_user_groups(phone)
    if ug:
        lines = "\n".join(
            f"{ICONS.get(g['module_type'],'•')} *{g['keyword']}* — {g['name']}"
            for g in ug
        )
        return (f"Your groups:\n\n{lines}\n\n"
                f"Type a keyword to connect.\n"
                f"To create a new group, say *register*.")
    return ("What would you like to do?\n\n"
            "• Say *register* to create a group or shop\n"
            "• Tell me what product you're looking for\n"
            "• Ask about your SACCO balance")


def _my_groups_msg(phone: str, ug: list = None) -> str:
    if ug is None: ug = _get_user_groups(phone)
    if not ug:
        return ("You're not in any groups on Weza yet.\n\n"
                "Say *register* to create one, or ask your group admin to add you.")
    conn = get_db()
    lines = []
    for g in ug:
        icon = ICONS.get(g["module_type"],"•")
        adm  = conn.execute("SELECT 1 FROM tenant_admins WHERE tenant_id=? AND phone=?",(g["id"],phone)).fetchone()
        lines.append(f"{icon} *{g['keyword']}* — {g['name']}{' _(admin)_' if adm else ''}")
    conn.close()
    return ("Your groups on Weza:\n\n" + "\n".join(lines) +
            "\n\nType a keyword to connect, or say *register* to create a new one.")


def _is_admin_of(phone: str, tenant_id) -> bool:
    if not tenant_id:
        return False
    conn = get_db()
    row  = conn.execute(
        "SELECT 1 FROM tenant_admins WHERE tenant_id=? AND phone=?",
        (tenant_id, phone)
    ).fetchone()
    conn.close()
    return row is not None


def _get_user_groups(phone: str) -> list:
    conn = get_db()
    seen, res = set(), []
    for q in [
        "SELECT DISTINCT t.* FROM tenants t JOIN sacco_members m ON m.tenant_id=t.id WHERE m.phone=? AND t.is_active=1",
        "SELECT DISTINCT t.* FROM tenants t JOIN tenant_admins a ON a.tenant_id=t.id WHERE a.phone=? AND t.is_active=1",
        "SELECT DISTINCT t.* FROM tenants t JOIN group_events e ON e.tenant_id=t.id JOIN pledges p ON p.event_id=e.id WHERE p.member_phone=? AND t.is_active=1",
    ]:
        for row in conn.execute(q,(phone,)).fetchall():
            if row["id"] not in seen:
                seen.add(row["id"]); res.append(dict(row))
    conn.close(); return res


def _connect(phone: str, tenant: dict, msg: str, image_bytes) -> str:
    s = sessions.create(phone, tenant); s["tenant"] = tenant
    icon = ICONS.get(tenant["module_type"],"•")
    greeting = f"{icon} *{tenant['name']}*\nConnected. Type *HELP* or *EXIT*."
    whatsapp.send(phone, greeting)
    rem = msg.strip()
    if rem.upper().startswith(tenant["keyword"].upper()):
        rem = rem[len(tenant["keyword"]):].strip()
    if rem and rem.upper() not in ("HELP",""):
        r = _dispatch(tenant["module_type"], rem, phone, s, image_bytes)
        whatsapp.send(phone, r)
        return greeting + "\n\n" + r
    return greeting


def _dispatch(mt, msg, phone, session, image_bytes):
    if mt=="SACCO":  return sacco.handle(msg, phone, session, image_bytes)
    if mt=="GROUPS": return groups.handle(msg, phone, session, image_bytes)
    if mt=="RETAIL": return retail.handle(msg, phone, session, image_bytes)
    return "Type EXIT to go back."


def _load_tenant(session):
    if "tenant" not in session:
        conn = get_db()
        t = conn.execute("SELECT * FROM tenants WHERE id=?",(session["tenant_id"],)).fetchone()
        conn.close()
        if t: session["tenant"] = dict(t)


def _shadow_ledger(phone: str, text: str, group_id: str,
                   group_name: str = "", added_by: str = ""):
    """
    Handles messages from WhatsApp groups.

    Two scenarios:
    1. Weza is being added to a new group → auto-register it
    2. Message from a known group → shadow ledger processing
    """
    from app.services.weza_ai import detect_financial_intent
    conn = get_db()
    t = conn.execute(
        "SELECT * FROM tenants WHERE wa_group_id=? AND is_active=1",
        (group_id,)
    ).fetchone()

    # Scenario 1: Unknown group — auto-register as GROUPS module
    if not t and group_name:
        admin_phone = added_by or phone
        base_kw = re.sub(r"[^A-Z0-9]","", group_name.upper())[:12]
        keyword  = base_kw if len(base_kw) >= 4 else "GRP" + base_kw
        counter  = 1
        while conn.execute("SELECT 1 FROM tenants WHERE keyword=?",(keyword,)).fetchone():
            keyword = base_kw[:10] + str(counter); counter += 1

        tid = conn.execute(
            "INSERT INTO tenants (keyword,name,module_type,owner_phone,wa_group_id,collection_method) "
            "VALUES (?,?,'GROUPS',?,?,'momo')",
            (keyword, group_name, admin_phone, group_id)
        ).lastrowid
        conn.execute(
            "INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')",
            (tid, admin_phone)
        )
        conn.commit()

        # Welcome message to the group
        welcome = (
            f"Hello! I\'m *Weza* 👋\n\n"
            f"I\'m now set up to track contributions for *{group_name}*\n\n"
            f"To get started, DM me *MENU* and I\'ll show you the control panel.\n\n"
            f"Members can pledge by saying:\n"
            f"_PLEDGE 50000_ — record a pledge\n"
            f"_PAID 50000 MP123_ — confirm payment"
        )
        whatsapp.send(group_id, welcome)
        conn.close()
        return

    conn.close()
    if not t: return

    # Scenario 2: Known group — shadow ledger
    if not re.search(r"\b(pledge|paid|pay|ugx|\d{3,}|contribute)\b",text,re.I):
        return

    intent = detect_financial_intent(text, phone)
    if intent.get("isPledge") and intent.get("amount",0) > 0:
        groups.handle(f"PLEDGE {intent['amount']}", phone,
                      {"tenant_id":t["id"],"tenant":dict(t),
                       "module_type":"GROUPS","context":{}})
