"""
app/database.py — Complete Weza v3 schema
All tables for marketplace, SACCO, groups, analytics, verification.
"""
import sqlite3, os
DB_PATH = os.getenv("DATABASE_URL", "weza.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""

    -- ═══ PLATFORM ═══════════════════════════════════════════════════════════

    CREATE TABLE IF NOT EXISTS tenants (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        keyword       TEXT UNIQUE NOT NULL,
        name          TEXT NOT NULL,
        module_type   TEXT NOT NULL CHECK(module_type IN ('SACCO','GROUPS','RETAIL')),
        owner_phone   TEXT NOT NULL,
        momo_number   TEXT,
        momo_network  TEXT DEFAULT 'MTN',
        bank_name     TEXT,
        bank_account  TEXT,
        bank_branch   TEXT,
        collection_method TEXT DEFAULT 'momo',
        location      TEXT,
        country       TEXT DEFAULT 'UG',
        latitude      REAL,
        longitude     REAL,
        wa_group_id   TEXT,
        wa_direct     TEXT,
        banner_image  TEXT,
        access_mode   TEXT DEFAULT 'OPEN',
        is_verified   INTEGER DEFAULT 0,
        verified_at   DATETIME,
        rating        REAL DEFAULT 0,
        total_orders  INTEGER DEFAULT 0,
        total_revenue INTEGER DEFAULT 0,
        total_leads   INTEGER DEFAULT 0,
        subscription_status TEXT DEFAULT 'trial',
        trial_ends_at DATETIME,
        subscription_paid_until DATETIME,
        is_active     INTEGER DEFAULT 1,
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS tenant_admins (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id   INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        phone       TEXT NOT NULL,
        role        TEXT DEFAULT 'admin',
        added_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(tenant_id, phone)
    );

    CREATE TABLE IF NOT EXISTS sessions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        phone       TEXT UNIQUE NOT NULL,
        tenant_id   INTEGER NOT NULL REFERENCES tenants(id),
        module_type TEXT NOT NULL,
        context     TEXT DEFAULT '{}',
        expires_at  DATETIME NOT NULL,
        last_active DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id   INTEGER REFERENCES tenants(id),
        actor_phone TEXT NOT NULL,
        action      TEXT NOT NULL,
        target_id   INTEGER,
        target_type TEXT,
        details     TEXT DEFAULT '{}',
        logged_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- ═══ RETAIL / MARKETPLACE ═══════════════════════════════════════════════

    CREATE TABLE IF NOT EXISTS products (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id      INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        name           TEXT NOT NULL,
        name_luganda   TEXT,
        description    TEXT,
        category       TEXT DEFAULT 'General',
        price_ugx      INTEGER NOT NULL,
        bulk_price_ugx INTEGER,
        bulk_min_qty   INTEGER DEFAULT 10,
        unit           TEXT DEFAULT 'item',
        stock_qty      INTEGER DEFAULT 0,
        restock_alert  INTEGER DEFAULT 5,
        image_id       TEXT,
        sizes          TEXT DEFAULT '[]',
        colors         TEXT DEFAULT '[]',
        is_available   INTEGER DEFAULT 1,
        added_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id   INTEGER NOT NULL REFERENCES tenants(id),
        buyer_phone TEXT NOT NULL,
        buyer_name  TEXT,
        items       TEXT DEFAULT '[]',
        total_ugx   INTEGER NOT NULL,
        delivery_fee INTEGER DEFAULT 0,
        delivery_address TEXT,
        payment_ref TEXT,
        status      TEXT DEFAULT 'completed',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS payments (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id      INTEGER REFERENCES tenants(id),
        order_id       INTEGER REFERENCES orders(id),
        buyer_phone    TEXT NOT NULL,
        transaction_id TEXT,
        amount_ugx     INTEGER,
        network        TEXT,
        verified       INTEGER DEFAULT 0,
        raw_ocr        TEXT,
        created_at     DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS leads (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        buyer_phone  TEXT NOT NULL,
        tenant_id    INTEGER REFERENCES tenants(id),
        product_name TEXT,
        product_id   INTEGER,
        status       TEXT DEFAULT 'sent',
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- ═══ SACCO ══════════════════════════════════════════════════════════════

    CREATE TABLE IF NOT EXISTS sacco_rules (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id           INTEGER UNIQUE NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        monthly_contrib_ugx INTEGER DEFAULT 0,
        contrib_day         TEXT DEFAULT 'last Saturday',
        late_penalty_ugx    INTEGER DEFAULT 0,
        grace_days          INTEGER DEFAULT 7,
        loan_multiplier     REAL DEFAULT 3.0,
        interest_rate       REAL DEFAULT 10.0,
        loan_term_months    INTEGER DEFAULT 6,
        approvers_required  TEXT DEFAULT 'treasurer',
        exit_policy         TEXT DEFAULT 'full savings returned',
        has_constitution    INTEGER DEFAULT 0,
        constitution_text   TEXT,
        is_merry_go_round   INTEGER DEFAULT 0,
        round_amount        INTEGER DEFAULT 0,
        current_round       INTEGER DEFAULT 1,
        share_price         INTEGER DEFAULT 10000,
        updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sacco_members (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id       INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        phone           TEXT NOT NULL,
        full_name       TEXT NOT NULL,
        member_number   TEXT,
        savings_balance INTEGER DEFAULT 0,
        shares          INTEGER DEFAULT 0,
        share_value     INTEGER DEFAULT 0,
        loan_balance    INTEGER DEFAULT 0,
        credit_score    INTEGER DEFAULT 500,
        status          TEXT DEFAULT 'active',
        joined_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(tenant_id, phone)
    );

    CREATE TABLE IF NOT EXISTS sacco_transactions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
        member_id       INTEGER NOT NULL REFERENCES sacco_members(id),
        type            TEXT NOT NULL,
        amount_ugx      INTEGER NOT NULL,
        balance_after   INTEGER NOT NULL,
        transaction_ref TEXT,
        notes           TEXT,
        approved_by     TEXT,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sacco_loans (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
        member_id       INTEGER NOT NULL REFERENCES sacco_members(id),
        principal_ugx   INTEGER NOT NULL,
        interest_rate   REAL DEFAULT 10.0,
        term_months     INTEGER DEFAULT 6,
        monthly_payment INTEGER,
        balance_ugx     INTEGER,
        guarantor_phones TEXT DEFAULT '[]',
        guarantors_confirmed TEXT DEFAULT '[]',
        status          TEXT DEFAULT 'pending',
        rejection_reason TEXT,
        applied_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        approved_at     DATETIME,
        due_date        DATETIME
    );

    CREATE TABLE IF NOT EXISTS deposit_queue (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
        member_id       INTEGER REFERENCES sacco_members(id),
        submitter_phone TEXT NOT NULL,
        transaction_ref TEXT,
        amount_ugx      INTEGER,
        method          TEXT DEFAULT 'momo',
        ocr_raw         TEXT,
        status          TEXT DEFAULT 'pending',
        submitted_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS rotation_order (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id   INTEGER REFERENCES tenants(id),
        member_id   INTEGER REFERENCES sacco_members(id),
        position    INTEGER NOT NULL,
        received    INTEGER DEFAULT 0,
        received_at DATETIME,
        UNIQUE(tenant_id, position)
    );

    CREATE TABLE IF NOT EXISTS meetings (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id        INTEGER REFERENCES tenants(id),
        location         TEXT,
        scheduled_at     DATETIME,
        attendees        INTEGER DEFAULT 0,
        total_members    INTEGER DEFAULT 0,
        amount_collected INTEGER DEFAULT 0,
        notes            TEXT,
        status           TEXT DEFAULT 'scheduled',
        created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS meeting_attendance (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        meeting_id INTEGER REFERENCES meetings(id),
        member_id  INTEGER REFERENCES sacco_members(id),
        phone      TEXT,
        status     TEXT DEFAULT 'confirmed'
    );

    -- ═══ GROUPS & EVENTS ════════════════════════════════════════════════════

    CREATE TABLE IF NOT EXISTS group_events (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id       INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        event_name      TEXT NOT NULL,
        event_type      TEXT DEFAULT 'general',
        target_budget   INTEGER DEFAULT 0,
        collected_total INTEGER DEFAULT 0,
        event_date      TEXT,
        status          TEXT DEFAULT 'active',
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS pledges (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id        INTEGER NOT NULL REFERENCES group_events(id) ON DELETE CASCADE,
        tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
        member_phone    TEXT NOT NULL,
        member_name     TEXT,
        pledged_ugx     INTEGER DEFAULT 0,
        paid_ugx        INTEGER DEFAULT 0,
        transaction_ref TEXT,
        status          TEXT DEFAULT 'pledged',
        is_draft        INTEGER DEFAULT 0,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- ═══ ANALYTICS & AI ═════════════════════════════════════════════════════

    CREATE TABLE IF NOT EXISTS platform_settings (
        key         TEXT PRIMARY KEY,
        value       TEXT NOT NULL,
        updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS ai_usage (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        model           TEXT DEFAULT 'grok-3-mini-fast',
        input_tokens    INTEGER DEFAULT 0,
        output_tokens   INTEGER DEFAULT 0,
        cost_usd        REAL DEFAULT 0,
        intent          TEXT,
        cached          INTEGER DEFAULT 0,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS analytics_events (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type      TEXT NOT NULL,
        user_phone      TEXT,
        shop_id         INTEGER,
        data            TEXT DEFAULT '{}',
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS message_log (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        phone           TEXT NOT NULL,
        direction       TEXT NOT NULL DEFAULT 'inbound',
        content         TEXT,
        intent          TEXT,
        language        TEXT DEFAULT 'en',
        ai_tier         INTEGER DEFAULT 0,
        tokens_used     INTEGER DEFAULT 0,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS user_profiles (
        phone           TEXT PRIMARY KEY,
        name            TEXT,
        language        TEXT DEFAULT 'en',
        location_lat    REAL,
        location_lng    REAL,
        location_name   TEXT,
        user_type       TEXT DEFAULT 'buyer',
        last_search     TEXT,
        search_count    INTEGER DEFAULT 0,
        total_purchases INTEGER DEFAULT 0,
        total_spent     INTEGER DEFAULT 0,
        favorite_shop   TEXT,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS verifications (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id       INTEGER REFERENCES tenants(id),
        type            TEXT NOT NULL,
        status          TEXT DEFAULT 'pending',
        data            TEXT DEFAULT '{}',
        payment_ref     TEXT,
        amount_paid     INTEGER,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    """)
    conn.commit()
    conn.close()
    print("✓ Database initialised:", DB_PATH)

if __name__ == "__main__":
    init_db()
