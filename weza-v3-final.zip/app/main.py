"""
app/main.py — Weza Platform v2 (AI-Centric)

PUBLIC:
  GET  /           → Landing website
  GET  /simulator  → WhatsApp chat simulator
  POST /webhook    → Twilio WhatsApp webhook
  POST /webhook/meta → Meta Cloud API webhook (GET for verify, POST for messages)
  POST /api/simulate → Simulator API

ADMIN:
  GET  /admin      → Dashboard with AI metrics
  GET  /admin/*    → Groups, Members, Loans, Events, Audit, AI Stats, Shops

API:
  GET  /api/tenants
  GET  /api/stats
  GET  /health
"""

import os, base64, json, hmac, hashlib
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, Request, Form, HTTPException, Depends, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

from app.database import init_db, get_db
from app.router import process as process_message
from app.services import session_store as sessions

app = FastAPI(title="Weza", version="2.0.0")

BASE_DIR   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "website", "static")
TMPL_DIR   = os.path.join(BASE_DIR, "website", "templates")

app.mount("/static", StaticFiles(directory=STATIC_DIR, check_dir=False), name="static")
templates  = Jinja2Templates(directory=TMPL_DIR)

ADMIN_USER = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASSWORD", "weza2024")

@app.on_event("startup")
async def startup():
    init_db()
    sessions.load_from_db()
    print("✓ Weza v2 started (AI-Centric)")

# ── Website data ──────────────────────────────────────────────────────────────

GROUP_TYPES = [
    {"icon": "🏦", "name": "SACCO", "color": "emerald",
     "desc": "Savings and credit cooperatives. Member ledgers, loan management, deposit verification — all automated via WhatsApp.",
     "tags": ["Savings", "Loans", "Statements", "Guarantors"]},
    {"icon": "👥", "name": "Community Groups", "color": "violet",
     "desc": "Weddings, funerals, harambees. Track pledges, confirm payments, publish transparency reports.",
     "tags": ["Pledges", "Events", "Fundraising", "Kyakazi"]},
    {"icon": "🔄", "name": "Merry-go-round", "color": "blue",
     "desc": "Rotating savings groups. Track each member's turn, contribution history, and payout schedule.",
     "tags": ["Rotation", "Chama", "Susu", "Tontine"]},
    {"icon": "🛒", "name": "Marketplace", "color": "amber",
     "desc": "Hardware shops, market traders. AI-powered product catalog, MoMo verification, daily sales reports.",
     "tags": ["Inventory", "Orders", "Payments", "Delivery"]},
]

FEATURES = [
    {"icon": "🤖", "title": "AI-Powered Brain", "desc": "Understands 50+ languages. Just talk naturally — the AI figures out what you need."},
    {"icon": "📱", "title": "No App Download", "desc": "Works on any phone with WhatsApp. Members never need to install anything."},
    {"icon": "🔍", "title": "Smart Product Search", "desc": "Say what you need in any language. AI finds it, compares prices, shows nearest shops."},
    {"icon": "📄", "title": "Auto Documents", "desc": "Loan agreements, statements, transparency reports — generated automatically as PDFs."},
    {"icon": "✅", "title": "MoMo Verification", "desc": "Send a screenshot or paste the confirmation text. AI reads and verifies instantly."},
    {"icon": "🌍", "title": "Any Language", "desc": "English, Luganda, Swahili, French, Amharic, Hausa, Yoruba — just talk naturally."},
    {"icon": "📊", "title": "Smart Reports", "desc": "AI generates daily briefs, P&L statements, and trend alerts automatically."},
    {"icon": "🔐", "title": "Phone-based Identity", "desc": "No passwords needed. Your WhatsApp number is your secure identity."},
    {"icon": "🚚", "title": "Smart Delivery", "desc": "AI batches orders by neighborhood to cut delivery costs. Dynamic pricing included."},
]

STEPS = [
    {"num": "1", "title": "Send a message", "desc": "Text anything to our WhatsApp number. No forms, no downloads."},
    {"num": "2", "title": "AI guides you", "desc": "The AI asks 2-3 quick questions to understand your group or shop."},
    {"num": "3", "title": "You're live", "desc": "Members can check balances, search products, and make payments instantly."},
]

PRICING = [
    {"name": "Starter", "price": "Free", "period": "forever",
     "highlighted": False,
     "features": ["Up to 10 members", "Balance checks", "Basic statements", "Product listing (5 items)"]},
    {"name": "Growth", "price": "UGX 25,000", "period": "per month",
     "highlighted": True,
     "features": ["Up to 50 members", "Full loan management", "PDF documents", "Unlimited products", "MoMo verification", "Morning brief"]},
    {"name": "Business", "price": "UGX 50,000", "period": "per month",
     "highlighted": False,
     "features": ["Unlimited members", "All features", "Verified badge ✅", "Priority support", "AI trend alerts", "Custom constitution"]},
]

QUICK_COMMANDS = [
    {"label": "Register a new group", "text": "REGISTER"},
    {"label": "Connect to Vision SACCO (demo)", "text": "VISIONSACCO"},
    {"label": "Search for cement", "text": "I need cement"},
    {"label": "Check balance", "text": "what's my balance?"},
    {"label": "Apply for a loan", "text": "I want a loan of 300000"},
    {"label": "Browse products", "text": "what do you have?"},
    {"label": "Create a wedding event", "text": "I want to create an event for Nakato's wedding"},
    {"label": "Record a pledge", "text": "I pledge 50000"},
    {"label": "Get AI catchup", "text": "CATCHUP"},
    {"label": "Try Luganda", "text": "nfuna siminti"},
    {"label": "Try Swahili", "text": "nataka saruji"},
    {"label": "Try French", "text": "je veux du ciment"},
]

# ── Public routes ─────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def landing(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "group_types": GROUP_TYPES,
        "features": FEATURES,
        "steps": STEPS,
        "pricing": PRICING,
    })

@app.get("/simulator", response_class=HTMLResponse)
async def simulator(request: Request):
    conn = get_db()
    tenants = conn.execute("SELECT keyword, name, module_type FROM tenants WHERE is_active=1 ORDER BY name").fetchall()
    conn.close()
    return templates.TemplateResponse("simulator.html", {
        "request": request,
        "quick_commands": QUICK_COMMANDS,
        "tenants": [dict(t) for t in tenants],
        "now": datetime.now().strftime("%H:%M"),
    })

# ── API: simulator ────────────────────────────────────────────────────────────

class SimulateRequest(BaseModel):
    phone: str
    message: str
    image_base64: Optional[str] = None

@app.post("/api/simulate")
async def api_simulate(body: SimulateRequest):
    image_bytes = None
    if body.image_base64:
        image_bytes = base64.b64decode(body.image_base64)
    reply = process_message(body.phone, body.message, image_bytes)
    return {"reply": reply, "phone": body.phone}

# ── Twilio webhook ────────────────────────────────────────────────────────────

@app.post("/webhook")
async def twilio_webhook(
    request: Request,
    From: str = Form(default=""),
    Body: str = Form(default=""),
    MediaUrl0: Optional[str] = Form(default=None),
    MediaContentType0: Optional[str] = Form(default=None),
    GroupId: Optional[str] = Form(default=None),
):
    from twilio.twiml.messaging_response import MessagingResponse
    phone = From.replace("whatsapp:+", "").replace("whatsapp:", "")
    image_bytes = None
    if MediaUrl0 and "image" in (MediaContentType0 or ""):
        try:
            auth = (os.getenv("TWILIO_ACCOUNT_SID",""), os.getenv("TWILIO_AUTH_TOKEN",""))
            async with httpx.AsyncClient() as client:
                img_res = await client.get(MediaUrl0, auth=auth)
                image_bytes = img_res.content
        except Exception as e:
            print(f"Image download failed: {e}")
    reply = process_message(phone, Body, image_bytes)
    resp = MessagingResponse()
    return Response(content=str(resp), media_type="application/xml")

# ── Meta Cloud API webhook ────────────────────────────────────────────────────

@app.get("/webhook/meta")
async def meta_webhook_verify(request: Request):
    """Meta webhook verification (challenge-response)."""
    params = request.query_params
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")
    verify_token = os.getenv("WA_VERIFY_TOKEN", "weza-webhook-verify-2024")
    if mode == "subscribe" and token == verify_token:
        print(f"✓ Meta webhook verified")
        return Response(content=challenge, media_type="text/plain")
    raise HTTPException(status_code=403, detail="Verification failed")

@app.post("/webhook/meta")
async def meta_webhook(request: Request):
    """Handle incoming Meta WhatsApp Cloud API messages."""
    body = await request.json()
    try:
        for entry in body.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                if "messages" not in value:
                    continue
                for msg in value["messages"]:
                    phone = msg.get("from", "")
                    msg_type = msg.get("type", "")
                    text = ""
                    image_bytes = None

                    if msg_type == "text":
                        text = msg.get("text", {}).get("body", "")
                    elif msg_type == "interactive":
                        interactive = msg.get("interactive", {})
                        if interactive.get("type") == "button_reply":
                            text = interactive.get("button_reply", {}).get("title", "")
                        elif interactive.get("type") == "list_reply":
                            text = interactive.get("list_reply", {}).get("title", "")
                    elif msg_type == "image":
                        # TODO: download image from Meta
                        text = msg.get("image", {}).get("caption", "")

                    if text:
                        process_message(phone, text, image_bytes)
    except Exception as e:
        print(f"Meta webhook error: {e}")
    return JSONResponse({"status": "ok"})

# ── Evolution API webhook ─────────────────────────────────────────────────────

@app.post("/webhook/evolution")
async def evolution_webhook(request: Request):
    """
    Handle incoming messages from Evolution API.
    Evolution sends MESSAGES_UPSERT events when a message is received.
    """
    try:
        body = await request.json()
        event = body.get("event", "")

        # Only process incoming messages
        if event != "messages.upsert":
            return JSONResponse({"status": "ignored"})

        data = body.get("data", {})
        key = data.get("key", {})

        # Skip messages sent BY us (fromMe = true)
        if key.get("fromMe", False):
            return JSONResponse({"status": "skipped_own"})

        phone = key.get("remoteJid", "").replace("@s.whatsapp.net", "").replace("@g.us", "")
        if not phone or not phone.isdigit():
            return JSONResponse({"status": "invalid_phone"})

        msg_type = data.get("messageType", "")
        text = ""
        image_bytes = None

        # Text message
        if msg_type in ("conversation", "extendedTextMessage"):
            text = data.get("message", {}).get("conversation", "") or \
                   data.get("message", {}).get("extendedTextMessage", {}).get("text", "")

        # Image message
        elif msg_type == "imageMessage":
            img_msg = data.get("message", {}).get("imageMessage", {})
            text = img_msg.get("caption", "")
            # TODO: download image via Evolution API media endpoint if needed

        # Location message
        elif msg_type == "locationMessage":
            loc = data.get("message", {}).get("locationMessage", {})
            lat = loc.get("degreesLatitude", 0)
            lng = loc.get("degreesLongitude", 0)
            # Store location for the user
            try:
                from app.database import get_db as _gdb
                _c = _gdb()
                _c.execute("INSERT OR REPLACE INTO user_profiles (phone,location_lat,location_lng,location_name) VALUES (?,?,?,?)",
                           (phone, lat, lng, f"{lat},{lng}"))
                _c.commit(); _c.close()
            except: pass
            text = f"location:{lat},{lng}"

        # Button response
        elif msg_type == "buttonsResponseMessage":
            text = data.get("message", {}).get("buttonsResponseMessage", {}).get("selectedDisplayText", "")

        # List response
        elif msg_type == "listResponseMessage":
            text = data.get("message", {}).get("listResponseMessage", {}).get("title", "")

        if text:
            print(f"\n📥 [EVOLUTION] +{phone}: {text[:100]}")
            process_message(phone, text, image_bytes)
        else:
            print(f"\n📥 [EVOLUTION] +{phone}: [unsupported type: {msg_type}]")

    except Exception as e:
        print(f"Evolution webhook error: {e}")
        import traceback; traceback.print_exc()

    return JSONResponse({"status": "ok"})

# ── API ───────────────────────────────────────────────────────────────────────

@app.get("/api/tenants")
async def api_tenants():
    conn = get_db()
    rows = conn.execute("SELECT id,keyword,name,module_type,is_active FROM tenants WHERE is_active=1 ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/api/stats")
async def api_stats():
    from app.services.weza_ai import get_ai_stats
    conn = get_db()
    tenants = conn.execute("SELECT COUNT(*) n FROM tenants WHERE is_active=1").fetchone()["n"]
    members = conn.execute("SELECT COUNT(*) n FROM sacco_members WHERE status='active'").fetchone()["n"]
    orders = conn.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    try:
        messages = conn.execute("SELECT COUNT(*) n FROM message_log").fetchone()["n"]
    except:
        messages = 0
    conn.close()
    ai = get_ai_stats()
    return {"tenants":tenants,"members":members,"orders":orders,"messages":messages,"ai":ai}

# ── WhatsApp Provider Management ─────────────────────────────────────────────

@app.get("/api/admin/provider-status")
async def provider_status(_=Depends(check_admin)):
    from app.services.whatsapp import get_provider_status
    return get_provider_status()

class ProviderSwitch(BaseModel):
    provider: str  # "evolution", "meta", or "twilio"

@app.post("/api/admin/set-provider")
async def switch_provider(body: ProviderSwitch, _=Depends(check_admin)):
    from app.services.whatsapp import set_provider
    success = set_provider(body.provider)
    if success:
        return {"status": "ok", "provider": body.provider}
    return JSONResponse(status_code=400, content={"error": "Invalid provider. Use: evolution, meta, or twilio"})

class GroupAddRequest(BaseModel):
    admin_phone: str
    group_name: str = ""
    group_id: str = ""

@app.post("/api/simulate-group-add")
async def simulate_group_add(body: GroupAddRequest):
    from app.router import handle_group_added
    phone = body.admin_phone.strip().lstrip("+")
    group_id = body.group_id or f"test_group_{phone}_{int(__import__('time').time())}"
    msg = handle_group_added(phone, group_id, body.group_name)
    return {"status":"ok","reply":msg or "Onboarding started","phone":phone,"group_id":group_id}


# ── Shop public page ─────────────────────────────────────────────────────────

@app.get("/shop/{keyword}", response_class=HTMLResponse)
async def shop_page(request: Request, keyword: str):
    conn = get_db()
    tenant = conn.execute("SELECT * FROM tenants WHERE UPPER(keyword)=UPPER(?) AND is_active=1",
                          (keyword,)).fetchone()
    if not tenant:
        conn.close()
        raise HTTPException(status_code=404, detail="Shop not found")
    tenant = dict(tenant)
    products = conn.execute(
        "SELECT * FROM products WHERE tenant_id=? AND is_available=1 ORDER BY category, name",
        (tenant["id"],)).fetchall()
    products = [dict(p) for p in products]
    # Stats
    stats = conn.execute("SELECT total_orders, total_revenue, total_leads, rating FROM tenants WHERE id=?",
                         (tenant["id"],)).fetchone()
    conn.close()
    return templates.TemplateResponse("shop.html", {
        "request": request, "shop": tenant, "products": products,
        "stats": dict(stats), "keyword": keyword.upper(),
    })

# ── Status card generation endpoint ──────────────────────────────────────────

@app.get("/api/generate-cards/{tenant_id}")
async def generate_cards_api(tenant_id: int, _=Depends(check_admin)):
    from app.services.status_cards import generate_daily_cards
    cards = generate_daily_cards(tenant_id)
    if not cards:
        return {"error": "No products found"}
    # For now just return count; actual sending via morning brief
    return {"cards_generated": len(cards)}

@app.get("/health")
async def health():
    return {"status":"ok","version":"2.0.0","ai":"grok","ts":datetime.now().isoformat()}

# ── Admin auth ────────────────────────────────────────────────────────────────

def check_admin(request: Request):
    token = request.cookies.get("admin_token")
    if token != base64.b64encode(f"{ADMIN_USER}:{ADMIN_PASS}".encode()).decode():
        raise HTTPException(status_code=302, headers={"Location": "/admin/login"})
    return True

@app.get("/admin/login", response_class=HTMLResponse)
async def admin_login_page(request: Request, error: str = ""):
    return templates.TemplateResponse("admin/login.html", {"request": request, "error": error})

@app.post("/admin/login")
async def admin_login(response: Response, username: str = Form(...), password: str = Form(...)):
    if username == ADMIN_USER and password == ADMIN_PASS:
        token = base64.b64encode(f"{username}:{password}".encode()).decode()
        resp = RedirectResponse("/admin", status_code=302)
        resp.set_cookie("admin_token", token, httponly=True)
        return resp
    return RedirectResponse("/admin/login?error=1", status_code=302)

@app.get("/admin/logout")
async def admin_logout():
    resp = RedirectResponse("/admin/login", status_code=302)
    resp.delete_cookie("admin_token")
    return resp

# ── Admin dashboard ───────────────────────────────────────────────────────────

@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(request: Request, _=Depends(check_admin)):
    from app.services.weza_ai import get_ai_stats
    conn = get_db()
    tenants = conn.execute("SELECT COUNT(*) n FROM tenants WHERE is_active=1").fetchone()["n"]
    members = conn.execute("SELECT COUNT(*) n FROM sacco_members WHERE status='active'").fetchone()["n"]
    loans   = conn.execute("SELECT COUNT(*) n FROM sacco_loans WHERE status='pending'").fetchone()["n"]
    pledges = conn.execute("SELECT COUNT(*) n FROM pledges WHERE status IN ('pledged','partial')").fetchone()["n"]
    orders  = conn.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    products= conn.execute("SELECT COUNT(*) n FROM products WHERE is_available=1").fetchone()["n"]
    try:
        messages = conn.execute("SELECT COUNT(*) n FROM message_log").fetchone()["n"]
    except:
        messages = 0
    recent  = conn.execute("SELECT * FROM audit_log ORDER BY logged_at DESC LIMIT 10").fetchall()

    # Revenue
    try:
        revenue = conn.execute("SELECT COALESCE(SUM(amount_ugx),0) n FROM payments WHERE verified=1").fetchone()["n"]
    except:
        revenue = 0
    conn.close()

    ai = get_ai_stats()
    from app.services.whatsapp import get_provider_status
    wa_provider = get_provider_status()
    return templates.TemplateResponse("admin/dashboard.html", {
        "request": request,
        "stats": {
            "tenants": tenants, "members": members, "loans": loans,
            "pledges": pledges, "orders": orders, "products": products,
            "messages": messages, "revenue": revenue,
        },
        "ai": ai,
        "wa": wa_provider,
        "recent": [dict(r) for r in recent],
        "active": "dashboard",
    })

@app.get("/admin/tenants", response_class=HTMLResponse)
async def admin_tenants(request: Request, _=Depends(check_admin)):
    conn = get_db()
    rows = conn.execute("SELECT t.*, (SELECT COUNT(*) FROM tenant_admins WHERE tenant_id=t.id) admins FROM tenants t ORDER BY created_at DESC").fetchall()
    conn.close()
    return templates.TemplateResponse("admin/tenants.html", {
        "request": request, "rows": [dict(r) for r in rows], "active": "tenants"
    })

@app.get("/admin/members", response_class=HTMLResponse)
async def admin_members(request: Request, _=Depends(check_admin)):
    conn = get_db()
    rows = conn.execute(
        "SELECT m.*, t.name as tenant_name FROM sacco_members m JOIN tenants t ON t.id=m.tenant_id ORDER BY m.joined_at DESC LIMIT 100"
    ).fetchall()
    conn.close()
    return templates.TemplateResponse("admin/members.html", {
        "request": request, "rows": [dict(r) for r in rows], "active": "members"
    })

@app.get("/admin/loans", response_class=HTMLResponse)
async def admin_loans(request: Request, _=Depends(check_admin)):
    conn = get_db()
    rows = conn.execute(
        "SELECT l.*, m.full_name, m.phone, t.name as tenant_name FROM sacco_loans l JOIN sacco_members m ON m.id=l.member_id JOIN tenants t ON t.id=l.tenant_id ORDER BY l.applied_at DESC LIMIT 50"
    ).fetchall()
    conn.close()
    return templates.TemplateResponse("admin/loans.html", {
        "request": request, "rows": [dict(r) for r in rows], "active": "loans"
    })

@app.get("/admin/events", response_class=HTMLResponse)
async def admin_events(request: Request, _=Depends(check_admin)):
    conn = get_db()
    rows = conn.execute(
        "SELECT e.*, t.name as tenant_name, (SELECT COUNT(*) FROM pledges WHERE event_id=e.id) pledge_count FROM group_events e JOIN tenants t ON t.id=e.tenant_id ORDER BY e.created_at DESC LIMIT 50"
    ).fetchall()
    conn.close()
    return templates.TemplateResponse("admin/events.html", {
        "request": request, "rows": [dict(r) for r in rows], "active": "events"
    })

@app.get("/admin/audit", response_class=HTMLResponse)
async def admin_audit(request: Request, _=Depends(check_admin)):
    conn = get_db()
    rows = conn.execute(
        "SELECT a.*, t.name as tenant_name FROM audit_log a LEFT JOIN tenants t ON t.id=a.tenant_id ORDER BY a.logged_at DESC LIMIT 100"
    ).fetchall()
    conn.close()
    return templates.TemplateResponse("admin/audit.html", {
        "request": request, "rows": [dict(r) for r in rows], "active": "audit"
    })

@app.get("/admin/ai", response_class=HTMLResponse)
async def admin_ai(request: Request, _=Depends(check_admin)):
    from app.services.weza_ai import get_ai_stats
    conn = get_db()
    try:
        daily = conn.execute(
            "SELECT DATE(created_at) as day, COUNT(*) as calls, SUM(input_tokens) as inp, SUM(output_tokens) as out, SUM(cost_usd) as cost FROM ai_usage GROUP BY DATE(created_at) ORDER BY day DESC LIMIT 30"
        ).fetchall()
    except:
        daily = []
    try:
        top_intents = conn.execute(
            "SELECT intent, COUNT(*) as cnt FROM message_log WHERE intent IS NOT NULL GROUP BY intent ORDER BY cnt DESC LIMIT 10"
        ).fetchall()
    except:
        top_intents = []
    try:
        languages = conn.execute(
            "SELECT language, COUNT(*) as cnt FROM message_log WHERE language IS NOT NULL GROUP BY language ORDER BY cnt DESC LIMIT 10"
        ).fetchall()
    except:
        languages = []
    conn.close()
    return templates.TemplateResponse("admin/ai_stats.html", {
        "request": request,
        "ai": get_ai_stats(),
        "daily": [dict(r) for r in daily],
        "top_intents": [dict(r) for r in top_intents],
        "languages": [dict(r) for r in languages],
        "active": "ai",
    })
