"""
diagnose.py — Run this to find out why AI is not working.
Run from the weza folder: python diagnose.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("\n=== Weza AI Diagnostic ===\n")

# 1. Check .env is loading
from dotenv import load_dotenv
load_dotenv()

key = os.getenv("GROQ_API_KEY", "")
print(f"GROQ_API_KEY in .env:  {'✓ Found — ' + key[:12] + '...' if key else '✗ MISSING or empty'}")

twilio_sid = os.getenv("TWILIO_ACCOUNT_SID", "")
print(f"TWILIO_ACCOUNT_SID:    {'✓ Found' if twilio_sid else '✗ Missing'}")

db = os.getenv("DATABASE_URL", "weza.db")
print(f"DATABASE_URL:          {db}")

# 2. Check ai_brain.py exists and has GROQ_API_KEY
print()
try:
    from app.services.ai_brain import GROQ_API_KEY, _call
    print(f"ai_brain.py import:    ✓ OK")
    print(f"GROQ_API_KEY in module: {'✓ ' + GROQ_API_KEY[:12] + '...' if GROQ_API_KEY else '✗ EMPTY — key not reaching the module'}")
except Exception as e:
    print(f"ai_brain.py import:    ✗ FAILED: {e}")

# 3. Try an actual Groq call
print()
if key:
    print("Testing Groq API call...")
    import httpx
    try:
        r = httpx.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json={
                "model": "llama3-8b-8192",
                "max_tokens": 20,
                "messages": [{"role": "user", "content": "Say: WORKING"}]
            },
            timeout=10
        )
        data = r.json()
        if "choices" in data:
            reply = data["choices"][0]["message"]["content"]
            print(f"Groq API call:         ✓ SUCCESS — replied: {reply[:50]}")
        else:
            print(f"Groq API call:         ✗ Error response: {data}")
    except Exception as e:
        print(f"Groq API call:         ✗ FAILED: {e}")
else:
    print("Skipping Groq test — no API key found")

# 4. Check database
print()
try:
    from app.database import get_db, init_db
    init_db()
    conn = get_db()
    tenants = conn.execute("SELECT id, keyword, name, module_type FROM tenants WHERE is_active=1").fetchall()
    print(f"Database:              ✓ OK — {len(tenants)} active groups")
    for t in tenants:
        print(f"  • {t['keyword']} — {t['name']} ({t['module_type']})")
    conn.close()
except Exception as e:
    print(f"Database:              ✗ FAILED: {e}")

print()
print("=== Diagnosis complete ===")
print()
print("If GROQ_API_KEY is missing:")
print("  1. Open .env in Notepad")
print("  2. Add: GROQ_API_KEY=gsk_your_key_here")
print("  3. Get a free key at https://console.groq.com/keys")
print("  4. Restart: python run.py")
