"""Seed Weza v3 demo data."""
import json
from datetime import datetime, timedelta
from app.database import init_db, get_db

def seed():
    init_db()
    conn = get_db()

    # Skip if already seeded
    if conn.execute("SELECT COUNT(*) n FROM tenants").fetchone()["n"] > 0:
        print("Already seeded. Delete weza.db to re-seed.")
        conn.close()
        return

    now = datetime.now()
    trial_end = (now + timedelta(days=90)).isoformat()

    # ═══ RETAIL: Kamya Hardware ═══
    t1 = conn.execute(
        "INSERT INTO tenants (keyword,name,module_type,owner_phone,momo_number,momo_network,location,wa_direct,is_verified,verified_at,trial_ends_at,subscription_status,country) "
        "VALUES ('KAMYA','Kamya Hardware','RETAIL','256700000010','0700000010','MTN','Nansana, Kampala','256700000010',1,?,?,'trial','UG')",
        (now.isoformat(), trial_end)).lastrowid
    conn.execute("INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')", (t1, "256700000010"))
    hardware = [
        ("Cement (Hima)", 38000, 36000, 10, "bag", "Building Materials", 50),
        ("Cement (Tororo)", 36000, 34000, 10, "bag", "Building Materials", 30),
        ("Iron Bars (Y16)", 18000, None, None, "piece", "Building Materials", 100),
        ("Iron Bars (Y12)", 14000, None, None, "piece", "Building Materials", 80),
        ("Binding Wire", 8000, None, None, "kg", "Building Materials", 25),
        ("Roofing Sheets (Gauge 28)", 32000, 30000, 20, "piece", "Roofing", 60),
        ("Nails (4 inch)", 6000, 5500, 5, "kg", "Hardware", 40),
        ("Paint (Sadolin 20L)", 280000, None, None, "tin", "Paint", 15),
        ("Paint Roller", 8000, None, None, "piece", "Paint", 20),
        ("PVC Pipe (1 inch)", 12000, 11000, 10, "piece", "Plumbing", 45),
        ("Sand", 120000, None, None, "trip", "Building Materials", 0),
        ("Aggregate", 180000, None, None, "trip", "Building Materials", 0),
        ("Door Lock (Yale)", 45000, None, None, "piece", "Hardware", 12),
        ("Hinge (4 inch)", 5000, None, None, "pair", "Hardware", 30),
        ("Wheelbarrow", 85000, None, None, "piece", "Tools", 8),
        ("Spade", 25000, None, None, "piece", "Tools", 15),
        ("Tiles (Floor 40x40)", 2500, 2200, 100, "piece", "Tiles", 500),
        ("Tile Adhesive", 22000, None, None, "bag", "Tiles", 20),
        ("Timber (2x4)", 8000, 7500, 20, "piece", "Building Materials", 60),
        ("Barbed Wire", 65000, None, None, "roll", "Fencing", 10),
    ]
    for h in hardware:
        conn.execute("INSERT INTO products (tenant_id,name,price_ugx,bulk_price_ugx,bulk_min_qty,unit,category,stock_qty,name_search) VALUES (?,?,?,?,?,?,?,?,?)",
                     (t1, h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[0].lower()))
    print(f"✓ Kamya Hardware — {len(hardware)} products")

    # ═══ RETAIL: Mama Grace General Store ═══
    t2 = conn.execute(
        "INSERT INTO tenants (keyword,name,module_type,owner_phone,momo_number,momo_network,location,wa_direct,trial_ends_at,subscription_status,country) "
        "VALUES ('GRACE','Mama Grace General Store','RETAIL','256700000011','0700000011','MTN','Ntinda, Kampala','256700000011',?,'trial','UG')",
        (trial_end,)).lastrowid
    conn.execute("INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')", (t2, "256700000011"))
    general = [
        ("Sugar (1kg)", 4500, 4000, 10, "kg", "Food", 50),
        ("Cooking Oil (5L)", 28000, None, None, "bottle", "Food", 20),
        ("Rice (5kg)", 18000, 16000, 5, "bag", "Food", 30),
        ("Flour (2kg)", 6000, None, None, "pack", "Food", 40),
        ("Soap (OMO 1kg)", 8000, 7500, 5, "pack", "Household", 60),
        ("Matches", 500, None, None, "box", "Household", 100),
        ("Exercise Books", 1500, 1200, 20, "piece", "Stationery", 200),
        ("Pens (Bic)", 500, None, None, "piece", "Stationery", 300),
        ("Airtime (MTN)", 1000, None, None, "voucher", "Telecom", 0),
        ("Charcoal", 3000, 2500, 5, "kg", "Fuel", 100),
        ("Paraffin (1L)", 4000, None, None, "litre", "Fuel", 30),
        ("Bread", 5000, None, None, "loaf", "Food", 10),
    ]
    for g in general:
        conn.execute("INSERT INTO products (tenant_id,name,price_ugx,bulk_price_ugx,bulk_min_qty,unit,category,stock_qty,name_search) VALUES (?,?,?,?,?,?,?,?,?)",
                     (t2, g[0], g[1], g[2], g[3], g[4], g[5], g[6], g[0].lower()))
    print(f"✓ Mama Grace General Store — {len(general)} products")

    # ═══ RETAIL: Mama Sarah Boutique (fashion) ═══
    t5 = conn.execute(
        "INSERT INTO tenants (keyword,name,module_type,owner_phone,momo_number,momo_network,location,wa_direct,is_verified,verified_at,trial_ends_at,subscription_status,country) "
        "VALUES ('SARAH','Mama Sarah Boutique','RETAIL','256700000012','0700000012','MTN','Wandegeya, Kampala','256700000012',1,?,?,'trial','UG')",
        (now.isoformat(), trial_end)).lastrowid
    conn.execute("INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')", (t5, "256700000012"))
    fashion = [
        ("Kitenge Dress", 45000, None, None, "piece", "Fashion", 8, '["S","M","L","XL"]'),
        ("Black Heels", 80000, None, None, "pair", "Footwear", 5, '["37","38","39","40","41"]'),
        ("Ankara Bag", 35000, None, None, "piece", "Bags", 12, '[]'),
        ("Men's Shirt", 25000, None, None, "piece", "Fashion", 15, '["S","M","L","XL","XXL"]'),
        ("Red Cocktail Dress", 55000, None, None, "piece", "Fashion", 4, '["S","M","L"]'),
        ("Sandals", 30000, None, None, "pair", "Footwear", 10, '["36","37","38","39","40"]'),
        ("Clutch Bag", 20000, None, None, "piece", "Bags", 8, '[]'),
        ("Denim Jacket", 65000, None, None, "piece", "Fashion", 6, '["M","L","XL"]'),
    ]
    for f in fashion:
        conn.execute("INSERT INTO products (tenant_id,name,price_ugx,bulk_price_ugx,bulk_min_qty,unit,category,stock_qty,sizes,name_search) VALUES (?,?,?,?,?,?,?,?,?,?)",
                     (t5, f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[0].lower()))
    print(f"✓ Mama Sarah Boutique — {len(fashion)} products")

    # ═══ SACCO: Vision SACCO ═══
    t3 = conn.execute(
        "INSERT INTO tenants (keyword,name,module_type,owner_phone,momo_number,momo_network,location,trial_ends_at,subscription_status,country) "
        "VALUES ('VISION','Vision SACCO','SACCO','256701000001','0701000001','MTN','Nakasero, Kampala',?,'trial','UG')",
        (trial_end,)).lastrowid
    conn.execute("INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')", (t3, "256701000001"))
    conn.execute("INSERT INTO sacco_rules (tenant_id,monthly_contrib_ugx,contrib_day,late_penalty_ugx,grace_days,loan_multiplier,interest_rate,loan_term_months,share_price) VALUES (?,50000,'last Saturday',5000,3,3.0,10.0,6,10000)", (t3,))

    members = [
        ("256701000001", "Sarah Nakato",  500000, 10, 0),
        ("256701000002", "John Ssali",    400000, 10, 0),
        ("256701000003", "Mary Nabukenya",300000, 5,  0),
        ("256701000004", "Peter Okello",  250000, 5,  150000),
        ("256701000005", "Grace Atim",    150000, 3,  0),
        ("256701000006", "David Ssemanda",200000, 5,  100000),
    ]
    for phone, name, savings, shares, loan in members:
        mid = conn.execute("INSERT INTO sacco_members (tenant_id,phone,full_name,savings_balance,shares,share_value,loan_balance) VALUES (?,?,?,?,?,?,?)",
                           (t3, phone, name, savings, shares, shares*10000, loan)).lastrowid
        # Add some transactions
        for i in range(3):
            bal = savings - (50000 * (2-i))
            conn.execute("INSERT INTO sacco_transactions (tenant_id,member_id,type,amount_ugx,balance_after,notes) VALUES (?,?,'deposit',50000,?,?)",
                         (t3, mid, bal, f"Month {i+1} contribution"))
    print(f"✓ Vision SACCO — {len(members)} members")

    # ═══ GROUPS: Nakato Wedding ═══
    t4 = conn.execute(
        "INSERT INTO tenants (keyword,name,module_type,owner_phone,momo_number,momo_network,trial_ends_at,subscription_status) "
        "VALUES ('NAKATO','Nakato Wedding Committee','GROUPS','256702000001','0702000001','MTN',?,'trial')",
        (trial_end,)).lastrowid
    conn.execute("INSERT INTO tenant_admins (tenant_id,phone,role) VALUES (?,?,'owner')", (t4, "256702000001"))
    eid = conn.execute("INSERT INTO group_events (tenant_id,event_name,event_type,target_budget,collected_total) VALUES (?,'Nakato Wedding','wedding',5000000,3250000)", (t4,)).lastrowid
    pledgers = [
        ("256702000001","Organiser",500000,500000,"cleared"),
        ("256702000002","Uncle Peter",500000,500000,"cleared"),
        ("256702000003","Auntie Rose",300000,300000,"cleared"),
        ("256702000004","Cousin James",200000,200000,"cleared"),
        ("256702000005","Friend Stella",500000,250000,"partial"),
        ("256702000006","Brother David",300000,300000,"cleared"),
        ("256702000007","Sister Agnes",200000,200000,"cleared"),
        ("256702000008","Aunt Mary",500000,0,"pledged"),
        ("256702000009","Friend Tom",300000,0,"pledged"),
        ("256702000010","Neighbor Grace",200000,200000,"cleared"),
    ]
    for phone, name, pledged, paid, status in pledgers:
        conn.execute("INSERT INTO pledges (event_id,tenant_id,member_phone,member_name,pledged_ugx,paid_ugx,status) VALUES (?,?,?,?,?,?,?)",
                     (eid, t4, phone, name, pledged, paid, status))
    print(f"✓ Nakato Wedding — {len(pledgers)} pledges")

    # ═══ Some leads and analytics ═══
    for i in range(5):
        conn.execute("INSERT INTO leads (buyer_phone,tenant_id,product_name,status) VALUES (?,?,?,?)",
                     (f"25670300000{i}", t1, ["cement","iron bars","paint","nails","tiles"][i], "sent"))
    for i in range(3):
        conn.execute("INSERT INTO leads (buyer_phone,tenant_id,product_name,status) VALUES (?,?,?,?)",
                     (f"25670300001{i}", t5, ["dress","heels","bag"][i], "sent"))
    conn.execute("UPDATE tenants SET total_leads=5 WHERE id=?", (t1,))
    conn.execute("UPDATE tenants SET total_leads=3 WHERE id=?", (t5,))

    # Some orders/sales
    for i in range(3):
        conn.execute("INSERT INTO orders (tenant_id,buyer_phone,items,total_ugx,status) VALUES (?,?,?,?,'completed')",
                     (t1, f"256703000{i:03d}", json.dumps([{"name":"Cement","qty":10}]), 380000))
    conn.execute("UPDATE tenants SET total_orders=3, total_revenue=1140000 WHERE id=?", (t1,))
    conn.execute("INSERT INTO orders (tenant_id,buyer_phone,items,total_ugx,status) VALUES (?,?,?,?,'completed')",
                 (t5, "256703000010", json.dumps([{"name":"Kitenge Dress","qty":1}]), 45000))
    conn.execute("UPDATE tenants SET total_orders=1, total_revenue=45000 WHERE id=?", (t5,))

    conn.commit()
    conn.close()

    print(f"""
╔═══════════════════════════════════════════════════════════╗
║              Weza v3 — Demo Data Ready!                   ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  🛒 SHOPS:                                                ║
║    KAMYA — Kamya Hardware (Nansana) ✅                    ║
║    GRACE — Mama Grace General Store (Ntinda)              ║
║    SARAH — Mama Sarah Boutique (Wandegeya) ✅             ║
║                                                           ║
║  🏦 SACCO:                                                ║
║    VISION — Vision SACCO (6 members)                      ║
║    Treasurer: 256701000001 (Sarah Nakato)                 ║
║                                                           ║
║  👥 WEDDING:                                               ║
║    NAKATO — Nakato Wedding Committee                      ║
║                                                           ║
║  Test deep links (from Status cards):                     ║
║    Type: Shop SARAH                                       ║
║    Type: Shop KAMYA                                       ║
║                                                           ║
║  Test SACCO cash deposit (as treasurer):                  ║
║    Phone: 256701000001                                    ║
║    Type: VISION                                           ║
║    Then: DEPOSIT Mary 50000 cash                          ║
║                                                           ║
║  Web shop pages:                                          ║
║    http://localhost:8000/shop/SARAH                        ║
║    http://localhost:8000/shop/KAMYA                        ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝""")

if __name__ == "__main__":
    seed()
