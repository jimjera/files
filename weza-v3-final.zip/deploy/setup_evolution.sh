#!/bin/bash
# Weza — Evolution API Setup
# Run: bash deploy/setup_evolution.sh YOUR_API_KEY wesza.online
set -e
EVO_API_KEY="${1:-weza-evo-key-change-me}"
WEZA_DOMAIN="${2:-wesza.online}"

echo "🚀 Setting up Evolution API..."

# Install Docker if needed
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker && systemctl start docker
fi

# Stop old container
docker stop evolution-api 2>/dev/null || true
docker rm evolution-api 2>/dev/null || true

# Run Evolution API
docker run -d --name evolution-api --restart always \
    -p 8080:8080 \
    -e AUTHENTICATION_API_KEY="$EVO_API_KEY" \
    -e AUTHENTICATION_EXPOSE_IN_FETCH_INSTANCES=true \
    -e WEBHOOK_GLOBAL_URL="https://$WEZA_DOMAIN/webhook/evolution" \
    -e WEBHOOK_GLOBAL_ENABLED=true \
    -e WEBHOOK_GLOBAL_WEBHOOK_BY_EVENTS=false \
    -e LOG_LEVEL=WARN \
    -v evolution_instances:/evolution/instances \
    atrevolution/evolution-api:v2.2.3

echo "⏳ Waiting 15 seconds for startup..."
sleep 15

# Create instance
echo "📱 Creating Weza instance..."
curl -s -X POST "http://localhost:8080/instance/create" \
    -H "apikey: $EVO_API_KEY" \
    -H "Content-Type: application/json" \
    -d "{\"instanceName\":\"weza\",\"integration\":\"WHATSAPP-BAILEYS\",\"qrcode\":true,\"rejectCall\":true,\"alwaysOnline\":true,\"readMessages\":true}"

# Update Weza .env
if [ -f /opt/weza/.env ]; then
    grep -q "EVOLUTION_API_URL" /opt/weza/.env || echo -e "\nEVOLUTION_API_URL=http://localhost:8080\nEVOLUTION_API_KEY=$EVO_API_KEY\nEVOLUTION_INSTANCE=weza\nWHATSAPP_PROVIDER=evolution" >> /opt/weza/.env
    sed -i "s|^EVOLUTION_API_KEY=.*|EVOLUTION_API_KEY=$EVO_API_KEY|" /opt/weza/.env
    sed -i "s|^WHATSAPP_PROVIDER=.*|WHATSAPP_PROVIDER=evolution|" /opt/weza/.env
fi

sudo systemctl restart weza 2>/dev/null || true

echo ""
echo "════════════════════════════════════════════════════"
echo "  ✅ Evolution API running!"
echo ""
echo "  📱 Scan QR to connect WhatsApp:"
echo "  Open: http://$(hostname -I | awk '{print $1}'):8080/manager"
echo "  API Key: $EVO_API_KEY"
echo ""
echo "  Or get QR via API:"
echo "  curl http://localhost:8080/instance/connect/weza -H 'apikey: $EVO_API_KEY'"
echo ""
echo "  Test after scanning:"
echo "  curl -X POST http://localhost:8080/message/sendText/weza \\"
echo "    -H 'apikey: $EVO_API_KEY' -H 'Content-Type: application/json' \\"
echo "    -d '{\"number\":\"YOUR_PHONE\",\"text\":\"Hello from Weza!\"}'"
echo "════════════════════════════════════════════════════"
