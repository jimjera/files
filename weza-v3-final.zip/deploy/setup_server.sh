#!/bin/bash
# Weza Platform — VPS Deployment Script
# Safe to re-run — won't overwrite nginx/SSL
set -e
echo "🚀 Setting up Weza Platform..."

sudo apt update && sudo apt install -y python3 python3-pip python3-venv nginx certbot python3-certbot-nginx

sudo useradd -m -s /bin/bash weza 2>/dev/null || true

APP_DIR="/opt/weza"
sudo mkdir -p $APP_DIR
sudo cp -r . $APP_DIR/
sudo chown -R weza:weza $APP_DIR

cd $APP_DIR
if [ ! -d "venv" ]; then
    sudo -u weza python3 -m venv venv
fi
sudo -u weza venv/bin/pip install -r requirements.txt

if [ ! -f .env ]; then
    sudo -u weza cp .env.example .env
    echo "⚠️  Edit /opt/weza/.env — add GROK_API_KEY and EVOLUTION_API_KEY"
fi

sudo -u weza venv/bin/python -c "from app.database import init_db; init_db()"
sudo -u weza venv/bin/python seed_demo.py 2>/dev/null || true

# Systemd service
sudo tee /etc/systemd/system/weza.service > /dev/null << EOF
[Unit]
Description=Weza WhatsApp AI Platform
After=network.target
[Service]
Type=simple
User=weza
WorkingDirectory=/opt/weza
Environment=PATH=/opt/weza/venv/bin
ExecStart=/opt/weza/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable weza
sudo systemctl restart weza

# Only create nginx config if it doesn't exist (don't overwrite SSL)
if [ ! -f /etc/nginx/sites-available/weza ]; then
    sudo tee /etc/nginx/sites-available/weza > /dev/null << EOF
server {
    listen 80;
    server_name _;
    client_max_body_size 10M;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 120s;
    }
}
EOF
    sudo ln -sf /etc/nginx/sites-available/weza /etc/nginx/sites-enabled/
    sudo rm -f /etc/nginx/sites-enabled/default
    sudo nginx -t && sudo systemctl restart nginx
else
    echo "✅ Nginx config exists — not overwriting (SSL preserved)"
    sudo systemctl restart weza
fi

echo ""
echo "✅ Weza is running!"
echo "   Website: http://$(hostname -I | awk '{print $1}')"
echo "   Admin:   http://$(hostname -I | awk '{print $1}')/admin"
echo ""
echo "Next: bash deploy/setup_evolution.sh YOUR_KEY wesza.online"
